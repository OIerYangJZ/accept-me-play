"""每周行动与课题管理。"""

from . import data, helpers
from .state import Paper, clamp

TITLE_TEMPLATES = {
    "llm": ("{x} Is All You Need?", "Scaling {x} Without Scaling Compute", "When Do Language Models Really {y}?"),
    "vision_gen": ("Diffusing {x} into Pixels", "One Image Is Worth a Thousand {x}", "Towards Controllable {x} Generation"),
    "ml_theory": ("A Sharp Analysis of {x}", "On the Convergence of {x}", "Why Does {x} Generalize?"),
    "linguistics": ("What Language Models Do Not Know About {x}", "Rethinking {x} in the Age of Scale", "{x}: A Linguistic Probe"),
    "ai4science": ("Learning {x} from First Principles", "{x}-Informed Neural Operators", "Accelerating {x} Discovery with Deep Learning"),
}
TITLE_X = {
    "llm": ("Tiny Adapters", "Chain-of-Doubt", "Sparse Memory", "Self-Refusal"),
    "vision_gen": ("Shadows", "Tiny Cats", "3D Teapots", "Night Scenes"),
    "ml_theory": ("Sign Descent", "Overparameterized Attention", "Lazy Training", "Label Noise"),
    "linguistics": ("Negation", "Metaphor", "Word Order", "Politeness"),
    "ai4science": ("Protein Folding Pathways", "Crystal Stability", "Turbulent Flows", "Catalyst"),
}
TITLE_Y = ("Reason", "Forget", "Plan", "Count")


def make_title(gs, topic):
    rng = gs.rng()
    tpl = rng.choice(TITLE_TEMPLATES[topic])
    return tpl.format(x=rng.choice(TITLE_X[topic]), y=rng.choice(TITLE_Y))


def can_start_paper(gs):
    cur = gs.current_paper
    return gs.ideas >= data.IDEAS_TO_START and (cur is None or cur.status != "draft")


def start_paper(gs, topic, title=None):
    gs.ideas -= data.IDEAS_TO_START
    p = Paper(gs.new_id(), title or make_title(gs, topic), topic)
    # 读论文积累的底子：之前读得越多，起点越高
    p.attrs["novelty"] = 15.0 + gs.skill["novelty"] * 0.8
    gs.papers.append(p)
    gs.active_paper = p.id
    gs.note("开始了新课题《%s》" % p.title)
    return p


def start_thesis_paper(gs):
    """开局自带的课题：本科毕业论文的延续（当年就挂在夏可薇那里）。"""
    topic = data.TRACKS[gs.track]["topics"][0]
    p = Paper(gs.new_id(), make_title(gs, topic), topic)
    for a, v in (("novelty", 30), ("rigor", 26), ("clarity", 28), ("sota", 30), ("hype", 8)):
        p.attrs[a] = float(v)
    p.progress = 35.0
    p.arxiv = True
    gs.papers.append(p)
    gs.active_paper = p.id
    gs.flag("thesis_paper")
    return p


def set_active_paper(gs, pid):
    gs.active_paper = pid


def _gain(gs, paper, attr, base, combo=1.0):
    """属性增益：受选题倍率、导师加成、日程搭配和边际递减影响。"""
    mult = data.TOPICS[paper.topic]["gain"].get(attr, 1.0) * gs.advisor_info["gain_bonus"] * combo
    mult *= 1.0 + gs.skill[attr] / 40.0
    if gs.low_san:
        mult *= 0.7
    cur = paper.attrs[attr]
    amount = base * mult * (1.0 - cur / 125.0)
    paper.attrs[attr] = clamp(cur + amount, 0, 100)
    gs.skill[attr] = min(data.SKILL_MAX, gs.skill[attr] + 1)
    return amount


def _progress(paper, amount):
    paper.progress = clamp(paper.progress + amount, 0, 100)


def in_crunch_window(gs):
    return any(0 <= d - gs.week <= 2 for d in upcoming_deadlines(gs))


def upcoming_deadlines(gs, horizon=60):
    out = []
    for v in data.CONFERENCE_ORDER:
        for d in data.VENUES[v]["deadlines"]:
            if gs.week <= d <= gs.week + horizon:
                out.append(d)
    return sorted(out)


def available_actions(gs):
    """返回 [(action_id, 是否可选, 不可选原因)]。"""
    paper = gs.current_paper
    has_draft = paper is not None and paper.status in ("draft", "rejected") and not gs.paper_under_review(paper.id)
    result = []
    for a in data.ACTION_ORDER:
        ok, why = True, ""
        if a in ("experiment", "theory", "write", "promote") and not has_draft:
            ok, why = False, "需要一个正在进行的课题"
        if a == "experiment" and ok and gs.compute < data.EXPERIMENT_COMPUTE_COST:
            ok, why = False, "算力不足"
        if a == "crunch" and not (has_draft and in_crunch_window(gs)):
            ok, why = False, "只能在截稿前两周选"
        result.append((a, ok, why))
    return result


# ---------------------------------------------------------------------------
# 日程搭配：上周做了什么会影响这周的效果。排日程时界面会把加成标在格子上。
# ---------------------------------------------------------------------------
WORK_ACTIONS = ("read", "experiment", "theory", "write", "promote", "crunch")
COMBOS = {
    # (上周, 这周): (主属性倍率, 说明)
    ("experiment", "write"): (1.25, "有结果可写"),
    ("theory", "experiment"): (1.15, "理论指路"),
    ("read", "theory"): (1.15, "读到了关键引理"),
    ("write", "promote"): (1.3, "稿子写顺了，宣传有底气"),
}
OVERWORK_STREAK = 3  # 连续工作这么多周之后，再工作会额外掉 SAN
OVERWORK_SAN = -4
REST_AFTER_WORK_SAN = 7


def combo(last_action, work_streak, action):
    """返回 (倍率, 额外 SAN, 说明)。只看上一周和连续工作周数，排日程时可以提前算。"""
    mult, note = COMBOS.get((last_action, action), (1.0, ""))
    san = 0
    if action in WORK_ACTIONS and work_streak >= OVERWORK_STREAK:
        san = OVERWORK_SAN
        note = (note + "，" if note else "") + "连轴转 SAN %d" % OVERWORK_SAN
    elif action == "rest" and work_streak >= OVERWORK_STREAK:
        san = REST_AFTER_WORK_SAN
        note = "终于能歇口气 SAN +%d" % REST_AFTER_WORK_SAN
    return mult, san, note


def plan_preview(gs, plan):
    """排好的日程每一格会拿到什么搭配效果：[(倍率, 额外 SAN, 说明)]。"""
    last, streak = gs.last_action, gs.work_streak
    out = []
    for action, _target in plan:
        out.append(combo(last, streak, action))
        streak = streak + 1 if action in WORK_ACTIONS else 0
        last = action
    return out


def apply_action(gs, action, target=None, talked=False):
    """执行一周的行动。返回 dict(lines=[...], event=可能触发的事件 id)。
    target：去见刊娘时是她的 id；工作周是 AI 帮手的形态 id（见 helpers.py），没有帮手是 None。
    talked=True 表示这周去见刊娘时已经聊过天（好感在 talk.talk() 里结算了）。"""
    rng = gs.rng()
    paper = gs.current_paper
    lines = []
    res = {"action": action, "lines": lines, "bug": False, "target": target, "talked": talked}
    mult, combo_san, combo_note = combo(gs.last_action, gs.work_streak, action)
    res["combo"] = combo_note
    working = paper is not None and paper.status in ("draft", "rejected")
    h = helpers.begin(gs, action, target, rng) if working and action != "social" else None
    res["helper"] = h
    if h:
        mult *= h["mult"]
    claude_code = bool(h and h["ok"] and not h["banned"] and h["family"] == "claude")

    if action == "read":
        if paper is not None and paper.status in ("draft", "rejected"):
            g = _gain(gs, paper, "novelty", rng.uniform(12, 17), mult)
            lines.append("创新 +%.0f" % g)
        if rng.random() < 0.6 or paper is None or paper.status != "draft":
            gs.ideas += 1
            lines.append("获得了一个 idea")
        gs.add_san(-2)

    elif action == "experiment":
        gs.add_compute(-data.EXPERIMENT_COMPUTE_COST)
        bug_chance = 0.18 if gs.bug_streak == 0 else 0.05
        if claude_code:
            bug_chance *= 0.4  # Claude 重写过的脚本很少出错
        if rng.random() < bug_chance:
            gs.bug_streak += 1
            res["bug"] = True
            gs.add_san(-6)
            lines.append("跑了一周，发现数据加载写错了。实验结果 +0")
        else:
            gs.bug_streak = 0
            g = _gain(gs, paper, "sota", rng.uniform(14, 20), mult)
            r = _gain(gs, paper, "rigor", rng.uniform(2, 4))
            _progress(paper, 8)
            lines.append("实验 +%.0f，严谨 +%.0f" % (g, r))
            gs.add_san(-3)

    elif action == "theory":
        g = _gain(gs, paper, "rigor", rng.uniform(13, 18), mult)
        _progress(paper, 7)
        lines.append("严谨 +%.0f" % g)
        gs.add_san(-4)

    elif action == "write":
        g = _gain(gs, paper, "clarity", rng.uniform(13, 18), mult)
        _progress(paper, 14)
        lines.append("表达 +%.0f" % g)
        gs.add_san(-3)

    elif action == "promote":
        if not paper.arxiv:
            paper.arxiv = True
            gs.add_affinity("kiwi", 3)
            lines.append("论文挂上了 arXiv（夏可薇好感 +3）")
        g = _gain(gs, paper, "hype", rng.uniform(14, 20), mult)
        # 热度高于实际质量时，水分增加（为“夸大结论”埋雷）
        quality = (paper.attrs["sota"] + paper.attrs["rigor"] + paper.attrs["novelty"]) / 3.0
        if paper.attrs["hype"] > quality + 20:
            paper.water += 3
        lines.append("热度 +%.0f" % g)
        gs.add_san(-1)

    elif action == "rest":
        gs.add_san(15)
        lines.append("SAN +15")

    elif action == "social":
        if target and res.get("talked"):
            pass  # 已经在 talk.talk() 里结算过好感和 SAN
        elif target:
            gain = rng.uniform(4, 7)
            if gs.low_san:
                gain *= 0.6
            gs.add_affinity(target, gain)
            gs.met[target] = True
            gs.add_san(5)
            lines.append("%s好感 +%.0f，SAN +5" % (data.HEROINES[target]["name"], gain))

    elif action == "crunch":
        for a in ("sota", "rigor", "clarity"):
            _gain(gs, paper, a, 6)
        _progress(paper, 22)
        paper.water += 2
        gs.add_san(-15)
        lines.append("完成度 +22，各项属性小幅提升，SAN -15")

    if working:
        helpers.finish(gs, paper, action, h, lines)
    if combo_san:
        gs.add_san(combo_san)
    if combo_note:
        lines.append("（%s）" % combo_note)
    gs.work_streak = gs.work_streak + 1 if action in WORK_ACTIONS else 0
    gs.last_action = action
    return res


def end_of_week(gs):
    """每周结算：算力恢复、导师带来的 SAN 变化、热度衰减。"""
    adv = gs.advisor_info
    gs.add_compute(adv["compute_per_week"])
    gs.add_san(adv["san_per_week"])
    for p in gs.papers:
        if p.attrs["hype"] > 0:
            p.attrs["hype"] = max(0.0, p.attrs["hype"] - 1.5)
    gs.week += 1
