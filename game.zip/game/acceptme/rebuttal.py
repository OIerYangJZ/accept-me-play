"""Rebuttal 对战。

玩家在有限的"天数"内，给每条审稿意见分配一张回应卡。提交后结算：
每条意见按卡牌效果被不同程度地解决，审稿人据此改分，并给出 raise / keep / lower 的态度。
"""

from . import data, helpers
from .compat import Base, rdict, rlist
from .state import clamp

# eff: 对各类意见的基础解决程度（0~1）；没写的意见类型使用 default
CARDS = {
    "experiment": {
        "name": "补实验",
        "days": 2,
        "compute": 40,
        "san": -4,
        "desc": "连夜补跑。对缺基线、缺消融、提升太小最有效。",
        "eff": {"missing_baseline": 0.95, "missing_ablation": 0.95, "weak_results": 0.7, "reproducibility": 0.6},
        "default": 0.2,
    },
    "clarify": {
        "name": "澄清误解",
        "days": 1,
        "compute": 0,
        "san": -1,
        "desc": "指出审稿人看漏的地方。对写作不清楚和创新性质疑有效。",
        "eff": {"unclear_writing": 0.9, "limited_novelty": 0.6, "overclaim": 0.4, "reproducibility": 0.5,
                "buried_contribution": 0.85},
        "default": 0.3,
    },
    "theory": {
        "name": "补理论分析",
        "days": 2,
        "compute": 0,
        "san": -5,
        "desc": "加一个定理或推导。严谨不够时可能失败。",
        "eff": {"need_theory": 0.95, "limited_novelty": 0.5, "overclaim": 0.4},
        "default": 0.2,
        "needs_rigor": 30,
    },
    "concede": {
        "name": "诚恳修改",
        "days": 0.5,
        "compute": 0,
        "san": 0,
        "desc": "承认问题，承诺修改。稳妥但效果有限，对夸大结论特别有效。",
        "eff": {"overclaim": 0.9},
        "default": 0.4,
    },
    "argue": {
        "name": "据理力争",
        "days": 1,
        "compute": 0,
        "san": -2,
        "desc": "高风险高回报：说服了就大涨，说不服还会惹毛对方。",
        "eff": {},
        "default": 0.85,
        "risky": True,
    },
    "cite": {
        "name": "加引用",
        "days": 0.5,
        "compute": 0,
        "san": -1,
        "desc": "把他要的文献都加上。对 Reviewer #2 有奇效。",
        "eff": {"cite_me": 1.0, "limited_novelty": 0.2},
        "default": 0.05,
    },
    "flag_llm": {
        "name": "向 AC 举报代写",
        "days": 1,
        "compute": 0,
        "san": -1,
        "desc": "指出这份意见疑似大模型生成。只对 Reviewer #3 有用。",
        "eff": {},
        "default": 0.0,
        "only_persona": "delve",
    },
    # AI 帮手（helpers.py）：认识她、额度够、没被封才能出
    "ai_claude": {
        "name": "让 Claude 写回复",
        "days": 0.5,
        "compute": 0,
        "san": 0,
        "desc": "她写得又快又清楚，对写作、贡献、可复现性的质疑都很有效。但写到一半可能被封号。",
        "eff": {"unclear_writing": 0.95, "buried_contribution": 0.95, "limited_novelty": 0.65, "overclaim": 0.6,
                "reproducibility": 0.7},
        "default": 0.35,
        "helper": "claude",
    },
    "ai_gpt": {
        "name": "让 GPT 补证明",
        "days": 1,
        "compute": 0,
        "san": -1,
        "desc": "一晚上补完一个定理，对缺乏理论分析特别有效。只是回复读起来像一份免责声明。",
        "eff": {"need_theory": 0.95, "missing_ablation": 0.3, "limited_novelty": 0.35, "unclear_writing": 0.15},
        "default": 0.25,
        "helper": "chatgpt",
    },
}
MAX_GAIN_PER_REVIEW = 1.6  # rebuttal 能挽回的分数有上限

CARD_ORDER = ("experiment", "clarify", "theory", "concede", "argue", "cite", "flag_llm", "ai_claude", "ai_gpt")


def days_budget(venue, round_no=1):
    rounds = data.VENUES[venue]["rebuttal_rounds"]
    return 7.0 if rounds <= 1 else 5.0


class RebuttalPlan(Base):
    """玩家的分配方案：{(review_idx, concern_idx): card_id}"""

    def __init__(self, sub, round_no=1):
        self.sub_id = sub.id
        self.venue = sub.venue
        self.round_no = round_no
        self.budget = days_budget(sub.venue, round_no)
        self.assign = rdict()
        self.done = rlist()  # 已经结算过的审稿人（对线时一位一位来）
        self.extra = rlist()  # 回应追问用掉的卡

    def cost(self, gs=None):
        cards = list(self.assign.values()) + list(getattr(self, "extra", ()))
        days = sum(CARDS[c]["days"] for c in cards)
        compute = sum(CARDS[c]["compute"] for c in cards)
        return days, compute

    def days_left(self):
        return self.budget - self.cost()[0]


def _ensure(plan):
    """旧存档里的 RebuttalPlan 没有 done / extra 字段。"""
    if not hasattr(plan, "done"):
        plan.done = rlist()
    if not hasattr(plan, "extra"):
        plan.extra = rlist()


def card_usable(gs, sub, review, card_id):
    card = CARDS[card_id]
    only = card.get("only_persona")
    if only and review.persona != only:
        return False
    fam = card.get("helper")
    if fam and not helpers.family_ready(gs, fam, helpers.REBUTTAL_COST):
        return False
    return True


def can_assign(gs, plan, sub, ri, ci, card_id):
    review = sub.reviews[ri]
    if not card_usable(gs, sub, review, card_id):
        if CARDS[card_id].get("helper"):
            return False, "她现在帮不上忙（还没认识、额度不够，或者账号被停用了）"
        return False, "这张卡对这位审稿人没用"
    _ensure(plan)
    old = plan.assign.get((ri, ci))
    days, _ = plan.cost()
    # 已经结算过的审稿人，他们的卡的算力已经扣掉了，这里只算还没结算的
    compute = sum(CARDS[c]["compute"] for (r, _c), c in plan.assign.items() if r not in plan.done)
    if old:
        days -= CARDS[old]["days"]
        compute -= CARDS[old]["compute"]
    card = CARDS[card_id]
    if days + card["days"] > plan.budget + 1e-9:
        return False, "rebuttal 时间不够了"
    if compute + card["compute"] > gs.compute + 1e-9:
        return False, "算力不够"
    return True, ""


def set_card(gs, plan, sub, ri, ci, card_id):
    if card_id is None:
        plan.assign.pop((ri, ci), None)
        return True, ""
    ok, why = can_assign(gs, plan, sub, ri, ci, card_id)
    if ok:
        plan.assign[(ri, ci)] = card_id
    return ok, why


def _card_effect(gs, paper, review, concern, card_id, rng, notes):
    """一张卡对一条意见的解决程度（0~1）和额外的分数变化。"""
    card = CARDS[card_id]
    extra = 0.0
    fam = card.get("helper")
    dumb = fam == "chatgpt" and helpers.is_dumb(gs)
    if fam and not helpers.use_small(gs, fam, rng, helpers.REBUTTAL_COST):
        if fam == "claude" and helpers.is_banned(gs):
            notes.append("Claude 的账号被停用了，这条回复没发出去")
        else:
            notes.append("%s 本月额度用完了" % helpers.FAMILIES[fam]["name"])
        return 0.0, 0.0
    eff = card["eff"].get(concern.kind, card["default"])
    if dumb:
        eff *= helpers.DUMB_FACTOR
        notes.append("ChatGPT 降智了，补的证明有一步是错的")
    if card.get("needs_rigor") and paper.attrs["rigor"] < card["needs_rigor"]:
        eff *= 0.4
        notes.append("理论分析不够扎实")
    if card_id == "experiment":
        eff *= 0.7 + 0.3 * min(1.0, gs.compute / 100.0 + 0.5)
    if card.get("risky"):
        # 据理力争：论文本身越扎实越容易说服
        p_win = 0.35 + 0.5 * paper.effective("rigor") / 100.0
        if review.persona == "rev2":
            p_win -= 0.3 if gs.has("rev2_grudge") else 0.2  # 初遇时顶过他，他记仇
        if rng.random() < p_win:
            eff = 0.95
            notes.append("据理力争成功")
        else:
            eff = 0.0
            extra -= 0.5
            notes.append("据理力争失败，惹毛了对方")
    if review.persona == "rev2" and concern.kind != "cite_me":
        eff *= 0.72 if gs.has("rev2_respect") else 0.6  # Reviewer #2 很难被说服；答应过补文献的，他会稍微认真读
    if review.persona == "rev2" and concern.kind == "cite_me" and card_id == "cite":
        extra += 0.5  # 奇效
    return clamp(eff * rng.uniform(0.85, 1.1), 0.0, 1.0), extra


def _set_reply(sub, review, new_score):
    old_shown = display_score(sub.venue, review.score)
    review.score = new_score
    # 态度跟着玩家看得到的分数走，避免出现“6 → 6，我上调评分”
    shown = display_score(sub.venue, new_score)
    review.reply = "raise" if shown > old_shown else "lower" if shown < old_shown else "keep"


def resolve_review(gs, sub, plan, ri):
    """结算一位审稿人：扣掉给他用的卡的算力和 SAN，改分，给出态度。返回结果 dict。"""
    _ensure(plan)
    rng = gs.rng()
    paper = gs.paper(sub.paper_id)
    review = sub.reviews[ri]
    mine = [(ci, c) for (r, ci), c in plan.assign.items() if r == ri]
    gs.add_compute(-sum(CARDS[c]["compute"] for _, c in mine))
    gs.add_san(sum(CARDS[c]["san"] for _, c in mine))

    delta = 0.0
    notes = []
    flagged = False
    for ci, concern in enumerate(review.concerns):
        card_id = plan.assign.get((ri, ci))
        remaining = 1.0 - concern.resolved
        if card_id is None:
            # 没回应的意见：严重的会让审稿人更不满
            if concern.severity >= 1.2 and rng.random() < 0.4:
                delta -= 0.3
                notes.append("没回应「%s」，对方有点不满" % concern_name(concern.kind))
            continue
        if card_id == "flag_llm":
            review.weight = 0.3
            flagged = True
            notes.append("AC 注意到了这份意见可能是代写的")
            continue
        eff, extra = _card_effect(gs, paper, review, concern, card_id, rng, notes)
        delta += extra
        gained = remaining * eff
        concern.resolved = clamp(concern.resolved + gained, 0.0, 1.0)
        delta += concern.severity * gained * 0.45
    delta = min(delta, MAX_GAIN_PER_REVIEW)
    if review.persona == "delve":
        delta *= 0.3  # 大模型代写的审稿人基本不看 rebuttal
    new_score = clamp(review.score + delta, 1.0, 10.0)
    change = new_score - review.score
    _set_reply(sub, review, new_score)
    if ri not in plan.done:
        plan.done.append(ri)
    return {"review": ri, "delta": change, "reply": review.reply, "notes": notes, "flagged": flagged}


FOLLOWUP_FACTOR = 0.75  # 回应追问时对方更挑剔


def followup(gs, sub, plan, ri):
    """审稿人看完回应后要不要追问：返回要追问的意见下标，或 None。
    没被说服（维持或下调）且还有没解决的意见时才追问；Reviewer #2 只要有没解决的就追问。
    时间不够回应时不追问（追问了也接不住，只会让玩家难受）。"""
    _ensure(plan)
    review = sub.reviews[ri]
    if review.persona == "delve" or plan.days_left() < 0.5:
        return None
    if review.reply == "raise" and review.persona != "rev2":
        return None
    open_ = [(c.severity * (1 - c.resolved), ci) for ci, c in enumerate(review.concerns) if c.resolved < 0.6]
    if not open_:
        return None
    return max(open_)[1]


def answer_followup(gs, sub, plan, ri, ci, card_id):
    """用一张卡回应追问。返回结果 dict（和 resolve_review 相同格式）。"""
    _ensure(plan)
    rng = gs.rng()
    paper = gs.paper(sub.paper_id)
    review = sub.reviews[ri]
    concern = review.concerns[ci]
    card = CARDS[card_id]
    plan.extra.append(card_id)
    gs.add_compute(-card["compute"])
    gs.add_san(card["san"])
    notes = []
    eff, extra = _card_effect(gs, paper, review, concern, card_id, rng, notes)
    gained = (1.0 - concern.resolved) * eff * FOLLOWUP_FACTOR
    concern.resolved = clamp(concern.resolved + gained, 0.0, 1.0)
    delta = min(concern.severity * gained * 0.45 + extra, MAX_GAIN_PER_REVIEW * 0.5)
    new_score = clamp(review.score + delta, 1.0, 10.0)
    change = new_score - review.score
    _set_reply(sub, review, new_score)
    return {"review": ri, "delta": change, "reply": review.reply, "notes": notes, "flagged": False}


def followup_usable(gs, plan, sub, ri, card_id):
    """回应追问时能不能出这张卡（时间、算力、对象）。"""
    card = CARDS[card_id]
    if not card_usable(gs, sub, sub.reviews[ri], card_id) or card_id == "flag_llm":
        return False
    return plan.days_left() + 1e-9 >= card["days"] and gs.compute + 1e-9 >= card["compute"]


def resolve(gs, sub, plan):
    """一次性结算所有还没结算的审稿人（“交给导师处理”和平衡模拟用）。返回结果列表。"""
    _ensure(plan)
    results = rlist()
    for ri in range(len(sub.reviews)):
        if ri in plan.done:
            continue
        results.append(resolve_review(gs, sub, plan, ri))
    finish(sub, plan)
    return results


def finish(sub, plan):
    if plan.round_no >= data.VENUES[sub.venue]["rebuttal_rounds"]:
        sub.rebuttal_done = True


def duel_order(sub):
    """对线顺序：普通审稿人先，代写的戴尔夫其次，Reviewer #2 压轴。"""
    rank = {"normal": 0, "delve": 1, "rev2": 2}
    return sorted(range(len(sub.reviews)), key=lambda i: (rank[sub.reviews[i].persona], i))


def display_score(venue, score):
    from .review import display_score as _ds

    return _ds(venue, score)


def concern_name(kind):
    from .review import CONCERN_NAMES

    return CONCERN_NAMES.get(kind, kind)


def auto_plan(gs, sub, round_no=1):
    """简单的自动分配策略：给平衡模拟和“交给导师处理”按钮用。"""
    plan = RebuttalPlan(sub, round_no)
    best = {
        "missing_baseline": "experiment",
        "missing_ablation": "experiment",
        "weak_results": "experiment",
        "need_theory": "theory",
        "unclear_writing": "clarify",
        "limited_novelty": "clarify",
        "overclaim": "concede",
        "reproducibility": "clarify",
        "cite_me": "cite",
        "buried_contribution": "clarify",
    }
    items = []
    for ri, r in enumerate(sub.reviews):
        for ci, c in enumerate(r.concerns):
            if c.resolved < 0.9:
                items.append((c.severity, ri, ci, c.kind, r.persona))
    items.sort(reverse=True)
    for sev, ri, ci, kind, persona in items:
        card = "flag_llm" if persona == "delve" else best.get(kind, "concede")
        ok, _ = set_card(gs, plan, sub, ri, ci, card)
        if not ok:
            set_card(gs, plan, sub, ri, ci, "concede")
    return plan
