"""AI 帮手：ChatGPT 和 Claude。

日程本里每个工作周可以贴一张“帮手贴纸”，选其中一位的某个形态。日程里存成 (行动, 形态 id)。
  * 额度：两家各一份，每月刷新。形态越大越强，也越费额度。
  * ChatGPT：推公式最强；但她经手写过的稿子会叠上一层“防御性措辞”（Paper.hedge），
    审稿时创新和热度打折，还容易收到“看不出贡献”。
  * ChatGPT 还会“降智”：这个月的额度用掉 60% 以后，之后每次帮忙的效果都打对折（Claude 不会）。
  * Claude：写论文、写代码最强；但每次使用都有概率被封号，停用几周。
  * 亲笔率：每篇论文记下工作周数和用了帮手的周数，结局里统计。
设定见 CHARACTERS_AI.md 2.9–2.11、4.6。
"""

from . import data
from .compat import rlist
from .state import HEDGE_PENALTY_MAX, clamp

FAMILIES = {
    "chatgpt": {"name": "ChatGPT", "forms": ("luna", "terra", "sol", "astra"), "default": "sol"},
    "claude": {"name": "Claude", "forms": ("haiku", "sonnet", "opus", "fable"), "default": "sonnet"},
}

# power：帮忙的力度；cost：每次用掉的额度；spec：特别擅长的行动（力度再 ×SPEC_BONUS）
FORMS = {
    "luna": dict(family="chatgpt", name="Luna", power=0.35, cost=8, spec=None, desc="最快、最便宜"),
    "terra": dict(family="chatgpt", name="Terra", power=0.6, cost=18, spec="experiment", desc="会看图、会操作电脑：跑实验更顺手"),
    "sol": dict(family="chatgpt", name="Sol", power=0.75, cost=25, spec=None, desc="日常主力"),
    "astra": dict(family="chatgpt", name="Astra", power=1.0, cost=45, spec="theory", desc="旗舰：推公式最强，也最不说人话"),
    "haiku": dict(family="claude", name="Haiku", power=0.35, cost=8, spec=None, desc="最快、最便宜，话最少"),
    "sonnet": dict(family="claude", name="Sonnet", power=0.65, cost=20, spec="experiment", desc="日常主力，代码写得好"),
    "opus": dict(family="claude", name="Opus", power=0.85, cost=30, spec=None, desc="可靠、深思，性价比高"),
    "fable": dict(family="claude", name="Fable", power=1.05, cost=50, spec="write", desc="最强也最贵：能一个人连着干很久"),
}
FORM_ORDER = ("luna", "terra", "sol", "astra", "haiku", "sonnet", "opus", "fable")
SPEC_BONUS = 1.3

HELPABLE = ("read", "experiment", "theory", "write")
# 每家对每种行动的帮助，乘在主属性增益上：1 + 系数 × 力度。ChatGPT 写论文是负的——她不说人话。
EFFECT = {
    "chatgpt": {"read": 0.25, "experiment": 0.2, "theory": 0.65, "write": -0.35},
    "claude": {"read": 0.25, "experiment": 0.45, "theory": 0.25, "write": 0.6},
}

QUOTA = 100  # 每月额度
BAN_CHANCE = 0.4  # 每用一次 Claude 被封的概率
SHARED_BAN_MULT = 2.0  # 借了共享号以后更容易被封
BAN_WEEKS = (3, 5)
AUTO_BAN_AFFINITY = 22  # 好感到这里还没被封过，就封一次（她路线里的冲突）
ICLR_DEADLINE_WEEK = 4  # 截稿前用过她，就在截稿那周被封（最痛的时机）

HEDGE_MAX = 60.0
OWN_WRITE_UNHEDGE = 5.0  # 自己写一周，删掉一点防御性措辞

DUMB_QUOTA_USED = 0.6  # ChatGPT 本月额度用掉这么多以后就降智
DUMB_FACTOR = 0.5  # 降智后帮忙的力度打对折

REBUTTAL_COST = 15
DUTY_COST = 10


# ---------------------------------------------------------------------------
# 查询
# ---------------------------------------------------------------------------
def family_of(form):
    return FORMS[form]["family"]


def label(form):
    """「ChatGPT · Sol」"""
    return "%s · %s" % (FAMILIES[family_of(form)]["name"], FORMS[form]["name"])


def hedge(paper):
    return getattr(paper, "hedge", 0.0)


def hedge_penalty(paper):
    return min(HEDGE_PENALTY_MAX, hedge(paper) / 100.0)


def is_banned(gs):
    return gs.week < gs.ban_until


def ban_weeks_left(gs):
    return max(0, gs.ban_until - gs.week)


def available(gs, form, cost=None):
    """这个形态现在能不能用：返回 (能不能, 原因)。"""
    fam = family_of(form)
    if not gs.met.get(fam):
        return False, "还没认识%s" % FAMILIES[fam]["name"]
    if fam == "claude" and is_banned(gs):
        return False, "Claude 的账号被停用了"
    need = FORMS[form]["cost"] if cost is None else cost
    if gs.quota[fam] < need:
        return False, "%s 本月额度不够了" % FAMILIES[fam]["name"]
    return True, ""


def is_dumb(gs):
    """ChatGPT 这个月是不是已经被用到降智了：额度用掉 60% 以上。"""
    return QUOTA - gs.quota["chatgpt"] >= QUOTA * DUMB_QUOTA_USED - 1e-9


def family_ready(gs, fam, cost):
    """不挑形态，只看这一家现在能不能帮一次小忙（rebuttal、审稿用）。"""
    if not gs.met.get(fam):
        return False
    if fam == "claude" and is_banned(gs):
        return False
    return gs.quota[fam] >= cost


def helped(paper, fam):
    return fam in getattr(paper, "helped_by", ())


# ---------------------------------------------------------------------------
# 每周
# ---------------------------------------------------------------------------
def weekly(gs):
    """每周开始时调用：月初刷新额度、封号到期解封、剧情里的封号。"""
    month = data.week_to_date(gs.week)[1]
    if month != gs.quota_month:
        gs.quota_month = month
        for fam in FAMILIES:
            gs.quota[fam] = QUOTA
    if gs.has("claude_is_banned") and not is_banned(gs):
        gs.flag("claude_is_banned", False)
        gs.flag("claude_back")
    if gs.met.get("claude") and not gs.has("claude_banned_once"):
        iclr = gs.week == ICLR_DEADLINE_WEEK and gs.has("claude_used")
        if iclr or gs.affinity["claude"] >= AUTO_BAN_AFFINITY:
            ban(gs, gs.rng())
            if iclr:
                gs.flag("claude_ban_iclr")


def ban(gs, rng):
    gs.ban_until = gs.week + rng.randint(*BAN_WEEKS)
    gs.flag("claude_is_banned")
    if gs.has("claude_banned_once"):
        gs.flag("ban_notice")  # 第二次以后：下周开头一小段（on_ban）
    else:
        gs.flag("claude_banned_once")
        gs.flag("claude_ban_pending")  # 第一次：她路线里的冲突 claude_banned


def roll_ban(gs, rng):
    chance = BAN_CHANCE * (SHARED_BAN_MULT if gs.has("shared_account") else 1.0)
    if rng.random() < chance:
        ban(gs, rng)
        return True
    return False


def lift_ban(gs):
    """借共享号：马上能用，但以后更容易被封。"""
    gs.ban_until = gs.week
    gs.flag("claude_is_banned", False)
    gs.flag("shared_account")


def _spend(gs, fam, cost):
    gs.quota[fam] = max(0, gs.quota[fam] - cost)
    gs.add_affinity(fam, 1.5)
    if fam == "claude":
        gs.flag("claude_used")


# ---------------------------------------------------------------------------
# 工作周
# ---------------------------------------------------------------------------
def begin(gs, action, form, rng):
    """工作周开始前调用。返回帮手上下文 dict（mult = 主属性增益倍率），用不了时 ok=False 并附原因。"""
    if not form or form not in FORMS or action not in HELPABLE:
        return None
    ok, why = available(gs, form)
    if not ok:
        return {"ok": False, "form": form, "mult": 1.0, "lines": ["（%s，这周只能自己来）" % why]}
    f = FORMS[form]
    fam = f["family"]
    power = f["power"] * (SPEC_BONUS if f["spec"] == action else 1.0)
    dumb = fam == "chatgpt" and is_dumb(gs)
    if dumb:
        power *= DUMB_FACTOR
    _spend(gs, fam, f["cost"])
    h = {"ok": True, "form": form, "family": fam, "power": power, "banned": False, "dumb": dumb, "lines": []}
    if dumb:
        gs.flag("gpt_dumb_seen")
        h["lines"].append("（%s 降智了：这个月找她的次数太多，今天的回答像是换了一个人）" % f["name"])
    if fam == "claude" and roll_ban(gs, rng):
        h["banned"] = True
        h["mult"] = 1.0
        h["lines"].append("（%s 写到一半，账号被停用了。这周的活只能你自己收尾）" % f["name"])
        return h
    h["mult"] = max(0.3, 1.0 + EFFECT[fam][action] * power)
    return h


def finish(gs, paper, action, h, lines):
    """工作周结算后调用：防御性措辞、额外进度、亲笔率计数。h 可以是 None（没用帮手）。"""
    if paper is None:
        return
    if action in HELPABLE + ("crunch",):
        paper.work_weeks = getattr(paper, "work_weeks", 0) + 1
    if not h or not h["ok"]:
        if action == "write" and hedge(paper) > 0:
            paper.hedge = max(0.0, hedge(paper) - OWN_WRITE_UNHEDGE)
        if h:
            lines.extend(h["lines"])
        return
    paper.ai_weeks = getattr(paper, "ai_weeks", 0) + 1
    fam, power, name = h["family"], h["power"], FORMS[h["form"]]["name"]
    if not hasattr(paper, "helped_by"):
        paper.helped_by = rlist()
    if fam not in paper.helped_by:
        paper.helped_by.append(fam)
        if len(paper.helped_by) == 2:
            gs.flag("both_helped")
    lines.extend(h["lines"])
    if h["banned"]:
        return
    cost = FORMS[h["form"]]["cost"]
    if fam == "chatgpt":
        if action == "write":
            extra = 8.0 * power
            paper.progress = clamp(paper.progress + extra, 0, 100)
            paper.hedge = min(HEDGE_MAX, hedge(paper) + 6.0 + 8.0 * power)
            lines.append("（%s 帮你写了一大段：完成度又 +%.0f，但通篇都是“可能”“在一定条件下”）" % (name, extra))
        elif action == "theory":
            paper.hedge = min(HEDGE_MAX, hedge(paper) + 2.0 * power)
            lines.append("（%s 一晚上就推完了。证明后面附了十一个脚注）" % name)
        else:
            lines.append("（%s 帮了一周的忙）" % name)
    else:
        if action == "write":
            removed = min(hedge(paper), 12.0 * power)
            paper.hedge = hedge(paper) - removed
            extra = 4.0 * power + (6.0 if h["form"] == "fable" else 0.0)
            paper.progress = clamp(paper.progress + extra, 0, 100)
            if removed >= 1:
                lines.append("（%s 帮你改了一遍：读起来顺多了，还顺手删掉了 %.0f 处防御性措辞）" % (name, removed))
            else:
                lines.append("（%s 帮你改了一遍：读起来顺多了）" % name)
        elif action == "experiment":
            refund = round(data.EXPERIMENT_COMPUTE_COST * 0.35 * power)
            gs.add_compute(refund)
            lines.append("（%s 重写了实验脚本，省下 %d 算力）" % (name, refund))
        else:
            lines.append("（%s 帮了一周的忙）" % name)
    lines.append("（%s 额度 -%d）" % (FAMILIES[fam]["name"], cost))


# ---------------------------------------------------------------------------
# rebuttal 与审稿
# ---------------------------------------------------------------------------
def use_small(gs, fam, rng, cost):
    """rebuttal / 审稿时请她帮一次小忙。返回 True = 帮成了；False = 用不了或被封了。
    ChatGPT 降智与否要在调用之前用 is_dumb() 看（这一次花的额度也算进去）。"""
    if not family_ready(gs, fam, cost):
        return False
    _spend(gs, fam, cost)
    if fam == "claude" and roll_ban(gs, rng):
        return False
    return True


# ---------------------------------------------------------------------------
# 亲笔率
# ---------------------------------------------------------------------------
def own_paper(paper):
    """这篇算不算你自己写的：用了帮手的周不到一半。"""
    work = getattr(paper, "work_weeks", 0)
    return work == 0 or getattr(paper, "ai_weeks", 0) * 2 < work


def pen_stats(gs):
    work = sum(getattr(p, "work_weeks", 0) for p in gs.papers)
    ai = sum(getattr(p, "ai_weeks", 0) for p in gs.papers)
    ratio = None if work == 0 else 1.0 - float(ai) / work
    letters = len(gs.submissions)
    own = sum(1 for s in gs.submissions if own_paper(gs.paper(s.paper_id)))
    if ratio is None:
        title = None
    elif ratio >= 0.7:
        title = "亲笔"
    elif ratio <= 0.3:
        title = "代笔"
    else:
        title = None
    return {"ratio": ratio, "letters": letters, "own": own, "title": title, "ai_weeks": ai, "work_weeks": work}
