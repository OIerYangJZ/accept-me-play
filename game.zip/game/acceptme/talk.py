"""去见刊娘时选聊什么（没有触发剧情事件的普通拜访）。

三个话题：聊你的研究 / 聊聊她的事 / 请教投稿。每位刊娘对三个话题的喜好不同，
选对了好感涨得多；她的反应台词会透露喜好，玩家可以慢慢摸清。
“请教投稿”除了好感，还会带来一点和她的会议口味相关的实际好处。
同一个话题连着聊两次，她会觉得有点腻，效果打折。
"""

from . import data

TOPICS = {
    "research": "聊聊你的研究",
    "her": "聊聊她的事",
    "advice": "请教投稿的事",
}
TOPIC_ORDER = ("research", "her", "advice")

# 每位刊娘：最喜欢 / 一般 / 不太感兴趣
PREFS = {
    "kiwi": ("her", "research", "advice"),
    "clair": ("advice", "research", "her"),
    "aceline": ("her", "advice", "research"),
    "iris": ("research", "her", "advice"),
    "imel": ("research", "advice", "her"),
    "neuri": ("her", "advice", "research"),
    "closia": ("her", "research", "advice"),
    "natalie": ("research", "her", "advice"),
    "chatgpt": ("research", "her", "advice"),
    "claude": ("advice", "research", "her"),
}
TIER_GAIN = {"like": 9.0, "ok": 5.0, "cool": 2.0}
REPEAT_FACTOR = 0.5  # 连着聊同一个话题

# “请教投稿”的实际好处：(说明, 效果)。效果作用在当前课题上（没有课题时退化成 SAN）。
ADVICE = {
    "kiwi": ("热度 +5", {"hype": 5}),
    "clair": ("表达 +4", {"clarity": 4}),
    "aceline": ("表达 +5", {"clarity": 5}),
    "iris": ("实验结果 +4", {"sota": 4}),
    "imel": ("严谨 +5", {"rigor": 5}),
    "neuri": ("热度 +4，创新 +2", {"hype": 4, "novelty": 2}),
    "closia": ("算力 +40", {"compute": 40}),
    "natalie": ("创新 +4", {"novelty": 4}),
    "chatgpt": ("严谨 +5", {"rigor": 5}),
    "claude": ("表达 +5", {"clarity": 5}),
}


def tier(heroine, topic):
    like, ok, _cool = PREFS[heroine]
    return "like" if topic == like else "ok" if topic == ok else "cool"


def talk(gs, heroine, topic):
    """结算一次聊天。返回 dict(tier=, repeat=, gain=, lines=[结果说明])。"""
    rng = gs.rng()
    t = tier(heroine, topic)
    repeat = gs.last_topic.get(heroine) == topic
    gain = TIER_GAIN[t] * rng.uniform(0.85, 1.15)
    if repeat:
        gain *= REPEAT_FACTOR
    if gs.low_san:
        gain *= 0.7
    gs.add_affinity(heroine, gain)
    gs.met[heroine] = True
    gs.add_san(5)
    gs.last_topic[heroine] = topic
    lines = ["%s好感 +%.0f" % (data.HEROINES[heroine]["name"], gain)]

    if topic == "advice":
        desc, eff = ADVICE[heroine]
        paper = gs.current_paper
        has_paper = paper is not None and paper.status in ("draft", "rejected")
        if "compute" in eff:
            gs.add_compute(eff["compute"])
        elif has_paper:
            for k, v in eff.items():
                paper.attrs[k] = min(100.0, paper.attrs[k] + v)
        else:
            desc = "SAN +3"  # 手上没有课题，建议用不上，聊得开心
            gs.add_san(3)
        lines.append(desc)
    return {"tier": t, "repeat": repeat, "gain": gain, "lines": lines}
