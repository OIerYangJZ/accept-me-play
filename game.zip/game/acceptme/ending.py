"""第一学年结算。"""

from . import data, helpers

ROUTE_FINALE = {
    "kiwi": "kiwi_heart",
    "clair": "clair_secret",
    "aceline": "aceline_letter",
    "iris": "iris_photo",
    "imel": "imel_alone",
    "neuri": "neuri_backstage",
    "closia": "closia_unveil",
    "natalie": "natalie_window",
    "chatgpt": "gpt_plain_words",
    "claude": "claude_mythos",
}
ROUTE_MIN_AFFINITY = 50
LOVER_MIN_AFFINITY = 58
# 恋人结局需要至少一个“关键选择”（冲突、约定里那些更走心的选择，见 STORY_V2.md）
ROUTE_KEY_FLAGS = {
    "kiwi": ("kiwi_stay_open", "kiwi_failure", "kiwi_read_fail"),
    "clair": ("clair_faced", "clair_promise", "clair_report_yes"),
    "aceline": ("aceline_honest", "aceline_linguistics", "aceline_dialect_word"),
    "iris": ("iris_checklist", "iris_why", "iris_wait"),
    "imel": ("imel_private", "imel_lantern", "imel_coauthor"),
    "neuri": ("neuri_rest", "neuri_stay"),
    "closia": ("closia_no_nda", "closia_nda_amended", "closia_open", "closia_card_honest"),
    "natalie": ("natalie_answer", "natalie_letter_answer", "natalie_desk_honest"),
    "chatgpt": ("gpt_thanks", "gpt_plain", "gpt_found_bug"),
    "claude": ("claude_learned", "claude_wrote_myself", "claude_wait_yes"),
}


def is_lover(gs, h):
    return gs.affinity[h] >= LOVER_MIN_AFFINITY and any(gs.has(f) for f in ROUTE_KEY_FLAGS[h])


def reviewer_title(gs):
    k = gs.karma
    if k["harsh"] >= 2 and k["harsh"] >= k["careful"]:
        return "Reviewer #2 预备役"
    if k["llm"] >= 2 and k["llm"] >= k["careful"]:
        return "戴尔夫的同类"
    if k["careful"] >= 2:
        return "温柔的审稿人"
    return "还没想好要成为什么样的审稿人"


def route_heroine(gs):
    best, best_aff = None, -1
    for h in data.HEROINE_ORDER:
        aff = gs.affinity[h]
        if aff >= ROUTE_MIN_AFFINITY and gs.seen_events.get(ROUTE_FINALE[h]) is not None and aff > best_aff:
            best, best_aff = h, aff
    return best


def summary(gs):
    accepted = gs.accepted_papers()
    route = route_heroine(gs)
    if gs.san_breakdowns >= 2:
        ending = "rest_end"
    elif route:
        ending = route + ("_end" if is_lover(gs, route) else "_friend_end")
    else:
        ending = "normal_end"
    return {
        "ending": ending,
        "route": route,
        "accepted": [(p.title, [h[0] for h in p.history if h[1] == "accept"]) for p in accepted],
        "submissions": len(gs.submissions),
        "rejections": sum(1 for s in gs.submissions if s.outcome == "reject"),
        "reputation": round(gs.reputation),
        "title": reviewer_title(gs),
        "top_affinity": sorted(((gs.affinity[h], h) for h in data.HEROINE_ORDER), reverse=True)[:3],
        "pen": helpers.pen_stats(gs),
    }
