"""《Accept Me!》核心逻辑。不依赖 Ren'Py，可以单独测试。"""

from . import actions, data, ending, events, rebuttal, review, sim  # noqa: F401
from .state import GameState, Paper, Submission  # noqa: F401
