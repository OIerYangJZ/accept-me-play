"""自动游玩策略：给平衡模拟（tools/balance.py）和 Ren'Py 自动化测试（game/testcases.rpy）共用。

正常游戏中不会用到这里的任何东西。
"""

from . import actions, data, events, helpers

# Ren'Py 开新游戏时会重置 store，所以测试参数放在模块里传递。
CONFIG = {"seed": 1, "policy": "romantic"}


# 自动游玩时，工作周偶尔请 AI 帮手（按行动挑最合适、现在用得上的形态）
HELPER_RATE = 0.35
HELPER_PREFS = {
    "theory": ("astra", "sol", "opus", "luna"),
    "write": ("opus", "sonnet", "fable", "haiku"),
    "experiment": ("sonnet", "terra", "haiku"),
    "read": ("luna", "haiku"),
}


def choose_helper(gs, act, rng):
    if act not in HELPER_PREFS or rng.random() >= HELPER_RATE:
        return None
    for f in HELPER_PREFS[act]:
        if helpers.available(gs, f)[0]:
            return f
    return None


def choose_action(gs, policy, rng):
    """返回 (action, target)。action 可能是 "start" 表示先开始新课题；工作周的 target 是 AI 帮手形态或 None。"""
    act, target = _choose_action(gs, policy, rng)
    if target is None and act in HELPER_PREFS:
        target = choose_helper(gs, act, rng)
    return act, target


def _choose_action(gs, policy, rng):
    paper = gs.current_paper
    avail = {a: ok for a, ok, _ in actions.available_actions(gs)}
    if gs.san < 30:
        return "rest", None
    if paper is not None and paper.status == "rejected" and paper.travel >= 3:
        paper = None  # 环游太多次，放弃
        gs.active_paper = None
    if paper is None or paper.status not in ("draft", "rejected") or gs.paper_under_review(paper.id):
        if actions.can_start_paper(gs):
            return "start", None
        return "read", None
    if avail["crunch"] and paper.progress < 90 and policy != "slacker":
        return "crunch", None
    if policy == "romantic" and rng.random() < 0.35 and events.visitable_heroines(gs):
        return "social", rng.choice(events.visitable_heroines(gs))
    if avail.get("promote") and paper.progress >= 50 and paper.attrs["hype"] < 25 and rng.random() < 0.3:
        return "promote", None
    if policy == "slacker" and rng.random() < 0.3:
        return "rest", None
    # 补最弱的属性
    order = sorted(("sota", "rigor", "clarity", "novelty"), key=lambda a: paper.attrs[a])
    for a in order:
        act = {"sota": "experiment", "rigor": "theory", "clarity": "write", "novelty": "read"}[a]
        if avail.get(act):
            if act != "write" and paper.progress < 100 and rng.random() < 0.3:
                return "write", None
            return act, None
    return "write", None


def choose_topic(gs, rng):
    return rng.choice(data.TRACKS[gs.track]["topics"])


def wants_to_submit(gs, paper, venue):
    home = venue in data.TRACKS[gs.track]["home"]
    fit = data.TOPICS[paper.topic]["fit"].get(venue, 0.8)
    return (home and paper.progress >= 85) or (paper.travel >= 1 and fit >= 0.9) or venue == "nature"
