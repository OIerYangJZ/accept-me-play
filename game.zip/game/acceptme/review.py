"""审稿模拟：生成审稿人、打分、提出意见，以及 AC 的最终决定。

内部统一使用 10 分制；展示给玩家时再按会议的分数档换算（见 display_score）。
"""

from . import data
from .compat import Base, rlist
from .state import Submission, clamp

PERSONAS = ("normal", "rev2", "delve")

# 哪个属性弱会引出哪类意见
ATTR_CONCERNS = {
    "sota": ("missing_baseline", "weak_results"),
    "novelty": ("limited_novelty",),
    "clarity": ("unclear_writing",),
    "rigor": ("need_theory", "missing_ablation"),
}
CONCERN_NAMES = {
    "missing_baseline": "缺少基线对比",
    "limited_novelty": "创新性有限",
    "unclear_writing": "写作不清楚",
    "need_theory": "缺乏理论分析",
    "missing_ablation": "缺少消融实验",
    "cite_me": "要求引用文献",
    "weak_results": "提升太小",
    "overclaim": "结论夸大",
    "reproducibility": "可复现性存疑",
    "buried_contribution": "看不出贡献",
}
HEDGE_CONCERN_MIN = 10.0  # 防御性措辞到这个程度，审稿人开始找不到贡献在哪


class Concern(Base):
    def __init__(self, kind, severity):
        self.kind = kind
        self.severity = severity  # 这条意见让分数掉了多少（10 分制）
        self.resolved = 0.0  # 0~1


NORMAL_NUMBERS = (1, 4, 5, 6, 7, 8)


class Review(Base):
    def __init__(self, idx, persona, score):
        self.idx = idx
        self.persona = persona
        self.score = score  # 内部 10 分制
        self.initial_score = score
        self.concerns = rlist()
        self.weight = 1.0  # AC 对这份意见的采信程度（举报大模型代写后会降低）
        self.reply = None  # rebuttal 后的态度：raise / keep / lower
        self.confidence = 3
        self.normal_rank = 0  # 在普通审稿人中的序号，用于显示编号

    @property
    def name(self):
        # #2 和 #3 永远留给 Reviewer #2 与戴尔夫；普通审稿人用其余编号
        if self.persona == "rev2":
            return "Reviewer #2"
        if self.persona == "delve":
            return "Reviewer #3"
        return "Reviewer #%d" % NORMAL_NUMBERS[self.normal_rank]


def base_quality(paper, venue):
    """论文在某会议眼中的基础质量 0~100。"""
    cfg = data.VENUES[venue]
    w = cfg["weights"]
    total = sum(w.values())
    q = sum(paper.effective(a) * w[a] for a in data.ATTRS) / total
    q *= data.TOPICS[paper.topic]["fit"].get(venue, 0.8)
    if paper.scooped:
        q *= 0.8
    return clamp(q, 0, 100)


def quality_to_score(q):
    """质量 0~100 -> 10 分制。质量 60 左右大约是“接收线”附近。"""
    return 1.0 + 9.0 * (q / 100.0) ** 0.9


def display_score(venue, score):
    """把内部 10 分制换算成会议的分数档（取最接近的一档）。"""
    cfg = data.VENUES[venue]
    scale = cfg["scale"]
    if cfg.get("scale_from_ten"):
        lo, hi = scale[0], scale[-1]
        target = lo + (score - 1.0) / 9.0 * (hi - lo)
    else:
        target = score
    return min(scale, key=lambda s: abs(s - target))


def _pick_personas(gs, paper, venue, n, rng):
    personas = ["normal"] * n
    p_rev2 = 0.35 + 0.2 * min(paper.travel, 2)
    slots = list(range(n))
    rng.shuffle(slots)
    if rng.random() < p_rev2:
        personas[slots.pop()] = "rev2"
    if rng.random() < 0.3 and slots:
        personas[slots.pop()] = "delve"
    return personas


def _concerns_for(paper, venue, persona, deficit_score, rng, code_open=False):
    """根据最弱的属性生成 1~3 条意见，并把总扣分 deficit_score 分摊到各条意见上。"""
    cfg = data.VENUES[venue]
    weak = sorted(ATTR_CONCERNS, key=lambda a: paper.effective(a) * cfg["weights"][a] / sum(cfg["weights"].values()))
    kinds = []
    for a in weak[:2]:
        kinds.append(rng.choice(ATTR_CONCERNS[a]))
    quality = (paper.attrs["sota"] + paper.attrs["rigor"] + paper.attrs["novelty"]) / 3.0
    if paper.attrs["hype"] > quality + 15 or paper.water > 8:
        kinds.append("overclaim")
    if rng.random() < 0.2 and not code_open:  # 代码开源了，就不会被质疑可复现性
        kinds.append("reproducibility")
    hedge = getattr(paper, "hedge", 0.0)
    if hedge >= HEDGE_CONCERN_MIN and rng.random() < min(0.85, hedge / 30.0):
        kinds.insert(0, "buried_contribution")  # ChatGPT 的防御性措辞把亮点埋住了
    if persona == "rev2":
        kinds.insert(0, "cite_me")
    if persona == "delve":
        pool = [k for k in CONCERN_NAMES if not (code_open and k == "reproducibility")]
        kinds = [rng.choice(pool)] + kinds[:1]

    seen = []
    for k in kinds:
        if k not in seen:
            seen.append(k)
    kinds = seen[:3]

    weights = [rng.uniform(0.6, 1.4) for _ in kinds]
    wsum = sum(weights)
    out = rlist()
    for k, wt in zip(kinds, weights):
        sev = max(0.3, deficit_score * wt / wsum)
        if k == "cite_me":
            sev = max(sev, 1.0)
        out.append(Concern(k, round(sev, 2)))
    return out


def generate_reviews(gs, sub):
    """为一次投稿生成全部审稿意见。"""
    paper = gs.paper(sub.paper_id)
    venue = sub.venue
    cfg = data.VENUES[venue]
    rng = gs.rng()
    q = base_quality(paper, venue)
    ideal = quality_to_score(q)
    personas = _pick_personas(gs, paper, venue, cfg["reviewers"], rng)
    reviews = rlist()
    for i, persona in enumerate(personas):
        if persona == "normal":
            s = ideal + rng.gauss(0, cfg["sigma"])
        elif persona == "rev2":
            s = ideal - 1.6 + rng.gauss(0, cfg["sigma"] * 0.6)
        else:  # delve：大模型代写，分数和论文质量关系不大
            s = 0.3 * ideal + 0.7 * rng.uniform(4.5, 6.5)
        s = clamp(s, 1.0, 10.0)
        r = Review(i, persona, s)
        r.confidence = rng.choice((2, 3, 3, 4, 4, 5)) if persona != "rev2" else 5
        # “满分”与实际分数之间的差距，就是这位审稿人意见的总分量
        deficit = clamp(8.0 - s, 0.6, 4.0)
        r.concerns = _concerns_for(paper, venue, persona, deficit, rng, gs.has('code_open'))
        reviews.append(r)
    rank = 0
    for r in reviews:
        if r.persona == "normal":
            r.normal_rank = rank
            rank += 1
    sub.reviews = reviews
    sub.status = "reviewed"
    gs.flag(venue + "_reviewed")
    if any(r.persona == "delve" for r in reviews):
        gs.flag("met_delve")
    if any(r.persona == "rev2" for r in reviews):
        gs.flag("met_rev2")
        if paper.travel >= 1 and rng.random() < 0.5:
            sub.rev2_recognized = True
    return reviews


def desk_check(gs, sub):
    """期刊的编辑初筛（管家温斯顿）。返回 True = 送审。"""
    paper = gs.paper(sub.paper_id)
    impact = (paper.effective("novelty") * 1.3 + paper.effective("sota") + paper.effective("hype") * 0.5) / 2.8
    if paper.topic != "ai4science":
        impact *= 0.6
    return impact >= 62


def mean_score(sub):
    total_w = sum(r.weight for r in sub.reviews)
    if total_w == 0:
        return 0.0
    return sum(r.score * r.weight for r in sub.reviews) / total_w


def decide(gs, sub):
    """AC 最终决定。返回 'accept' / 'reject'。"""
    cfg = data.VENUES[sub.venue]
    rng = gs.rng()
    heroine = cfg["heroine"]
    bonus = 0.4 * gs.affinity.get(heroine, 0) / 100.0 if heroine else 0.0
    if gs.has("ac_tip"):
        bonus += 0.1  # 艾茜说过：AC 只想看到你真的听懂了审稿人
    score = mean_score(sub) + bonus + rng.gauss(0, cfg["ac_sigma"])
    sub.final_score = round(score, 2)
    sub.outcome = "accept" if score >= cfg["bar"] else "reject"
    sub.status = "decided"
    return sub.outcome


def submit(gs, paper, venue):
    sub = Submission(gs.new_id(), paper.id, venue, gs.week)
    paper.status = "review"
    gs.submissions.append(sub)
    gs.note("《%s》投给了 %s" % (paper.title, data.VENUES[venue]["name"]))
    if data.VENUES[venue]["kind"] == "conference":
        # 互审义务：在审稿期内要审别人的稿
        gs.duties.append((gs.week + max(2, data.VENUES[venue]["review_delay"] - 3), venue))
    return sub


def apply_outcome(gs, sub):
    """把决定结果写回论文和角色好感。"""
    paper = gs.paper(sub.paper_id)
    heroine = data.VENUES[sub.venue]["heroine"]
    paper.history.append((sub.venue, sub.outcome, gs.week))
    if sub.outcome == "accept":
        paper.status = "accepted"
        gs.reputation += 10 + paper.attrs["hype"] / 10.0
        gs.add_san(20)
        if heroine:
            gs.add_affinity(heroine, 15)
        if gs.active_paper == paper.id:
            gs.active_paper = None
    else:
        paper.status = "rejected"
        paper.travel += 1
        # 审稿意见里总有点有用的东西
        for a in ("rigor", "clarity"):
            paper.attrs[a] = clamp(paper.attrs[a] + 4, 0, 100)
        gs.add_san(-15)
        if heroine:
            gs.add_affinity(heroine, 3)
        # 手上没有在写的稿子时，才把被拒的论文拿回来改
        cur = gs.current_paper
        if cur is None or cur.status != "draft":
            gs.active_paper = paper.id


def venues_open_for(gs, paper):
    """此刻这篇论文可以投的地方：本周截稿的会议 + 全年开放的期刊。"""
    out = []
    if not paper.submittable or gs.paper_under_review(paper.id):
        return out
    for v, cfg in data.VENUES.items():
        if gs.week in cfg["deadlines"]:
            out.append(v)
    if gs.has("nature_unlocked") and paper.topic == "ai4science":
        out.append("nature")
    return out
