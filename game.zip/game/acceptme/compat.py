"""Ren'Py 兼容层。

在 Ren'Py 中运行时，游戏状态必须使用 Revertable 容器，回滚（rollback）才能正确撤销状态修改；
在普通 Python（单元测试、平衡模拟）中运行时，退化为普通的 object / list / dict。

核心代码里所有存进游戏状态的容器，都必须通过这里的 RList / RDict 创建，不要直接写 [] 或 {}。
"""

try:  # pragma: no cover - 只在 Ren'Py 中走这个分支
    from renpy.revertable import RevertableObject as Base
    from renpy.revertable import RevertableList as RList
    from renpy.revertable import RevertableDict as RDict
except ImportError:  # 普通 Python 环境
    Base = object
    RList = list
    RDict = dict


def rlist(items=()):
    return RList(items)


def rdict(items=None, **kwargs):
    d = RDict()
    if items:
        d.update(items)
    d.update(kwargs)
    return d
