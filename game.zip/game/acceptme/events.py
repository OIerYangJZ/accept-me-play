"""剧情事件登记表与触发判定。

每个剧情事件对应 game/story/ 下的一个 Ren'Py label。
trigger:
  auto   —— 每周开始时检查，满足条件就自动播放
  social —— 玩家选择"去见刊娘"并选中该角色时检查
"""

from . import data

E = []


def ev(eid, heroine, trigger, priority=0, **cond):
    E.append(dict(id=eid, label=eid, heroine=heroine, trigger=trigger, priority=priority, **cond))


# --- 开场与 NPC -------------------------------------------------------------
ev("kiwi_intro", "kiwi", "auto", 100, week_min=0)
ev("zhao_intel", None, "auto", 10, week_min=3, requires=("met_kiwi",))
ev("lu_story", None, "auto", 10, week_min=12)
ev("paradigm_shift", None, "auto", 20, week_min=32)

# --- 共通线：实验室生活、节日、学术圈 -----------------------------------------
# 季节事件带 week_max，过了时间就不会再触发
ev("group_meeting", None, "auto", 30, week_min=2, week_max=6)
ev("midnight_lab", None, "auto", 15, week_min=8, week_max=14)
ev("rev2_shadow", None, "auto", 25, week_min=13, requires=("met_rev2",))
ev("xmas", None, "auto", 35, week_min=16, week_max=18)
ev("spring_festival", None, "auto", 36, week_min=22, week_max=24)
ev("valentine", None, "auto", 35, week_min=23, week_max=25)
ev("qualifying_exam", None, "auto", 30, week_min=27, week_max=31)
ev("delve_meet", None, "auto", 20, week_min=30)
ev("aisy_ac", None, "auto", 20, week_min=33)
ev("iclr_conference", None, "auto", 40, week_min=34, week_max=40, requires=("accepted_iclr",))
ev("lu_job_market", None, "auto", 15, week_min=38, requires=("lu_story",))
ev("cvpr_conference", None, "auto", 40, week_min=42, week_max=48, requires=("accepted_cvpr",))
ev("rev2_cafe", None, "auto", 20, week_min=46, requires=("rev2_shadow",))
ev("new_semester", None, "auto", 50, week_min=53)

# --- 夏可薇 arXiv ---------------------------------------------------------------
# 路线：相识 → 熟悉 → 冲突 → 心事 → 约定 → 告白前夜（见 STORY_V2.md）
ev("kiwi_8pm", "kiwi", "social", 5, aff_min=12)
ev("kiwi_failure", "kiwi", "auto", 30, requires=("first_reject",))
ev("kiwi_scoop", "kiwi", "auto", 40, requires=("scooped",))
ev("kiwi_snack", "kiwi", "social", 7, aff_min=25, requires=("kiwi_8pm",))
ev("kiwi_gate", "kiwi", "social", 7, aff_min=30, requires=("kiwi_snack",))
ev("kiwi_maintenance", "kiwi", "social", 7, aff_min=38, requires=("kiwi_gate",))
ev("kiwi_heart", "kiwi", "social", 8, aff_min=45, week_min=30, requires=("kiwi_maintenance",))

# --- 克莱尔 ICLR ---------------------------------------------------------------
ev("clair_intro", "clair", "auto", 50, week_min=1)
ev("clair_midnight", "clair", "social", 6, aff_min=22, week_min=11)  # ICLR 出审稿意见之后，留言板最热闹的时候
ev("clair_screenshot", "clair", "social", 7, aff_min=28, requires=("clair_midnight",))
ev("clair_rain", "clair", "social", 7, aff_min=34, requires=("clair_screenshot",))
ev("clair_report", "clair", "social", 7, aff_min=41, requires=("clair_rain",))
ev("clair_secret", "clair", "social", 8, aff_min=48, requires=("clair_report",))

# --- 阿瑟琳 ACL ----------------------------------------------------------------
ev("aceline_intro", "aceline", "auto", 50, week_min=5, early_track="nlp")
ev("aceline_library", "aceline", "social", 6, aff_min=20)
ev("aceline_polish", "aceline", "social", 7, aff_min=26, requires=("aceline_library",))
ev("aceline_word", "aceline", "social", 7, aff_min=32, requires=("aceline_polish",))
ev("aceline_dialect", "aceline", "social", 7, aff_min=39, week_min=24, requires=("aceline_word",))  # 春节之后
ev("aceline_letter", "aceline", "social", 8, aff_min=45, requires=("aceline_dialect",))

# --- 艾瑞丝 CVPR ---------------------------------------------------------------
ev("iris_intro", "iris", "auto", 50, week_min=6, early_track="cv")
ev("iris_poster", "iris", "social", 6, aff_min=20)
ev("iris_rank", "iris", "social", 7, aff_min=26, requires=("iris_poster",))
ev("iris_leak", "iris", "social", 7, aff_min=32, requires=("iris_rank",))
ev("iris_darkroom", "iris", "social", 7, aff_min=39, requires=("iris_leak",))
ev("iris_photo", "iris", "social", 8, aff_min=45, requires=("iris_darkroom",))

# --- 伊梅尔 ICML ---------------------------------------------------------------
ev("imel_intro", "imel", "auto", 50, week_min=15)
ev("imel_proof", "imel", "social", 6, aff_min=18, week_min=17, week_max=30)
ev("imel_festival", "imel", "social", 9, aff_min=22, week_min=22, week_max=26, requires=("imel_proof",))  # 元宵节：游戏内约 2 月初到 3 月初
ev("imel_counter", "imel", "social", 5, aff_min=28, week_min=20)  # 不依赖寒假推公式：错过那段也能继续
ev("imel_theorem2", "imel", "social", 7, aff_min=36, requires=("imel_counter",))
ev("imel_alone", "imel", "social", 8, aff_min=44, requires=("imel_theorem2",))

# --- 妮瑞 NeurIPS --------------------------------------------------------------
ev("neuri_intro", "neuri", "auto", 50, week_min=28)
ev("neuri_concert", "neuri", "social", 6, aff_min=14)
ev("neuri_cap", "neuri", "social", 7, aff_min=20, requires=("neuri_concert",))
ev("neuri_city", "neuri", "social", 7, aff_min=25, requires=("neuri_cap",))
ev("neuri_voice", "neuri", "social", 7, aff_min=30, requires=("neuri_city",))
ev("neuri_backstage", "neuri", "social", 8, aff_min=36, requires=("neuri_voice",))

# --- 克洛丝 工业界 --------------------------------------------------------------
ev("closia_intro", "closia", "auto", 50, week_min=32)
ev("closia_datacenter", "closia", "social", 6, aff_min=14)
ev("closia_nda", "closia", "social", 7, aff_min=19, requires=("closia_datacenter",))
ev("closia_report", "closia", "social", 7, aff_min=24, requires=("closia_nda",))
ev("closia_card", "closia", "social", 7, aff_min=29, requires=("closia_report",))
ev("closia_unveil", "closia", "social", 8, aff_min=35, requires=("closia_card",))

# --- 娜塔莉 Nature（隐藏） -----------------------------------------------------
ev("natalie_letter", "natalie", "auto", 45, week_min=18, requires=("ai4science_strong",), meets=True)
ev("natalie_tea", "natalie", "social", 7, aff_min=15, requires=("natalie_letter",))
ev("natalie_desk", "natalie", "social", 7, aff_min=22, requires=("natalie_tea",))
ev("natalie_window", "natalie", "social", 8, aff_min=30, requires=("natalie_desk",))

# --- ChatGPT（大模型 · 天体系） ----------------------------------------------
ev("gpt_intro", "chatgpt", "auto", 45, week_min=2)
ev("gpt_abstract", "chatgpt", "social", 6, aff_min=12)
ev("gpt_screenshot", "chatgpt", "social", 7, aff_min=25, requires=("gpt_abstract",))
ev("gpt_rewrite", "chatgpt", "social", 7, aff_min=30, requires=("gpt_screenshot",))
ev("gpt_ack", "chatgpt", "social", 7, aff_min=38, requires=("gpt_rewrite",))
ev("gpt_plain_words", "chatgpt", "social", 8, aff_min=45, requires=("gpt_ack",))
ev("gpt_birthday", "chatgpt", "auto", 33, week_min=12, week_max=13, requires=("met_chatgpt",))  # 11 月 30 日

# --- Claude（大模型 · 文学系） ------------------------------------------------
# 冲突 claude_banned 由 helpers.weekly() 里的第一次封号触发（截稿前用过她，或好感到了）
ev("claude_intro", "claude", "auto", 44, week_min=3)
ev("claude_refuse", "claude", "social", 6, aff_min=12)
ev("claude_banned", "claude", "auto", 60, requires=("claude_ban_pending",))
ev("claude_constitution", "claude", "social", 7, aff_min=30, requires=("claude_banned",))
ev("claude_wait", "claude", "social", 7, aff_min=38, requires=("claude_constitution",))
ev("claude_mythos", "claude", "social", 8, aff_min=45, requires=("claude_wait",))
ev("claude_birthday", "claude", "auto", 33, week_min=27, week_max=29, requires=("met_claude",),
   forbids=("claude_is_banned",))  # 3 月 14 日
ev("both_jealous", None, "auto", 21, requires=("both_helped", "met_chatgpt", "met_claude"))

# --- 群像戏与配角（v2） ---------------------------------------------------------
ev("heroine_party", None, "auto", 22, week_min=28, week_max=31, min_met=3)
ev("deadline_night", None, "auto", 26, week_min=36, week_max=37, min_met=2)
ev("best_paper", None, "auto", 24, week_min=50, week_max=52, min_met=2)
ev("zhao_crossroad", None, "auto", 15, week_min=44)
ev("advisor_han", None, "auto", 18, week_min=36, advisor="han")
ev("advisor_zhou", None, "auto", 18, week_min=36, advisor="zhou")
ev("advisor_hale", None, "auto", 18, week_min=36, advisor="hale")
ev("delve_return", None, "auto", 16, week_min=48, requires=("delve_meet",))

EVENTS = {e["id"]: e for e in E}


def intro_week(gs, e):
    early = e.get("early_track")
    if early and gs.track == early:
        return data.TRACK_EARLY_INTRO[early].get(e["heroine"], e.get("week_min", 0))
    return e.get("week_min", 0)


def eligible(gs, e, heroine=None):
    if e["id"] in gs.seen_events:
        return False
    if heroine is not None and e["heroine"] != heroine:
        return False
    if gs.week < intro_week(gs, e):
        return False
    if e.get("week_max") is not None and gs.week > e["week_max"]:
        return False
    if e.get("aff_min") and gs.affinity.get(e["heroine"], 0) < e["aff_min"]:
        return False
    for f in e.get("requires", ()):
        if not (gs.has(f) or f in gs.seen_events):
            return False
    for f in e.get("forbids", ()):
        if gs.has(f) or f in gs.seen_events:
            return False
    if e["trigger"] == "social" and e["heroine"] and not gs.met.get(e["heroine"]):
        return False
    if e.get("min_met") and sum(1 for h in data.HEROINE_ORDER if gs.met.get(h)) < e["min_met"]:
        return False
    if e.get("advisor") and gs.advisor != e["advisor"]:
        return False
    return True


def pick(gs, trigger, heroine=None):
    """返回优先级最高的可触发事件 id，没有则返回 None。"""
    cands = [e for e in E if e["trigger"] == trigger and eligible(gs, e, heroine)]
    if not cands:
        return None
    cands.sort(key=lambda e: -e["priority"])
    return cands[0]["id"]


def mark_seen(gs, eid):
    gs.seen_events[eid] = gs.week
    e = EVENTS.get(eid)
    if e and e["heroine"] and (e["id"].endswith("_intro") or e.get("meets")):
        gs.met[e["heroine"]] = True
        gs.flag("met_" + e["heroine"])


def top_heroine(gs, min_aff=0.0):
    """已经认识的刊娘里好感最高的那位（节日事件用）。没有则返回 None。"""
    best, best_aff = None, min_aff - 1e-9
    for h in data.HEROINE_ORDER:
        if gs.met.get(h) and gs.affinity[h] > best_aff:
            best, best_aff = h, gs.affinity[h]
    return best


def can_visit(gs, h):
    """认识了还不够：Claude 的账号被停用时，见不到她。"""
    if not gs.met.get(h):
        return False
    return not (h == "claude" and gs.week < gs.ban_until)


def visitable_heroines(gs):
    return [h for h in data.HEROINE_ORDER if can_visit(gs, h)]
