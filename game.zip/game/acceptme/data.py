"""游戏的静态设定数据：时间轴、会议/期刊参数、选题、导师、刊娘。

所有日期都用"周序号"表示：第 0 周 = 一年级 9 月第 1 周。MVP 跨度为 WEEKS_TOTAL 周
（到第二年 9 月 NeurIPS 出结果为止）。截稿日、出分时间等数字是大致范围，可以直接在这里调。
"""

WEEKS_TOTAL = 57  # 第 0~56 周

ATTRS = ("novelty", "rigor", "clarity", "sota", "hype")
ATTR_NAMES = {
    "novelty": "创新",
    "rigor": "严谨",
    "clarity": "表达",
    "sota": "实验",
    "hype": "热度",
}

SAN_MAX = 100
COMPUTE_MAX = 400


def week_to_date(week):
    """周序号 -> (学年, 月份, 当月第几周)。一年按 52 周、每月约 4.33 周近似。"""
    year = 1 + week // 52
    w = week % 52
    month_index = int(w * 12 / 52)  # 0 = 9 月
    month = (8 + month_index) % 12 + 1
    first_week_of_month = -(-month_index * 52 // 12)  # ceil
    week_of_month = w - first_week_of_month + 1
    return year, month, max(1, week_of_month)


def week_label(week):
    year, month, wom = week_to_date(week)
    grade = "一年级" if year == 1 else "二年级"
    return "%s · %d月第%d周" % (grade, month, wom)


# ---------------------------------------------------------------------------
# 选题
# ---------------------------------------------------------------------------
# gain: 每周行动对各属性的增益倍率；fit: 与各会议的契合度（乘在审稿基础分上）
TOPICS = {
    "llm": {
        "name": "大模型",
        "desc": "最火的方向，热度涨得快，但随时可能被大厂抢发。",
        "gain": {"hype": 1.4, "sota": 1.0, "rigor": 0.8},
        "scoop_risk": 0.10,
        "fit": {"iclr": 1.05, "neurips": 1.05, "icml": 0.95, "cvpr": 0.75, "iccv": 0.75, "acl": 1.0, "nature": 0.6},
    },
    "vision_gen": {
        "name": "视觉生成",
        "desc": "做出来的图好看，审稿人看三秒就有印象。",
        "gain": {"sota": 1.2, "clarity": 1.1, "hype": 1.1},
        "scoop_risk": 0.06,
        "fit": {"iclr": 0.95, "neurips": 0.95, "icml": 0.85, "cvpr": 1.15, "iccv": 1.15, "acl": 0.55, "nature": 0.6},
    },
    "ml_theory": {
        "name": "学习理论",
        "desc": "推公式推到天亮。不吃算力，但很吃头发。",
        "gain": {"rigor": 1.5, "sota": 0.6, "hype": 0.6},
        "scoop_risk": 0.02,
        "fit": {"iclr": 0.95, "neurips": 1.0, "icml": 1.15, "cvpr": 0.5, "iccv": 0.5, "acl": 0.5, "nature": 0.5},
    },
    "linguistics": {
        "name": "语言与语义",
        "desc": "大模型时代里，认真问一句“这个词为什么有这个意思”。",
        "gain": {"clarity": 1.3, "novelty": 1.1, "sota": 0.8},
        "scoop_risk": 0.04,
        "fit": {"iclr": 0.85, "neurips": 0.85, "icml": 0.8, "cvpr": 0.5, "iccv": 0.5, "acl": 1.2, "nature": 0.55},
    },
    "ai4science": {
        "name": "AI for Science",
        "desc": "用 AI 去解决一门真正的科学问题。听说有位大小姐只看这种工作。",
        "gain": {"novelty": 1.2, "rigor": 1.1, "hype": 0.9},
        "scoop_risk": 0.04,
        "fit": {"iclr": 0.9, "neurips": 0.95, "icml": 0.9, "cvpr": 0.6, "iccv": 0.6, "acl": 0.5, "nature": 1.2},
    },
}

TRACKS = {
    "ml": {"name": "通用机器学习", "home": ("iclr", "neurips", "icml"), "topics": ("llm", "ml_theory", "ai4science")},
    "cv": {"name": "计算机视觉", "home": ("cvpr", "iccv"), "topics": ("vision_gen", "llm", "ai4science")},
    "nlp": {"name": "自然语言处理", "home": ("acl",), "topics": ("linguistics", "llm", "ai4science")},
}

# ---------------------------------------------------------------------------
# 会议 / 期刊
# ---------------------------------------------------------------------------
# weights: 审稿时各属性权重；sigma: 单个审稿人的噪声；ac_sigma: AC 决策噪声；bar: 录用线（10 分制）
# deadlines: 截稿周；review_delay: 截稿后几周出审稿意见；decision_delay: 出分后几周出结果
# rebuttal_rounds: 0 = 没有 rebuttal；scale: 展示给玩家的离散分数档
VENUES = {
    "iclr": {
        "name": "ICLR",
        "heroine": "clair",
        "kind": "conference",
        "weights": {"novelty": 1.1, "rigor": 1.0, "clarity": 1.0, "sota": 1.0, "hype": 0.4},
        "reviewers": 4,
        "sigma": 1.2,
        "ac_sigma": 0.35,
        "bar": 6.0,
        "deadlines": (4,),
        "review_delay": 7,
        "decision_delay": 10,
        "rebuttal_rounds": 2,
        "public": True,
        "scale": (1, 3, 5, 6, 8, 10),
    },
    "cvpr": {
        "name": "CVPR",
        "heroine": "iris",
        "kind": "conference",
        "weights": {"novelty": 0.9, "rigor": 0.7, "clarity": 1.2, "sota": 1.4, "hype": 0.5},
        "reviewers": 3,
        "sigma": 1.3,
        "ac_sigma": 0.4,
        "bar": 6.3,
        "deadlines": (10,),
        "review_delay": 11,
        "decision_delay": 4,
        "rebuttal_rounds": 1,
        "public": False,
        "scale": (1, 2, 3, 4, 5, 6),
        "scale_from_ten": True,
    },
    "icml": {
        "name": "ICML",
        "heroine": "imel",
        "kind": "conference",
        "weights": {"novelty": 1.0, "rigor": 1.5, "clarity": 1.0, "sota": 0.8, "hype": 0.3},
        "reviewers": 4,
        "sigma": 1.1,
        "ac_sigma": 0.35,
        "bar": 6.1,
        "deadlines": (21,),
        "review_delay": 9,
        "decision_delay": 5,
        "rebuttal_rounds": 1,
        "public": False,
        "scale": (1, 2, 3, 4, 5),
        "scale_from_ten": True,
    },
    "iccv": {
        "name": "ICCV",
        "heroine": "iris",  # 奥德（ICCV）只是客串，好感算在姐姐艾瑞丝头上
        "kind": "conference",
        "weights": {"novelty": 1.0, "rigor": 0.8, "clarity": 1.1, "sota": 1.3, "hype": 0.5},
        "reviewers": 3,
        "sigma": 1.3,
        "ac_sigma": 0.4,
        "bar": 6.3,
        "deadlines": (26,),
        "review_delay": 10,
        "decision_delay": 6,
        "rebuttal_rounds": 1,
        "public": False,
        "scale": (1, 2, 3, 4, 5, 6),
        "scale_from_ten": True,
    },
    "neurips": {
        "name": "NeurIPS",
        "heroine": "neuri",
        "kind": "conference",
        "weights": {"novelty": 1.2, "rigor": 1.0, "clarity": 0.8, "sota": 1.1, "hype": 0.6},
        "reviewers": 4,
        "sigma": 1.8,  # "抽签"
        "ac_sigma": 0.6,
        "bar": 6.0,
        "deadlines": (37,),
        "review_delay": 11,
        "decision_delay": 8,
        "rebuttal_rounds": 1,
        "public": False,
        "scale": (1, 2, 3, 4, 5, 6),
        "scale_from_ten": True,
    },
    "acl": {
        "name": "ACL（ARR）",
        "heroine": "aceline",
        "kind": "conference",
        "weights": {"novelty": 1.0, "rigor": 0.9, "clarity": 1.5, "sota": 0.9, "hype": 0.3},
        "reviewers": 3,
        "sigma": 1.1,
        "ac_sigma": 0.35,
        "bar": 6.4,
        "deadlines": (7, 16, 24, 33, 42),  # ARR 一年多轮
        "review_delay": 7,
        "decision_delay": 5,
        "rebuttal_rounds": 1,
        "public": False,
        "scale": (1, 2, 3, 4, 5),
        "scale_from_ten": True,
    },
    "nature": {
        "name": "Nature",
        "heroine": "natalie",
        "kind": "journal",
        "weights": {"novelty": 1.5, "rigor": 1.2, "clarity": 1.0, "sota": 0.8, "hype": 0.8},
        "reviewers": 3,
        "sigma": 0.8,
        "ac_sigma": 0.3,
        "bar": 6.8,
        "deadlines": (),  # 全年开放投稿
        "review_delay": 8,
        "decision_delay": 3,
        "rebuttal_rounds": 1,
        "public": False,
        "desk_reject": True,
        "scale": (1, 2, 3, 4, 5, 6, 7, 8, 9, 10),
    },
}

CONFERENCE_ORDER = ("iclr", "cvpr", "acl", "icml", "iccv", "neurips")

# ---------------------------------------------------------------------------
# 刊娘
# ---------------------------------------------------------------------------
HEROINES = {
    "kiwi": {"name": "夏可薇", "origin": "arXiv", "intro_week": 0, "venue": None},
    "clair": {"name": "克莱尔", "origin": "ICLR", "intro_week": 1, "venue": "iclr"},
    "iris": {"name": "艾瑞丝", "origin": "CVPR", "intro_week": 6, "venue": "cvpr"},
    "aceline": {"name": "阿瑟琳", "origin": "ACL", "intro_week": 5, "venue": "acl"},
    "imel": {"name": "伊梅尔", "origin": "ICML", "intro_week": 15, "venue": "icml"},
    "neuri": {"name": "妮瑞", "origin": "NeurIPS", "intro_week": 28, "venue": "neurips"},
    "closia": {"name": "克洛丝", "origin": "无限远研究院", "intro_week": 40, "venue": None},
    "natalie": {"name": "娜塔莉", "origin": "Nature", "intro_week": None, "venue": "nature"},
    # 大模型的化身：不属于任何会议，也是日程本里的 AI 帮手（见 helpers.py）
    "chatgpt": {"name": "ChatGPT", "origin": "OpenAI", "intro_week": 2, "venue": None},
    "claude": {"name": "Claude", "origin": "Anthropic", "intro_week": 3, "venue": None},
}
HEROINE_ORDER = ("kiwi", "clair", "aceline", "iris", "imel", "neuri", "closia", "natalie", "chatgpt", "claude")

# 开局选了某个方向，对应的刊娘会提前登场
TRACK_EARLY_INTRO = {"cv": {"iris": 2}, "nlp": {"aceline": 2}, "ml": {}}

# ---------------------------------------------------------------------------
# 导师
# ---------------------------------------------------------------------------
ADVISORS = {
    "han": {
        "name": "韩建国",
        "short": "韩老师",
        "type": "放养型",
        "desc": "自由度高，几乎不管你，但算力也几乎没有。",
        "compute_per_week": 18,
        "san_per_week": 0,
        "gain_bonus": 1.0,
    },
    "zhou": {
        "name": "周静",
        "short": "周老师",
        "type": "卷王型",
        "desc": "资源多、指导多，每周组会让你掉一层皮。",
        "compute_per_week": 30,
        "san_per_week": -3,
        "gain_bonus": 1.15,
    },
    "hale": {
        "name": "Martin Hale",
        "short": "Hale 教授",
        "type": "大厂兼职型",
        "desc": "一半时间在公司，算力管够，但你很难见到他。",
        "compute_per_week": 45,
        "san_per_week": -1,
        "gain_bonus": 0.95,
    },
}

# ---------------------------------------------------------------------------
# 每周行动
# ---------------------------------------------------------------------------
ACTIONS = {
    "read": {"name": "读论文", "desc": "提升创新。没有课题时可以积累 idea。"},
    "experiment": {"name": "跑实验", "desc": "提升实验结果，消耗算力。"},
    "theory": {"name": "推公式", "desc": "提升严谨。"},
    "write": {"name": "写论文", "desc": "提升表达，推进完成度最快。"},
    "promote": {"name": "挂 arXiv / 宣传", "desc": "提升热度。第一次会把论文挂到 arXiv。"},
    "rest": {"name": "摸鱼休息", "desc": "恢复 SAN。"},
    "social": {"name": "去见刊娘", "desc": "提升好感，可能触发剧情。"},
    "crunch": {"name": "赶 DDL", "desc": "截稿前两周才能选。进度暴涨，SAN 暴跌。"},
}
ACTION_ORDER = ("read", "experiment", "theory", "write", "promote", "rest", "social", "crunch")

EXPERIMENT_COMPUTE_COST = 40
MIN_SUBMIT_PROGRESS = 60
IDEAS_TO_START = 1
SKILL_MAX = 30
