"""游戏状态。整个存档就是一个 GameState 对象。"""

import random

from .compat import Base, rdict, rlist
from . import data


def clamp(x, lo, hi):
    return max(lo, min(hi, x))


HEDGE_PENALTY_MAX = 0.3  # ChatGPT 的防御性措辞最多让创新、热度打七折（见 helpers.py）


class Paper(Base):
    def __init__(self, pid, title, topic):
        self.id = pid
        self.title = title
        self.topic = topic
        self.attrs = rdict({a: 0.0 for a in data.ATTRS})
        self.progress = 0.0  # 完成度 0~100
        self.water = 0.0  # 隐藏属性：水分
        self.status = "draft"  # draft / review / accepted / rejected
        self.arxiv = False
        self.travel = 0  # 被拒后转投次数（论文环游世界）
        self.history = rlist()  # [(venue, outcome, week)]
        self.scooped = False
        # AI 帮手（helpers.py）。旧存档里的 Paper 没有这些字段，读取时一律用 getattr 给默认值。
        self.hedge = 0.0  # ChatGPT 留下的防御性措辞
        self.work_weeks = 0  # 在这篇上工作了几周
        self.ai_weeks = 0  # 其中几周用了 AI 帮手
        self.helped_by = rlist()  # 帮过忙的大模型

    def effective(self, attr):
        """完成度不足时，论文的实际质量打折；防御性措辞会把创新和热度盖住一部分。"""
        factor = 0.6 + 0.4 * self.progress / 100.0
        if attr in ("novelty", "hype"):
            factor *= 1.0 - min(HEDGE_PENALTY_MAX, getattr(self, "hedge", 0.0) / 100.0)
        return self.attrs[attr] * factor

    @property
    def submittable(self):
        return self.status in ("draft", "rejected") and self.progress >= data.MIN_SUBMIT_PROGRESS


class Submission(Base):
    def __init__(self, sid, paper_id, venue, week):
        cfg = data.VENUES[venue]
        self.id = sid
        self.paper_id = paper_id
        self.venue = venue
        self.submit_week = week
        self.reviews_week = week + cfg["review_delay"]
        self.decision_week = self.reviews_week + cfg["decision_delay"]
        self.reviews = rlist()
        self.rebuttal_done = False
        self.status = "waiting"  # waiting / reviewed / decided / desk_rejected
        self.outcome = None  # "accept" / "reject"
        self.final_score = None
        self.rev2_recognized = False  # Reviewer #2 认出了这篇转投的论文


class GameState(Base):
    def __init__(self, seed=None):
        self.surname = "林"
        self.given_name = "知远"
        self.track = "ml"
        self.advisor = "han"
        self.week = 0

        self.san = 80.0
        self.compute = 60.0
        self.reputation = 0.0
        self.ideas = 0
        # 研究能力：随相应行动成长，让后面的论文写得越来越好（“成长”的数值体现）
        self.skill = rdict(novelty=0.0, rigor=0.0, clarity=0.0, sota=0.0, hype=0.0)

        self.affinity = rdict({h: 0.0 for h in data.HEROINE_ORDER})
        self.met = rdict({h: False for h in data.HEROINE_ORDER})
        self.flags = rdict()
        self.karma = rdict(careful=0, llm=0, harsh=0)
        self.seen_events = rdict()

        self.papers = rlist()
        self.active_paper = None  # Paper.id
        self.submissions = rlist()
        self.duties = rlist()  # 待完成的审稿任务 [(week, venue)]
        self.log = rlist()

        self.seed = seed if seed is not None else random.randrange(1 << 30)
        self.rng_counter = 0
        self.next_id = 1
        self.san_breakdowns = 0
        self.bug_streak = 0
        self.upgrade()

    def upgrade(self):
        """给旧存档补上后来新增的字段（玩法 v2：日程本、突发状况、见刊娘的话题）。
        新开局时也调用一次。只补缺的，不覆盖已有的值。"""
        defaults = {
            "plan": rlist,  # 排好的日程：[(action, target)]，从前往后执行
            "last_plan": rlist,  # 上一次排的日程，“照上次再来一轮”用
            "last_action": lambda: None,  # 上周做的事（日程搭配加成用）
            "work_streak": lambda: 0,  # 连续几周没有休息
            "last_topic": rdict,  # {刊娘: 上次聊的话题}
            "last_situation_week": lambda: -99,
            "situations_seen": rdict,  # {突发状况 id: 周}
            # AI 帮手（helpers.py）
            "quota": lambda: rdict(chatgpt=100, claude=100),  # 本月剩余额度
            "quota_month": lambda: -1,
            "ban_until": lambda: -1,  # Claude 的账号停用到第几周（不含）
            "helper": lambda: None,  # 日程本上选中的帮手形态
        }
        for name, make in defaults.items():
            if not hasattr(self, name):
                setattr(self, name, make())
        # 后来新增的女主
        for h in data.HEROINE_ORDER:
            if h not in self.affinity:
                self.affinity[h] = 0.0
            if h not in self.met:
                self.met[h] = False

    # -- 随机数 --------------------------------------------------------------
    # 不把 random.Random 存进状态：用 (seed, counter) 派生，保证存档/回滚后结果可复现。
    def rng(self):
        self.rng_counter += 1
        return random.Random("%d:%d" % (self.seed, self.rng_counter))

    def new_id(self):
        self.next_id += 1
        return self.next_id

    # -- 数值修改 ------------------------------------------------------------
    def add_san(self, delta):
        self.san = clamp(self.san + delta, 0, data.SAN_MAX)
        return self.san

    def add_compute(self, delta):
        self.compute = clamp(self.compute + delta, 0, data.COMPUTE_MAX)

    def add_affinity(self, heroine, delta):
        self.affinity[heroine] = clamp(self.affinity[heroine] + delta, 0, 100)
        return self.affinity[heroine]

    def flag(self, name, value=True):
        self.flags[name] = value

    def has(self, name):
        return bool(self.flags.get(name))

    def note(self, text):
        self.log.append((self.week, text))

    # -- 查询 ----------------------------------------------------------------
    def paper(self, pid):
        for p in self.papers:
            if p.id == pid:
                return p
        return None

    @property
    def current_paper(self):
        return self.paper(self.active_paper) if self.active_paper else None

    def submission(self, sid):
        for s in self.submissions:
            if s.id == sid:
                return s
        return None

    def open_submissions(self):
        return [s for s in self.submissions if s.status in ("waiting", "reviewed")]

    def accepted_papers(self):
        return [p for p in self.papers if p.status == "accepted"]

    def paper_under_review(self, pid):
        return any(s.paper_id == pid and s.status in ("waiting", "reviewed") for s in self.submissions)

    @property
    def date_label(self):
        return data.week_label(self.week)

    @property
    def advisor_info(self):
        return data.ADVISORS[self.advisor]

    @property
    def player_name(self):
        return self.surname + self.given_name

    @property
    def advisor_short(self):
        return data.ADVISORS[self.advisor]["short"]

    @property
    def low_san(self):
        return self.san < 30
