"""突发状况：科研生活里的两难小抉择，大约每三周出现一次，二选一。

每个状况：一两句交代（who 为说话人，None 是旁白），两个选项。
选项效果用一个小字典描述，见 apply_effect()；带 "chance" 的选项有风险，按概率走 win / lose。
排日程推进时，状况会打断一下（一个选择 + 一句结果），然后日程继续。
"""

from . import data

# 效果字段：san / compute / reputation / ideas / water / progress / attr{属性: 值}
#          affinity{刊娘: 值} / flag / arxiv / bug_safe（下次实验不会出 bug）/ karma
S = []


def sit(sid, lines, a, b, cond=None, who=None, repeatable=False, weight=1.0):
    S.append({"id": sid, "lines": lines, "options": (a, b), "cond": cond, "who": who,
              "repeatable": repeatable, "weight": weight})


def _draft(gs):
    p = gs.current_paper
    return p is not None and p.status in ("draft", "rejected") and not gs.paper_under_review(p.id)


sit("seeds",
    ["你把随机种子从 42 换成 43，提升从 2.1 个点变成了 0.3。"],
    ("多跑五个种子，老老实实报均值和方差",
     {"compute": -30, "attr": {"rigor": 5}, "text": "五个种子跑完，均值 1.4，方差不小。你把它们原样写进了表格。"}),
    ("就报 42 那次，大家都这么干",
     {"attr": {"sota": 5}, "water": 3, "text": "表格好看了。你决定不去想那个 0.3。"}),
    cond=lambda gs: _draft(gs) and gs.current_paper.attrs["sota"] > 20 and gs.compute >= 30)

sit("cluster_down",
    ["集群维护的通知：预计周三恢复。", "上一次的“预计”，是两周。"],
    ("把实验搬到自己的笔记本上跑",
     {"san": -6, "attr": {"sota": 3}, "text": "风扇响了三天三夜，室友戴上了耳塞。"}),
    ("那就先写论文吧",
     {"attr": {"clarity": 4}, "text": "你打开了一周没碰过的 related work。"}),
    cond=_draft, repeatable=True)

sit("advisor_slides",
    ["导师在群里 @ 你：“明天上午的汇报，slides 你来准备一下。”", "现在是晚上十点。"],
    ("熬夜做一份新的",
     {"san": -8, "reputation": 4, "text": "做到凌晨三点。第二天导师说：“挺好，下次早点发我。”"}),
    ("把上个月那份改改日期",
     {"san": 2, "reputation": -2, "text": "有位老师问第七页的结果是不是更新过。你说还在跑。"}),
    cond=lambda gs: gs.week >= 4)

sit("zhao_debug",
    ["“兄弟，帮我看个 bug，就五分钟。”"],
    ("帮他看",
     {"san": -4, "reputation": 1, "bug_safe": True,
      "text": "五分钟变成了三个小时。他拍着胸口说，下次你的实验出问题，包在他身上。"}),
    ("“我这周也要赶……”",
     {"san": 2, "text": "他说理解。走的时候背影有点落寞。"}),
    who="zhao", cond=lambda gs: gs.week >= 3)

sit("extra_review",
    ["邮箱里多了一封审稿邀请：一篇和你方向很近的稿子，两周内交。"],
    ("接，正好看看别人怎么写",
     {"san": -5, "reputation": 2, "attr": {"novelty": 3}, "karma": "careful",
      "text": "你学到了一个很巧的消融设计，顺手记进了笔记本。"}),
    ("婉拒",
     {"text": "你点了 decline。系统回复：“感谢您的回复。”"}),
    cond=lambda gs: gs.week >= 10)

sit("twitter_fight",
    ["有人在社交媒体上说你的论文“只是换了个数据集”。下面已经两百条转发了。"],
    ("下场回一条长推",
     {"chance": 0.5,
      "win": {"attr": {"hype": 10}, "reputation": 2, "text": "你的回复被转了一千次。有人评论：“这才叫 rebuttal。”"},
      "lose": {"attr": {"hype": 4}, "san": -8, "text": "越吵越多。你关掉手机的时候已经凌晨两点。"}}),
    ("不理它",
     {"san": 1, "text": "你把 app 删了。第二天又装了回来，但没点开那条。"}),
    cond=lambda gs: _draft(gs) and gs.current_paper.arxiv and gs.current_paper.attrs["hype"] > 10)

sit("table_typo",
    ["你发现论文表 2 里有个数字抄错了。", "错的那个，刚好对你有利。"],
    ("改掉，重新挂一版",
     {"water": -3, "attr": {"clarity": 2}, "text": "v2 的更新日志只有一行：修正表 2 的笔误。"}),
    ("反正审稿人也看不出来",
     {"water": 3, "text": "你把那一页关掉了。之后几天，偶尔还会想起那个数字。"}),
    cond=lambda gs: _draft(gs) and gs.current_paper.progress > 40)

sit("midnight_idea",
    ["凌晨一点，你在床上突然想到一个 idea。手机在桌子那头。"],
    ("爬起来记下来",
     {"ideas": 1, "san": -3, "text": "第二天看笔记：“把 attention 换成……”后面几个字你自己也认不出来。好在思路还记得。"}),
    ("睡觉。好 idea 不会跑的",
     {"san": 4, "text": "早上醒来，它跑了。"}),
    repeatable=True)

sit("meeting_callout",
    ["组会上，导师突然点你讲一篇这周的新论文。", "你只看过摘要。"],
    ("照着摘要硬讲",
     {"chance": 0.5,
      "win": {"reputation": 2, "text": "讲得意外流畅。导师点了点头，没多问。"},
      "lose": {"reputation": -2, "san": -4, "text": "第三页就被问住了。会议室安静了五秒。"}}),
    ("老实说还没看完",
     {"san": -2, "attr": {"novelty": 3}, "text": "导师说：“那下周你讲两篇。”你认认真真读完了两篇。"}),
    cond=lambda gs: 8 <= gs.week <= 50)

sit("volunteer",
    ["NeurIPS 在招学生志愿者：免注册费，但要在签到台站一整天。"],
    ("报名",
     {"san": -5, "reputation": 2, "affinity": {"neuri": 4},
      "text": "你在签到台站了一整天。妮瑞路过的时候，冲你眨了下眼。"}),
    ("不去了",
     {"san": 3, "text": "你在宿舍看了直播，弹幕比台上还热闹。"}),
    cond=lambda gs: gs.met.get("neuri") and gs.week >= 30)

sit("open_source",
    ["投稿前要不要把代码整理好开源？整理大概要一周。"],
    ("整理开源",
     {"san": -4, "reputation": 2, "attr": {"rigor": 4}, "flag": "code_open",
      "text": "README 写了三遍。最后一遍，你自己照着步骤跑通了。"}),
    ("先不开，录用了再说",
     {"text": "你在论文末尾写上：Code will be released upon acceptance."}),
    cond=lambda gs: _draft(gs) and gs.current_paper.progress >= 55 and not gs.has("code_open"))

sit("closia_gpus",
    ["克洛丝发来一条消息：“研究院有一批卡这周空着。要的话，来源不便透露。”"],
    ("要",
     {"compute": 80, "affinity": {"closia": 3}, "text": "第二天，你的任务排队时间从三天变成了三分钟。"}),
    ("谢谢，不用了",
     {"affinity": {"closia": 1}, "text": "她回了一个句号。"}),
    cond=lambda gs: gs.met.get("closia"))

sit("roommate_game",
    ["室友喊你开黑：“就一把，二十分钟。”"],
    ("就一把",
     {"san": 9, "text": "一把变成了五把。最后那把赢得很难看，但很开心。"}),
    ("戴上耳机继续干",
     {"san": -3, "progress": 4, "text": "你戴上降噪耳机，又写完了一节。"}),
    cond=_draft, repeatable=True)

sit("scoop_rumor",
    ["可薇半夜发来消息：“有个组刚挂的标题，和你的好像……”"],
    ("连夜挂 arXiv 占坑",
     {"arxiv": True, "attr": {"hype": 4}, "san": -5, "affinity": {"kiwi": 2},
      "text": "凌晨四点，你拿到了编号。可薇回：“时间我记下了。”"}),
    ("先读读他们的再说",
     {"attr": {"novelty": 3}, "text": "读完发现思路不太一样。你松了口气，还顺手学到两招。"}),
    cond=lambda gs: _draft(gs) and not gs.current_paper.arxiv and gs.met.get("kiwi") and gs.current_paper.progress >= 30)

sit("mom_call",
    ["妈妈打来视频：“最近是不是又瘦了？”"],
    ("陪她聊一个小时",
     {"san": 10, "text": "她问了三遍你吃了没。你说吃了，三遍都是真的。"}),
    ("“在忙，回头打给你”",
     {"san": -2, "progress": 3, "text": "你挂了电话，回到屏幕前。过了一会儿，给她发了张食堂饭菜的照片。"}),
    repeatable=True)

sit("cloud_voucher",
    ["实验室发了一批云算力代金券，先到先得。"],
    ("凌晨蹲点抢",
     {"compute": 50, "san": -3, "text": "两点整，你抢到了。屏幕那头，同门的消息一条接一条：“谁这么快？”"}),
    ("让给赵一鸣",
     {"reputation": 1, "san": 2, "text": "赵一鸣说欠你一顿饭。你记下了。"}),
    cond=lambda gs: gs.week >= 6)

SITUATIONS = {s["id"]: s for s in S}

# 出现频率
CHANCE = 0.38  # 满足间隔后，每周出现的概率
MIN_GAP = 2  # 两次之间至少隔几周
FIRST_WEEK = 3
REPEAT_GAP = 16  # 可重复的状况，至少隔这么多周才会再出现


def eligible(gs, s):
    if s["cond"] and not s["cond"](gs):
        return False
    seen = gs.situations_seen.get(s["id"])
    if seen is not None and (not s["repeatable"] or gs.week - seen < REPEAT_GAP):
        return False
    return True


def pick(gs):
    """本周要不要来一个突发状况；返回 id 或 None。"""
    if gs.week < FIRST_WEEK or gs.week - gs.last_situation_week < MIN_GAP:
        return None
    rng = gs.rng()
    if rng.random() > CHANCE:
        return None
    cands = [s for s in S if eligible(gs, s)]
    if not cands:
        return None
    # 没见过的优先
    fresh = [s for s in cands if s["id"] not in gs.situations_seen]
    pool = fresh or cands
    total = sum(s["weight"] for s in pool)
    x = rng.random() * total
    for s in pool:
        x -= s["weight"]
        if x <= 0:
            return s["id"]
    return pool[-1]["id"]


def apply_effect(gs, eff):
    """执行效果，返回给玩家看的结算说明（短句列表）。"""
    out = []
    paper = gs.current_paper
    has_paper = paper is not None and paper.status in ("draft", "rejected")
    if eff.get("san"):
        gs.add_san(eff["san"])
        out.append("SAN %+d" % eff["san"])
    if eff.get("compute"):
        gs.add_compute(eff["compute"])
        out.append("算力 %+d" % eff["compute"])
    if eff.get("reputation"):
        gs.reputation += eff["reputation"]
        out.append("声望 %+d" % eff["reputation"])
    if eff.get("ideas"):
        gs.ideas += eff["ideas"]
        out.append("idea +%d" % eff["ideas"])
    if has_paper:
        for a, v in eff.get("attr", {}).items():
            paper.attrs[a] = max(0.0, min(100.0, paper.attrs[a] + v))
            out.append("%s %+d" % (data.ATTR_NAMES[a], v))
        if eff.get("progress"):
            paper.progress = min(100.0, paper.progress + eff["progress"])
            out.append("完成度 +%d" % eff["progress"])
        if eff.get("water"):
            paper.water = max(0.0, paper.water + eff["water"])  # 水分不显示给玩家
        if eff.get("arxiv"):
            paper.arxiv = True
            out.append("已挂 arXiv")
    for h, v in eff.get("affinity", {}).items():
        gs.add_affinity(h, v)
        out.append("%s好感 %+d" % (data.HEROINES[h]["name"], v))
    if eff.get("flag"):
        gs.flag(eff["flag"])
    if eff.get("bug_safe"):
        gs.bug_streak = max(gs.bug_streak, 1)  # 下次实验出 bug 的概率降到最低
    if eff.get("karma"):
        gs.karma[eff["karma"]] += 1
    return out


def resolve(gs, sid, choice):
    """玩家选了第 choice 个选项（0 或 1）。返回 dict(text=结果描述, lines=[结算说明])。"""
    s = SITUATIONS[sid]
    gs.situations_seen[sid] = gs.week
    gs.last_situation_week = gs.week
    label, eff = s["options"][choice]
    if "chance" in eff:
        eff = eff["win"] if gs.rng().random() < eff["chance"] else eff["lose"]
    lines = apply_effect(gs, eff)
    return {"text": eff["text"], "lines": lines}
