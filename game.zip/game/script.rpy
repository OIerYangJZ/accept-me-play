## 主流程：开场 → 每周循环 → 第一学年结算。

default gs = None
default week_items = []
default wi = 0
default week_result = None
default cur_sub = None
default cur_plan = None
default rebuttal_results = None
default rebuttal_round = 1

## 自动化测试专用（game/testcases.rpy）。正常游戏中始终为 False。
default autoplay = False
default autoplay_seed = None
default autoplay_policy = "romantic"

init python:
    from acceptme import actions as aactions, events as aevents, rebuttal as arebuttal
    from acceptme import review as areview, sim as asim, ending as aending
    from acceptme import talk as atalk, situations as asit, helpers as ahelpers

    def venue_name(v):
        return adata.VENUES[v]["name"]

    def heroine_of(v):
        return adata.VENUES[v]["heroine"]

    def attach_review_text(sub):
        """给每条审稿意见配上文本池里的具体文字（生成时定下来，存档后保持一致）。"""
        for r in sub.reviews:
            for c in r.concerns:
                c.text = pick_line("review_comments", c.kind, r.persona)

    from acceptme import autoplay as aauto

    def ap_trace(msg):
        """自动化测试时把进度写到项目根目录的 autoplay_trace.txt。"""
        import os
        with open(os.path.join(config.basedir, "autoplay_trace.txt"), "a") as f:
            f.write(msg + "\n")

    def ap_go(name):
        """自动化测试：某个界面是否应该自动继续（截图测试会让它停在指定界面）。"""
        return autoplay and aauto.CONFIG.get("hold") != name

    def ap_week():
        act, target = aauto.choose_action(gs, autoplay_policy, renpy.random)
        if act == "start":
            return ("start_paper", None)
        return (act, target)

    def ap_topic():
        return aauto.choose_topic(gs, renpy.random)

    def paper_buff(**attrs):
        """剧情选择给当前课题加属性（没有在做的课题就什么都不加）。"""
        pp = gs.current_paper
        if pp is None or pp.status not in ("draft", "rejected"):
            return False
        for a, v in attrs.items():
            if a == "progress":
                pp.progress = min(100.0, pp.progress + v)
            else:
                pp.attrs[a] = max(0.0, min(100.0, pp.attrs[a] + v))
        return True

    def zhao_tip():
        """赵一鸣的情报：随机挑一位已经认识的刊娘，说出她最喜欢的话题。"""
        met = [h for h in adata.HEROINE_ORDER if gs.met.get(h)]
        if not met:
            return None
        h = renpy.random.choice(met)
        gs.flag("tip_" + h)
        return "%s最喜欢别人%s" % (adata.HEROINES[h]["name"], {"research": "跟她聊研究", "her": "问她最近怎么样", "advice": "向她请教投稿"}[atalk.PREFS[h][0]])

    PLAN_ACTIONS = ("start_paper", "switch_paper", "submit_nature", "social", "go")

    # ---------------- 日程本 ----------------
    PLAN_SLOTS = 4

    def plan_capacity():
        return max(0, min(PLAN_SLOTS, adata.WEEKS_TOTAL - gs.week))

    def plan_state_after(plan):
        """排完 plan 之后的 (上一周行动, 连续工作周数)，用来算下一格的搭配加成。"""
        last, streak = gs.last_action, gs.work_streak
        for a, _t in plan:
            streak = streak + 1 if a in aactions.WORK_ACTIONS else 0
            last = a
        return last, streak

    def next_combo(a):
        last, streak = plan_state_after(gs.plan)
        return aactions.combo(last, streak, a)

    def slot_problem(a, k):
        """第 k 格（从现在起第 k 周）能不能排 a；不能就返回原因。"""
        avail = {x: (ok, why) for x, ok, why in aactions.available_actions(gs)}
        ok, why = avail[a]
        if a == "crunch":
            dls = aactions.upcoming_deadlines(gs)
            if not (avail["write"][0] and any(0 <= d - (gs.week + k) <= 2 for d in dls)):
                return "只能排在截稿前两周"
            return None
        if a == "experiment" and avail["write"][0]:
            income = gs.advisor_info["compute_per_week"]
            used = sum(1 for x, _t in gs.plan[:k] if x == "experiment") * adata.EXPERIMENT_COMPUTE_COST
            if gs.compute + income * k - used < adata.EXPERIMENT_COMPUTE_COST:
                return "到那周算力不够"
            return None
        return None if ok else why

    def plan_add(a, target=None):
        if a in ahelpers.HELPABLE and target is None:
            target = gs.helper  # 日程本上选中的 AI 帮手，跟着排进去的每一个工作周
        k = len(gs.plan)
        if k >= plan_capacity():
            renpy.notify("日程排满了。点格子可以撤掉某一周。")
            return
        why = slot_problem(a, k)
        if why:
            renpy.notify(why)
            return
        gs.plan.append((a, target))

    def plan_clear_all():
        del gs.plan[:]

    def plan_remove(i):
        del gs.plan[i:]  # 撤掉某一周，后面的也一起撤（顺序变了，搭配会变）

    def plan_repeat():
        gs.plan[:] = []
        for a, t in gs.last_plan:
            if len(gs.plan) >= plan_capacity() or slot_problem(a, len(gs.plan)):
                break
            gs.plan.append((a, t))
        if not gs.plan:
            renpy.notify("上次的日程现在排不进去了，重新排一下吧。")

    def plan_step_problem(a, target):
        """执行到这一周时，计划的行动还能不能做；不能就返回原因。
        AI 帮手用不了（额度不够、被封号）不算问题：这周自己做，结算时会说明。"""
        if a == "social":
            if not gs.met.get(target):
                return "还没认识她"
            return None if aevents.can_visit(gs, target) else "Claude 的账号被停用了"
        avail = {x: (ok, why) for x, ok, why in aactions.available_actions(gs)}
        ok, why = avail.get(a, (False, "未知行动"))
        return None if ok else "%s%s" % (adata.ACTIONS[a]["name"], "：" + why if why else "做不了了")

    def valid_plan(r):
        """每周计划界面的返回值是否合法：(行动, 目标) 二元组，目标要和行动对得上。"""
        if not (isinstance(r, tuple) and len(r) == 2):
            return False
        act, target = r
        if act == "go":
            return bool(gs.plan)
        if act in ("switch_paper", "submit_nature"):
            return gs.paper(target) is not None
        if act == "social":
            return target in adata.HEROINES
        if act in ahelpers.HELPABLE:
            return target is None or target in ahelpers.FORMS
        return act == "start_paper" or act in adata.ACTIONS

    def ap_submit(v, cands):
        p = cands[0]
        return p.id if aauto.wants_to_submit(gs, p, v) else False

    def ap_rebuttal(plan, sub):
        auto_fill(plan, sub)
        return True

    def attach_reply_one(sub, ri):
        r = sub.reviews[ri]
        if r.reply:
            used = set(getattr(x, "reply_text", None) for x in sub.reviews if x is not r)
            pool = [l for l in POOLS["reviewer_replies"][r.persona][r.reply] if l not in used]
            r.reply_text = renpy.random.choice(pool or POOLS["reviewer_replies"][r.persona][r.reply])

    def ap_board_choice():
        """自动游玩：审稿意见页一半走对线、一半交给导师，两条路都测到。"""
        hold = aauto.CONFIG.get("hold")
        if hold == "rebuttal_result":
            return "auto"
        if hold in ("rebuttal_duel", "duel_reaction"):
            return "duel"
        return "duel" if renpy.random.random() < 0.5 else "auto"

    def ap_followup(plan, sub, ri, fu):
        """自动游玩回应追问：有能用的卡就用导师会选的那张，否则不接。"""
        if fu is None:
            return None
        best = {"missing_baseline": "experiment", "missing_ablation": "experiment", "weak_results": "experiment",
                "need_theory": "theory", "unclear_writing": "clarify", "limited_novelty": "clarify",
                "overclaim": "concede", "reproducibility": "clarify", "cite_me": "cite",
                "buried_contribution": "clarify"}
        for c in (best.get(sub.reviews[ri].concerns[fu].kind, "concede"), "concede"):
            if arebuttal.followup_usable(gs, plan, sub, ri, c):
                return c
        return None

    def attach_reply_text(sub):
        used = set()
        for r in sub.reviews:
            if r.reply:
                pool = [l for l in POOLS["reviewer_replies"][r.persona][r.reply] if l not in used]
                r.reply_text = renpy.random.choice(pool or POOLS["reviewer_replies"][r.persona][r.reply])
                used.add(r.reply_text)


label autoplay_start:
    # 只由自动化测试调用
    $ autoplay = True
    $ autoplay_seed = aauto.CONFIG["seed"]
    $ autoplay_policy = aauto.CONFIG["policy"]
    jump start

label start:
    $ gs = acceptme.GameState(seed=autoplay_seed if autoplay else None)
    if autoplay:
        $ renpy.random.seed(autoplay_seed)
        $ renpy.config.skipping = "slow"
    call prologue
    $ aactions.start_thesis_paper(gs)
    jump week_loop


label week_loop:
    while not asim.is_over(gs):
        $ renpy.block_rollback()
        $ week_items = asim.begin_week(gs)
        if autoplay:
            $ ap_trace("week %d %s items=%s san=%d" % (gs.week, gs.date_label, [k for k, _ in week_items], gs.san))
        $ wi = 0
        while wi < len(week_items):
            $ t_kind, t_payload = week_items[wi]
            $ wi += 1
            call expression ("on_" + t_kind) pass (t_payload)
        call plan_week
    if autoplay:
        $ ap_trace("loop done, week %d" % gs.week)
    jump year_end


## ---------------------------------------------------------------------------
## 每周行动
## ---------------------------------------------------------------------------
label plan_week:
    $ gs.upgrade()  # 旧存档补字段
    if gs.plan:
        # 日程里排好了：自动执行下一周
        $ t_act, t_target = gs.plan[0]
        $ t_why = plan_step_problem(t_act, t_target)
        if t_why:
            $ del gs.plan[:]
            $ renpy.notify("日程被打乱了：%s。重新排一下吧。" % t_why)
            jump plan_week
        $ gs.plan.pop(0)
        jump run_week

    if gs.low_san:
        scene bg lab_night at low_san_filter
    else:
        scene bg lab_day
    call screen week_planner
    if not valid_plan(_return):
        # 回退 / 快进重放时，界面可能拿到别的界面的返回值；不合法就重新选
        jump plan_week
    $ t_act, t_target = _return

    if t_act == "go":
        $ gs.last_plan[:] = list(gs.plan)
        jump plan_week
    elif t_act == "start_paper":
        call screen topic_select
        if _return in adata.TOPICS:
            $ aactions.start_paper(gs, _return)
            $ renpy.notify("开始了新课题《%s》" % gs.current_paper.title)
        jump plan_week
    elif t_act == "switch_paper":
        $ aactions.set_active_paper(gs, t_target)
        $ del gs.plan[:]
        jump plan_week
    elif t_act == "submit_nature":
        call submit_to(t_target, "nature")
        jump plan_week
    # 自动游玩直接给出一周的行动
    jump run_week


label run_week:
    ## 执行一周：t_act / t_target 由 plan_week 设好
    if gs.low_san:
        scene bg lab_night at low_san_filter
    else:
        scene bg lab_day
    $ t_talked = False
    if t_act == "social":
        call visit(t_target)
    $ week_result = asim.finish_week(gs, t_act, t_target, talked=t_talked)
    if autoplay:
        $ ap_trace("  action %s %s -> week %d" % (t_act, t_target, gs.week))
    call screen week_tick(t_act, t_target, week_result, week_flavor(t_act, t_target) if t_act != "social" else None)
    return


label visit(h):
    $ t_eid = aevents.pick(gs, "social", h)
    if t_eid:
        call expression t_eid
        $ aevents.mark_seen(gs, t_eid)
    else:
        call talk(h)
        $ t_talked = True
    return


## ---------------------------------------------------------------------------
## 每周事项的处理
## ---------------------------------------------------------------------------
label on_story(eid):
    call expression eid
    $ aevents.mark_seen(gs, eid)
    return

label on_breakdown(payload=None):
    scene bg dorm_night at low_san_filter
    $ sfx("sad")
    "你已经三天没怎么睡了。"
    "盯着 loss 曲线的时候，它开始自己往两边晃。你合上电脑躺下，再起来已经是一周以后。"
    $ asim.breakdown(gs)
    if gs.met["kiwi"]:
        show kiwi lonely
        kiwi "[gs.given_name]？你一周没回我消息了，我数了，四十三条。"
        kiwi "论文的事我不问。你回我一个字就行，“在”也行。"
        $ gs.add_affinity("kiwi", 5)
        hide kiwi
    "（SAN 恢复到了 45。请记得休息。）"
    return

label on_reminder(v):
    $ renpy.notify("距离 %s 截稿还有 2 周" % venue_name(v))
    return

label on_deadline(v):
    $ t_cands = [pp for pp in gs.papers if v in areview.venues_open_for(gs, pp)]
    if not t_cands:
        $ t_drafts = [pp for pp in gs.papers if pp.status in ("draft", "rejected") and not gs.paper_under_review(pp.id)]
        if t_drafts:
            $ t_vname = venue_name(v)
            "今天是 [t_vname] 的截稿日。你手上的稿子还没到能投的程度，只能看着倒计时归零。"
        return
    $ t_vname = venue_name(v)
    "今天是 [t_vname] 的截稿日。"
    call screen submit_select(v, t_cands)
    while _return and _return not in [pp.id for pp in t_cands]:
        # 不是这次可投的论文编号（回退 / 快进重放时可能拿到别的界面的返回值）：重新选
        call screen submit_select(v, t_cands)
    if _return:  # 论文编号从 1 开始；None / False 都表示这次不投
        call submit_to(_return, v)
    else:
        "你关掉了投稿页面。这次先不投。"
    return

label submit_to(pid, v):
    $ t_paper = gs.paper(pid)
    if t_paper is None or t_paper.status not in ("draft", "rejected") or gs.paper_under_review(pid):
        return
    $ cur_sub = areview.submit(gs, t_paper, v)
    $ t_vname = venue_name(v)
    "你把《[t_paper.title]》交给了 [t_vname]。"
    if renpy.has_label("submitted_" + v):
        call expression ("submitted_" + v)
    return

label on_desk(sid):
    $ cur_sub = gs.submission(sid)
    scene bg mansion
    show winston normal
    winston "您的稿件，我已经替大小姐过目了。"
    if asim.process_desk(gs, sid):
        show winston bow
        winston "我会把它呈给大小姐。从我书桌上走到这一步的稿子，一年没有几份。"
        $ gs.add_affinity("natalie", 8)
    else:
        show winston stern
        winston "很遗憾，我们认为这项工作更适合专业期刊。"
        winston "另附一句私人意见：被大小姐退回过的人里，后来有好几位拿了奖。请保重。"
    hide winston
    return

label on_reviews(sid):
    $ cur_sub = gs.submission(sid)
    $ areview.generate_reviews(gs, cur_sub)
    $ attach_review_text(cur_sub)
    $ t_vcfg = adata.VENUES[cur_sub.venue]
    $ t_vname = venue_name(cur_sub.venue)
    if cur_sub.venue == "iclr":
        scene bg openreview_hall
    else:
        scene bg lab_night
    "[t_vname] 的审稿意见出来了。"
    if renpy.has_label("reviews_" + cur_sub.venue):
        call expression ("reviews_" + cur_sub.venue)
    if cur_sub.rev2_recognized:
        show rev2 smirk
        rev2 "又是你。上次让你改的地方，你一个字都没改吧？"
        hide rev2
    if t_vcfg["rebuttal_rounds"] <= 0:
        call screen review_board(cur_sub, None, False)
        return
    $ rebuttal_round = 1
    while rebuttal_round <= t_vcfg["rebuttal_rounds"]:
        $ cur_plan = arebuttal.RebuttalPlan(cur_sub, rebuttal_round)
        call screen review_board(cur_sub, cur_plan, False)
        if _return == "duel":
            call rebuttal_duel_round
        else:
            # 交给导师：一次性分配、结算，看一张汇总
            $ auto_fill(cur_plan, cur_sub)
            $ rebuttal_results = arebuttal.resolve(gs, cur_sub, cur_plan)
            $ attach_reply_text(cur_sub)
            call screen rebuttal_result(cur_sub, rebuttal_results)
        $ rebuttal_round += 1
    return


label rebuttal_duel_round:
    ## 一位一位对线：出牌 → 对方回应 →（可能）追问 → 再出一张
    $ t_order = arebuttal.duel_order(cur_sub)
    $ t_i = 0
    while t_i < len(t_order):
        $ t_ri = t_order[t_i]
        $ t_i += 1
        $ duel_sel = duel_first_open(cur_plan, t_ri, cur_sub)
        call screen rebuttal_duel(cur_sub, cur_plan, t_ri, t_i, len(t_order))
        if _return == "auto_all":
            # 剩下的都交给导师
            $ auto_fill(cur_plan, cur_sub)
            $ rebuttal_results = arebuttal.resolve(gs, cur_sub, cur_plan)
            $ attach_reply_text(cur_sub)
            call screen rebuttal_result(cur_sub, rebuttal_results)
            return
        $ t_res = arebuttal.resolve_review(gs, cur_sub, cur_plan, t_ri)
        $ attach_reply_one(cur_sub, t_ri)
        $ t_fu = arebuttal.followup(gs, cur_sub, cur_plan, t_ri)
        call screen duel_reaction(cur_sub, cur_plan, t_ri, t_res, t_fu, t_i, len(t_order))
        if t_fu is not None and _return in arebuttal.CARDS and arebuttal.followup_usable(gs, cur_plan, cur_sub, t_ri, _return):
            $ t_res = arebuttal.answer_followup(gs, cur_sub, cur_plan, t_ri, t_fu, _return)
            $ attach_reply_one(cur_sub, t_ri)
            call screen duel_reaction(cur_sub, cur_plan, t_ri, t_res, None, t_i, len(t_order))
    $ arebuttal.finish(cur_sub, cur_plan)
    return

label on_decision(sid):
    $ cur_sub = gs.submission(sid)
    $ t_outcome = asim.process_decision(gs, sid)
    $ t_vname = venue_name(cur_sub.venue)
    scene bg lab_night
    $ sfx("mail")
    "邮箱里多了一封新邮件：「[t_vname] Decision Notification」。"
    call screen decision_letter(cur_sub)
    $ t_react = "react_%s_%s" % (cur_sub.venue, t_outcome)
    if renpy.has_label(t_react):
        call expression t_react
    elif t_outcome == "accept":
        call react_generic_accept
    else:
        call react_generic_reject
    return

label on_duty(v):
    scene bg lab_night
    $ t_vname = venue_name(v)
    "作为 [t_vname] 的投稿作者，你被分配了三篇别人的稿子。截止日期是明天中午。"
    $ t_gpt = ahelpers.family_ready(gs, "chatgpt", ahelpers.DUTY_COST)
    $ t_claude = ahelpers.family_ready(gs, "claude", ahelpers.DUTY_COST)
    menu:
        "认真读完，好好写意见":
            $ t_msg = asim.do_duty(gs, v, "careful")
        "交给 ChatGPT 写" if t_gpt:
            $ t_msg = asim.do_duty(gs, v, "gpt")
        "交给 Claude 写" if t_claude:
            $ t_msg = asim.do_duty(gs, v, "claude")
        "交给大模型写" if not (t_gpt or t_claude):
            $ t_msg = asim.do_duty(gs, v, "llm")
        "统统打低分，顺便要求引用我的论文":
            $ t_msg = asim.do_duty(gs, v, "harsh")
    "[t_msg]"
    return

label on_scoop(pid):
    $ t_paper = gs.paper(pid)
    $ t_news = pick_line("scoop_news", "news")
    scene bg lab_day
    "[t_news]"
    "你点开 PDF。方法、实验，连图的配色都和《[t_paper.title]》差不多。他们的图例还比你的好看。"
    $ asim.apply_scoop(gs, pid)
    "（这篇论文的创新大打折扣。你的 SAN 掉了一大截。）"
    return

label on_situation(sid):
    ## 突发状况：一两句交代 + 二选一 + 一句结果（内容见 acceptme/situations.py）
    $ t_sit = asit.SITUATIONS[sid]
    if gs.low_san:
        scene bg lab_night at low_san_filter
    else:
        scene bg lab_day
    if t_sit["who"]:
        show expression t_sit["who"] + " normal" as sitwho
    python:
        _who = getattr(store, t_sit["who"]) if t_sit["who"] else narrator
        for _l in t_sit["lines"][:-1]:
            renpy.say(_who, _l)
        renpy.say(_who, t_sit["lines"][-1], interact=False)
        t_choice = renpy.display_menu([(t_sit["options"][0][0], 0), (t_sit["options"][1][0], 1)])
        t_sres = asit.resolve(gs, sid, t_choice)
        t_stext = t_sres["text"]
    if autoplay:
        $ ap_trace("  situation %s -> %d" % (sid, t_choice))
    "[t_stext]"
    if t_sres["lines"]:
        $ renpy.notify("　·　".join(t_sres["lines"]))
    hide sitwho
    return

label on_omnia(payload=None):
    $ t_subject = pick_line("omnia_spam", "subjects")
    show omnia excited
    omnia "叮咚～您有一封新邮件：「[t_subject]」"
    menu:
        "删除":
            omnia "没关系！我们明天同一时间再来！后天也是！"
        "回复“已拉黑”":
            show omnia shocked
            omnia "您的回复我们已经收到，并将其作为一篇论文发表在本刊第 9999 期！"
            "你把“不回复任何陌生邮件”写在了便利贴上，贴在显示器边框。"
    hide omnia
    return


## 游戏目前只有中文：如果界面语言还是默认的英文，启动时切换到官方简体中文界面翻译。
## （config.default_language 只在玩家第一次运行时生效，这里兜底。以后加英文版时再改。）
label before_main_menu:
    if _preferences.language is None:
        $ renpy.change_language("schinese")
    return
