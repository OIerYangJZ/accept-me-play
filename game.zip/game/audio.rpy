## 音乐与音效。清单在 data/audio_manifest.json：
##   BGM：audio/bgm/<id>.ogg，进入某个 label 时按 rules 自动切换（不用在剧本里到处写 play music）；
##   音效：audio/sfx/<id>.ogg，剧本和界面里用 sfx("<id>") 播放。
## 文件不存在时静默跳过，所以缺几首曲子游戏照样能跑。

init -9 python:
    import re

    with renpy.open_file("data/audio_manifest.json") as _f:
        AUDIO = json.loads(_f.read().decode("utf-8"))

    _BGM_RULES = [(re.compile(pat), track) for pat, track in AUDIO["rules"]]

    _BGM_LOOP = {b["id"]: b["loop"] for b in AUDIO["bgm"] if b.get("loop")}

    def bgm_path(track):
        path = "audio/bgm/%s.ogg" % track
        return path if renpy.loadable(path) else None

    def bgm_play_name(track):
        """带循环点的写法：有前奏的曲子只放一次前奏，之后从 loop 秒处循环。"""
        path = bgm_path(track)
        if path and track in _BGM_LOOP:
            return "<loop %.4f>%s" % (_BGM_LOOP[track], path)
        return path

    def bgm(track, fade=1.2):
        """切换 BGM。同一首曲子正在播时不会重新开始；track=None 时淡出停止。"""
        path = bgm_play_name(track) if track else None
        if path:
            renpy.music.play(path, channel="music", loop=True, fadeout=fade, fadein=fade, if_changed=True)
        else:
            renpy.music.stop(channel="music", fadeout=fade)

    def sfx(name):
        """播放一个音效；文件不存在时什么都不做。"""
        path = "audio/sfx/%s.ogg" % name
        if renpy.loadable(path):
            renpy.sound.play(path, channel="sound")

    def bgm_for_label(label):
        """label 名对应的曲目 id；"keep" 或没有命中时返回 "keep"（不换曲）。"""
        if not isinstance(label, str):
            return "keep"
        for pat, track in _BGM_RULES:
            if pat.search(label):
                return track
        return "keep"

    def _bgm_label_callback(label, abnormal):
        track = bgm_for_label(label)
        if track != "keep":
            bgm(track)

    config.label_callbacks.append(_bgm_label_callback)

    config.main_menu_music = bgm_play_name("title")
    config.sample_sound = "audio/sfx/notify.ogg" if renpy.loadable("audio/sfx/notify.ogg") else None

## 默认音量：音乐比音效稍低，避免盖过阅读
define config.default_music_volume = 0.6
define config.default_sfx_volume = 0.8

## 所有按钮按下时的“嗒”一声（有音效文件时才生效）
init 1 python:
    if renpy.loadable("audio/sfx/click.ogg"):
        style.button.activate_sound = "audio/sfx/click.ogg"
