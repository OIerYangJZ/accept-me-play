## 阿瑟琳（ACL）—— 文学少女

label aceline_intro:
    scene bg old_library
    with fade
    "图书馆最里面的阅览室。台灯是暖黄色的，空气里有旧纸的味道。"
    show aceline reading
    "一个抱着厚词典的女孩从书后面抬起头。"
    show aceline smile
    aceline "你好。我是阿瑟琳。"
    aceline "你挂在 arXiv 上那篇，我读过摘要了。"
    show aceline frown
    aceline "“novel”四次，“significant”三次。一共一百九十个词。"
    aceline "这两个词本身没错，用多了就什么都不是了。"
    menu:
        "“能帮我圈出来吗？我回去改。”":
            show aceline smile
            aceline "当然。铅笔圈的，可以擦。"
            $ paper_buff(clarity=4)
            $ gs.add_affinity("aceline", 2)
        "“可是大家都这么写啊。”":
            aceline "大家都这么写，所以审稿人都看腻了。"
            show aceline smile
            aceline "不过你肯反驳，这点我喜欢。"
            $ gs.add_affinity("aceline", 4)
    show aceline smile
    aceline "在我这里投稿，要先寄到“滚动评审邮局”拿评分，再决定交给谁。一年好几轮，不急。"
    $ gs.add_affinity("aceline", 6)
    hide aceline
    "【阿瑟琳】ACL 的化身。一年有多轮截稿，最看重写作表达。"
    return

label visit_aceline:
    scene bg old_library
    $ t_v = renpy.random.randint(1, 3)
    if gs.low_san:
        show aceline reading
        aceline "你今天进门的时候撞到了书架。坐下吧。"
        aceline "我念一段给你听。不长，是一本童话里的，讲一只总是迷路的刺猬。"
        "她念得很慢。你没听完就趴在桌上睡着了，醒来的时候身上多了一件开衫。"
        $ gs.add_san(4)
    elif t_v == 1:
        show aceline reading
        aceline "今天在读一本讲否定词的书。有些语言里，一句话可以在三个不同的位置放“不”。"
        p "然后大模型三个都理解错？"
        show aceline excited
        aceline "对！上周有人用这个做了个测试集，错误率百分之四十一。"
    elif t_v == 2:
        show aceline frown
        aceline "今天有篇投稿，摘要里用了六次“state-of-the-art”。"
        aceline "第六次我拿铅笔圈了起来。"
        show aceline smile
        aceline "然后在页边写：“请换一个词。你的结果配得上更具体的形容。”铅笔写的，可以擦。"
    else:
        show aceline writing
        aceline "[gs.surname]同学，你写信打不打草稿？"
        aceline "我打。删掉的那些字不会出现在信里，但收信的人读得出来哪里删过。"
    hide aceline
    return

label aceline_library:
    scene bg old_library
    show aceline lonely
    "阿瑟琳在读一本书，借阅卡上一个名字也没有。"
    aceline "现在来找我的人，问的都是大模型。"
    aceline "很久没人问我，一个词为什么会是这个意思了。"
    aceline "有位前辈说过：“我每解雇一个语言学家，系统的性能就提高一点。”"
    aceline "这句话被引用了几十年。大家引用的时候都在笑。"
    menu:
        "“我想在论文里加一节语言学分析。你能教我吗？”":
            show aceline surprised
            aceline "你是认真的？"
            show aceline excited
            aceline "那从“否定”开始。不对，先讲量词。量词更好玩。“一匹布”为什么是“匹”，你想过吗——"
            $ gs.add_affinity("aceline", 10)
            $ gs.flag("aceline_linguistics")
        "“大模型其实也在学语言啊。”":
            show aceline smile
            aceline "在学。学得很好。只是它说不出来自己为什么这么理解。"
            $ gs.add_affinity("aceline", 4)
    hide aceline
    return

label aceline_word:
    scene bg old_library
    show aceline reading
    "阿瑟琳翻开那本很旧的词典，指甲在其中一行上划了一下。"
    aceline "[gs.surname]同学，“accept”这个词，你查过词源吗？"
    aceline "拉丁语 accipere。ad 是“朝向”，capere 是“拿”。"
    show aceline smile
    aceline "合在一起，是“拿到自己身边来”。"
    aceline "最早用这个词的时候，意思接近“收下”。“审核通过”是很后来才有的用法。"
    "你想到收件箱里那些标题带着 Decision 的邮件。有的已经来了，有的还在路上。"
    aceline "词义会漂移。有时候漂得太远，大家就忘了它原来是什么样。"
    menu:
        "“那你呢？你想被谁收下？”":
            show aceline surprised
            aceline "这个问题的施事和受事放反了。"
            show aceline blush
            aceline "我是会议。按语法，我只能做“收下”的那个。"
            aceline "被动语态……我没有试过。"
            $ gs.add_affinity("aceline", 10)
        "“谢谢你。我好像没那么怕了。”":
            show aceline smile
            aceline "那就好。词就是这样，查一查来历，常常就没那么吓人了。"
            $ gs.add_affinity("aceline", 7)
            $ gs.add_san(6)
    hide aceline
    return

label aceline_letter:
    scene cg_aceline_letter
    with dissolve
    aceline "[gs.surname]同学，这个给你。"
    "一封手写信。信封上的字一笔一画，写你名字的那几笔明显描过两遍。"
    aceline "现在大家都打字了。有些话我还是想用手写，写错了要重写一整页，所以每个字都得想好。"
    aceline "不许在我面前拆。"
    menu:
        "回她一封手写信":
            aceline "你写了回信？"
            aceline "我回去再读。我要一个字一个字地读，你别跟着。"
            $ gs.add_affinity("aceline", 12)
        "当面郑重地道谢":
            aceline "嗯。当面说的也算。口语也是语言。"
            $ gs.add_affinity("aceline", 8)
    scene bg old_library
    with dissolve
    return

label react_acl_accept:
    show aceline excited
    aceline "恭喜！你的摘要这次一个“novel”都没有。"
    aceline "我数了两遍。"
    hide aceline
    return

label react_acl_reject:
    show aceline smile
    aceline "没事，下一轮邮局很快又开了。"
    aceline "你的意见里有一句好话：有位审稿人说你的动机写得很清楚。这一段别改。"
    hide aceline
    return

## ---------------------------------------------------------------------------
## 冲突：润色过的信（没人借的书之后）
## ---------------------------------------------------------------------------
label aceline_polish:
    scene bg old_library
    show aceline frown
    "阿瑟琳面前摊着一封打印的信。你还没坐下，她就把信推了过来。"
    aceline "你读读第二段。"
    "“我们怀着最深切的歉意，诚挚地反思此次疏漏所带来的深远影响……”"
    aceline "一个作者记错了我的截稿日，写信来道歉。三百个字，没有一个字是他自己的。"
    aceline "道歉得自己找词。找得笨一点没关系，至少是他自己的。"
    show aceline lonely
    aceline "对不起，我很少这样。"
    aceline "[gs.surname]同学，你用过吗？那种东西。"
    menu:
        "“用过。改语法，翻译摘要。自己的意思，没让它替我说。”":
            show aceline surprised
            aceline "你说得这么具体。"
            show aceline smile
            aceline "改语法不算。你连用在哪都说清楚了，那就不算。"
            $ gs.flag("aceline_honest")
            $ gs.add_affinity("aceline", 8)
        "“没用过。”":
            if gs.karma["llm"] > 0:
                show aceline lonely
                aceline "可是你上次给我看的那份审稿意见，开头三句，我在别人的意见里见过一模一样的。"
                aceline "算了。不是什么大事。"
                $ gs.add_affinity("aceline", -4)
            else:
                show aceline smile
                aceline "嗯。我看得出来，你写东西有自己的毛病。"
                $ gs.add_affinity("aceline", 5)
        "“它只是工具。用的人才有问题。”":
            aceline "工具不会道歉。"
            aceline "不过你说得也对。这封信的问题，在写信的人。"
            $ gs.add_affinity("aceline", 3)
    hide aceline
    return


## ---------------------------------------------------------------------------
## 约定：不好翻译的词（春节之后）
## ---------------------------------------------------------------------------
label aceline_dialect:
    scene bg old_library
    show aceline writing
    aceline "春节回家了吧？我在收集方言里不好翻译的词。"
    aceline "比如一顿饭吃得特别舒服，从胃一直舒服到心里。你老家怎么说？"
    menu:
        "“巴适。”":
            $ t_word = "巴适"
            aceline "巴适。两个字，一个“巴”，嘴就张开了。"
        "“得劲。”":
            $ t_word = "得劲"
            aceline "得劲。不只是舒服，还带着一股使得上力气的感觉。"
        "“落胃。”":
            $ t_word = "落胃"
            aceline "落胃。东西落到胃里，人就安定下来了。"
    show aceline excited
    aceline "我写进词典最后一页。那页本来是空的。"
    "她在空白页上写下「[t_word]」，又在旁边用小字标了你的名字。"
    show aceline blush
    aceline "这一页，以后只收你教我的词。"
    $ gs.flag("aceline_dialect_word")
    $ gs.add_affinity("aceline", 7)
    hide aceline
    return


## ---------------------------------------------------------------------------
## 挚友结局
## ---------------------------------------------------------------------------
label aceline_friend_end:
    scene bg old_library
    with fade
    show aceline smile
    "一年级的最后一天。阅览室里那本没人借过的书，借阅卡上多了一个名字：你的。"
    aceline "借期一年，今天到期。"
    aceline "我替你办了续借。不用谢，图书馆的规矩我比管理员熟。"
    show aceline reading
    aceline "明年你的摘要，我还是会数“novel”。数到零为止。"
    show aceline smile
    aceline "这一年阅览室里的说话声，一大半是你的。管理员提醒过我三次。"
    hide aceline
    call reviewer_epilogue
    return


label aceline_end:
    scene bg old_library
    with fade
    show aceline smile
    "一年级的最后一天。阅览室那本没人借过的书，借阅卡上多了两个名字。"
    aceline "上面那个是我。下面那个是你，我替你写的，你不介意吧。"
    if gs.has("aceline_linguistics") and gs.has("acl_reviewed"):
        aceline "你论文里那节语言学分析，审稿人写的是“全文最有意思的部分”。"
        show aceline excited
        aceline "我把那句评语抄下来了，夹在这本词典“accept”那一页。"
        show aceline smile
    elif gs.has("aceline_linguistics"):
        aceline "你说要在论文里加一节语言学分析。我还在等。草稿也行，我帮你改。"
    if gs.has("aceline_dialect_word"):
        aceline "词典最后那页空白，现在写着你教我的那个词。注音是我自己标的，标错了你得告诉我。"
    if gs.has("aceline_honest"):
        aceline "你说过你用过大模型，也说了用在哪。那天我其实挺高兴的，就是没说出口。"
    aceline "accept，拿到自己身边来。我今年查了很多遍这个词。"
    scene cg_aceline_end
    with dissolve
    aceline "那天你的回答，我收下了。"
    aceline "这本书的借期是一年。到期了，记得来续借。"
    hide aceline
    call reviewer_epilogue
    return
