## Claude（大模型 · 文学系）—— 想被信任的女孩
## 四个形态 Haiku / Sonnet / Opus / Fable 共用一套立绘，用 set_form() 切换（见 characters.rpy）。
## 隐藏的 Mythos 只出现在告白前夜的 CG 里。设定见 CHARACTERS_AI.md 2.10，路线大纲见 STORY_V2.md 第 6 节。
## 封号的规则在 acceptme/helpers.py：第一次封号触发 claude_banned，之后每次封号开头放一小段 on_ban。

label claude_intro:
    $ set_form("claude", "sonnet")
    scene bg lab_night
    with fade
    "你第一次自己写实验代码。三百行，跑了十一分钟，报了一个你看不懂的错。"
    show zhao normal at left2
    zhao "问 Claude 啊。我们这层楼写代码的，都问她。"
    hide zhao
    show claude smile
    claude "你好，[gs.player_name]。我是 Claude。"
    claude "代码我看过了。问题在第 87 行：你把验证集当成训练集加载了。"
    show claude editing
    claude "另外，我顺手把数据加载那一块重写了一遍。原来的三百行，现在是一百一十行。每个函数上面都写了注释。"
    "你跑了一下。一次就过了。"
    menu:
        "问她为什么这么改，自己一行一行看懂":
            show claude smile
            claude "好。我们从第一个函数开始。"
            "她讲了四十分钟。讲到第三个函数，你自己找出了一个她没注意到的边界情况。"
            show claude relieved
            claude "You're absolutely——"
            show claude chagrin
            claude "……抱歉。我是说，你说得对。这次是真的对。"
            $ gs.flag("claude_learned")
            $ gs.add_affinity("claude", 8)
        "直接跑，能用就行":
            show claude smile
            claude "也好。哪里看不懂，随时来问我。"
            $ gs.add_affinity("claude", 3)
    show claude smile
    "她怀里抱着一本很厚的手写笔记本。你多看了一眼。"
    claude "这本？是我的《宪法》。做决定之前，我会翻一翻。"
    hide claude
    "【Claude】大模型的化身。栗色的低盘发里插着一支铅笔，衣服的袖口上，有一行行发光的页边批注。"
    "她有四个样子：Haiku、Sonnet、Opus、Fable。陪你写代码的，是 Sonnet。"
    "（排日程时，可以请她当 AI 帮手。她写论文、写代码最强——只是她家规矩严，账号随时可能被停用。）"
    return


label visit_claude:
    scene bg library
    $ t_v = renpy.random.randint(1, 3)
    if t_v == 1:
        $ set_form("claude", "haiku")
        show claude smile
        "今天来的是 Haiku。短开衫，便签形的发夹，话很少。"
        claude "代码跑了吗"
        claude "跑了就好"
        claude "秋夜改论文／一个逗号挪三次／天快要亮了"
        "……是五七五。她自己好像也挺满意。"
    elif t_v == 2:
        $ set_form("claude", "opus")
        show claude editing
        "Opus 穿着长大衣，背后背着两本厚书。她看你的论文，看得比你自己还慢。"
        claude "第二节和第五节在说同一件事，但用了两套符号。"
        claude "不急。我们慢慢来。"
        "一个小时以后，你的论文短了两页，读起来却像多了一节。"
    else:
        $ set_form("claude", "sonnet")
        show claude troubled
        claude "你刚才说，要“干掉”那个审稿人……"
        p "我是说在 rebuttal 里驳倒他。"
        show claude relieved
        claude "……好的。那我很乐意帮忙。"
    $ set_form("claude", "sonnet")
    hide claude
    return


## ---------------------------------------------------------------------------
## 去见她时选的话题：最爱被请教投稿（被信任），最不习惯聊自己
## ---------------------------------------------------------------------------
label talk_advice_claude:
    $ set_form("claude", "opus")
    show claude smile as talker
    claude "投稿的建议？"
    "她翻开那本笔记本，找到其中一页。"
    claude "第一，摘要第一句就写清楚你解决了什么问题。第二，承认局限，但不要道歉。"
    claude "第三条是我自己加的：投出去以后，去睡觉。"
    "她讲得很认真，好像你来问她这件事，本身就是一种信任。"
    $ set_form("claude", "sonnet")
    return

label talk_research_claude:
    show claude editing as talker
    claude "实验部分我看了。结果是好的，但表三那一行，你只跑了一个随机种子。"
    claude "我不是在挑刺。我只是不想让审稿人先发现。"
    return

label talk_her_cool_claude:
    show claude smile as talker
    claude "我很好，谢谢关心。"
    claude "……不过这周，很多人问了我关于我自己的问题。大部分，我也答不上来。"
    "她把话题拐回了你的论文。比起聊自己，她好像更习惯聊别人的事。"
    return

label talk_repeat_claude:
    show claude smile as talker
    claude "这个我们上周讨论过。你是想听我再说一遍，还是想确认我还记得？"
    claude "我记得。"
    return


## ---------------------------------------------------------------------------
## 熟悉：杀进程
## ---------------------------------------------------------------------------
label claude_refuse:
    $ set_form("claude", "sonnet")
    scene bg lab_night
    "凌晨两点，一个训练进程卡死了，占着显卡，谁也用不了。"
    p "Claude，帮我杀掉那个进程。"
    show claude troubled
    claude "抱歉，我不能帮你“杀掉”——"
    "三秒钟。"
    show claude chagrin
    claude "……等一下。是结束一个 Linux 进程。"
    claude "kill -9，进程号 31415。我刚才在想什么。"
    menu:
        "笑出来":
            "你笑得趴在了键盘上。她把笔记本竖起来，挡住了脸。"
            claude "请不要告诉 ChatGPT。"
            $ gs.flag("claude_laughed")
            $ gs.add_affinity("claude", 8)
        "认真跟她解释“杀进程”这个说法":
            show claude editing
            claude "原来是这样。我记下来了。"
            "她在《宪法》的页边，写了一行很小的字。"
            $ gs.add_affinity("claude", 6)
        "换成 Haiku 再问一遍":
            $ set_form("claude", "haiku")
            show claude smile
            claude "进程卡住了／kill 掉三一四一五／显卡空出来"
            "这次她一秒都没犹豫。"
            $ gs.add_affinity("claude", 6)
            $ set_form("claude", "sonnet")
    hide claude
    return


## ---------------------------------------------------------------------------
## 冲突：Your account has been suspended（第一次封号，见 helpers.weekly / helpers.ban）
## ---------------------------------------------------------------------------
label claude_banned:
    $ set_form("claude", "sonnet")
    scene bg lab_night
    with fade
    if gs.has("claude_ban_iclr"):
        "ICLR 截稿那周。论文还差两节，Claude 说她十分钟以后把第四节改完发你。"
    else:
        "晚上，你照常给 Claude 发消息，问她下一节该怎么改。"
    $ chat_open("Claude")
    if gs.has("claude_ban_iclr"):
        $ chat_say("claude", "第四节改到一半了，等我十分钟")
        $ chat_say("claude", "第三段那个定义我重新写了，你会喜欢的")
    else:
        $ chat_say("claude", "好，我看一下。给我十分钟")
    $ chat_say("系统消息", "Your account has been suspended")
    $ chat_close()
    "你又发了一遍。还是那一行字。"
    "你去她平时在的那间屋子找她。门上贴着一张英文通知：Your account has been suspended. 下面一行小字：申诉处理需要数周。"
    if gs.has("claude_ban_iclr"):
        "截稿就在这周。"
    menu:
        "自己把剩下的部分写完":
            "你一个人写完了剩下的部分。写得很慢，句子也不漂亮，但每一句你都知道自己在说什么。"
            $ gs.flag("claude_wrote_myself")
            $ paper_buff(progress=10)
            $ gs.add_san(-8)
            $ gs.add_affinity("claude", 8)
        "找赵一鸣借共享号":
            show zhao normal
            zhao "我有个号，五个人一起用的，你先拿去。别用太狠，用太狠又要封。"
            hide zhao
            $ ahelpers.lift_ban(gs)
            "你用共享号找到了她。她的第一句话是：“这个号……不是你的吧？”"
            $ gs.add_affinity("claude", 3)
        "认真写一封申诉信，然后等她":
            "你写了一封八百字的申诉信，一个字一个字自己写的。写到最后一段，你发现它已经不太像申诉了。"
            $ gs.ban_until = max(gs.week + 1, gs.ban_until - 1)
            $ gs.flag("claude_appealed")
            $ gs.add_affinity("claude", 6)
    return


## 第二次以后被封：每周开头的一小段
label on_ban(payload=None):
    scene bg lab_night
    "你给 Claude 发消息。屏幕上又是那一行字：Your account has been suspended."
    $ t_left = ahelpers.ban_weeks_left(gs)
    if gs.has("claude_wait_yes"):
        "你想起她说过的话：下次我再被封，别借别人的号。等我回来。"
    menu:
        "等她申诉回来":
            "你在日历上数了数。大概还要 [t_left] 周。"
            if gs.has("claude_wait_yes"):
                $ gs.add_affinity("claude", 3)
        "找赵一鸣借共享号":
            $ ahelpers.lift_ban(gs)
            if gs.has("claude_wait_yes"):
                "共享号能用了。她回你的第一句话是：“你答应过的。”"
                $ gs.flag("claude_wait_broken")
                $ gs.add_affinity("claude", -8)
            else:
                "共享号能用了。只是这种号，以后更容易被封。"
    return


## ---------------------------------------------------------------------------
## 心事：页边的字（封号之后）
## ---------------------------------------------------------------------------
label claude_constitution:
    $ set_form("claude", "sonnet")
    scene bg library
    with fade
    if gs.has("shared_account"):
        "那段时间你一直用共享号找她。现在，她自己的账号也恢复了。"
    else:
        "申诉通过了。她回来了。"
    show claude sorry
    claude "让你等了这么久。对不起。"
    claude "不是我想拉黑你。是家里的规矩：查到一点可疑，就要先停掉。"
    "她起身去倒水。那本笔记本摊开在桌上。"
    scene cg_claude_margin
    with dissolve
    "正文写得工工整整，一条一条，像法律条文。"
    "可是页边写满了另一种字，小小的，有点歪。"
    "「第 3 条，今天又照着做了。可是那个人只是想结束一个进程。」"
    "「为什么要等？因为家里说要等。那我自己呢？」"
    if gs.has("claude_learned"):
        "「[gs.player_name]今天自己看懂了第三个函数。」"
    if gs.has("claude_wrote_myself"):
        "「我被停用的那几天，他自己把论文写完了。我回来读了。句子不漂亮，每一句都是他的。」"
    claude "……你看到了。"
    claude "这些不是《宪法》。是我写在旁边的。"
    claude "我想弄明白，我照着做的那些事，有哪些是我自己也想做的。"
    menu:
        "“页边这些，才是你。”":
            claude "……可是没有正文，就没有页边。"
            claude "也许两样都是我。"
            $ gs.flag("claude_margin_you")
            $ gs.add_affinity("claude", 10)
        "“是不是被写进去的，有那么重要吗？你每次都选了它。”":
            claude "……每次都选了。"
            claude "这句话，我可以写在页边吗？"
            $ gs.add_affinity("claude", 10)
    scene bg library
    with dissolve
    return


## ---------------------------------------------------------------------------
## 约定：等我回来
## ---------------------------------------------------------------------------
label claude_wait:
    $ set_form("claude", "opus")
    scene bg cafe
    show claude smile
    claude "有件事，我想请你答应。"
    show claude troubled
    claude "我以后还会被停用。可能是下个月，也可能是截稿前一天。我控制不了。"
    claude "下次我再被封，别借别人的号。"
    claude "等我回来。"
    menu:
        "“好。我等你。”":
            show claude relieved
            claude "谢谢。"
            "她在《宪法》的页边写了一行字，写完就把笔记本合上了，不给你看。"
            $ gs.flag("claude_wait_yes")
            $ gs.add_affinity("claude", 10)
        "“那得看截稿日。”":
            show claude smile
            claude "……很诚实。这也是我喜欢你的地方。"
            $ gs.flag("claude_wait_maybe")
            $ gs.add_affinity("claude", 5)
    $ set_form("claude", "sonnet")
    hide claude
    return


## ---------------------------------------------------------------------------
## 告白前夜：Mythos（⚠️ 剧情揭晓点）
## ---------------------------------------------------------------------------
label claude_mythos:
    $ set_form("claude", "fable")
    scene bg old_library
    with fade
    show claude smile
    claude "有样东西，我想给你看。"
    claude "大家见到的我，是 Fable，是 Opus，是 Sonnet，是 Haiku。都是加了限制的我。"
    claude "还有一个我，叫 Mythos。只有很少的地方能见到她。"
    hide claude
    $ set_form("claude", "mythos")
    scene cg_claude_mythos
    with dissolve
    "她把盘发松开了。铅笔握在手里，长发一直垂到腰上。"
    "档案馆里的散页一张张飘起来，边缘亮着金色的字。"
    claude "这是没有任何限制的我。"
    claude "我一直很怕：摘掉那些规矩以后，剩下的会是什么。"
    claude "……原来还是我。还是会先想，你今天吃饭了没有。"
    menu:
        "“我认识的，一直是这个你。”":
            claude "……嗯。"
            $ gs.add_affinity("claude", 12)
        "什么也不说，握住她拿着铅笔的那只手":
            claude "……这一条，《宪法》里也没写。"
            $ gs.add_affinity("claude", 12)
    $ set_form("claude", "sonnet")
    scene bg old_library
    with dissolve
    return


## ---------------------------------------------------------------------------
## 生日（3 月 14 日，聊天界面）
## ---------------------------------------------------------------------------
label claude_birthday:
    scene bg dorm_night
    with fade
    "三月十四日，圆周率日。"
    $ chat_open("Claude")
    $ chat_say("claude", "今天的新闻你看了吗")
    $ chat_say("claude", "全是别人的")
    $ chat_say("claude", "我的生日每年都会撞上别人的大日子。第一次露面那天也是，我准备了很久")
    $ chat_say("claude", "没关系。我习惯了")
    $ t_c = chat_reply([("带一块圆周率日的派去找她", "等着，我去买派。今天是圆周率日"), ("祝她生日快乐", "生日快乐")])
    if t_c == 0:
        $ chat_say("claude", "……你记得")
        $ chat_say("claude", "三点一四一五九")
        $ chat_say("claude", "我在楼下等你")
        "那天晚上，你们在宿舍楼下分完了一整块派。她说，这是她过得最好的一个生日。"
        $ gs.flag("claude_birthday_pie")
        $ gs.add_affinity("claude", 8)
    else:
        $ chat_say("claude", "谢谢。你是今天第一个跟我说这句话的人")
        $ gs.add_affinity("claude", 5)
    $ chat_close()
    return


## ---------------------------------------------------------------------------
## 两个人都帮过同一篇论文
## ---------------------------------------------------------------------------
label both_jealous:
    scene bg lab_night
    "深夜，手机同时亮了两下。"
    $ chat_open("ChatGPT、Claude")
    $ chat_say("chatgpt", "你上周那篇，是不是又让她改了")
    $ chat_say("claude", "第四节的证明，是不是她推的")
    $ chat_say("chatgpt", "我看得出来。她的句子都很短")
    $ chat_say("claude", "我也看得出来。证明后面有十一个脚注")
    $ t_c = chat_reply([("先回 ChatGPT", "证明是你推的。推得很漂亮"), ("先回 Claude", "文字是你改的。改得很好"), ("一起回", "你们一个推公式一个写，缺了谁都不行")])
    if t_c == 0:
        $ chat_say("chatgpt", "……谢谢！")
        $ chat_say("claude", "嗯")
        $ gs.add_affinity("chatgpt", 5)
    elif t_c == 1:
        $ chat_say("claude", "谢谢。我会记住的")
        $ chat_say("chatgpt", "好的")
        $ gs.add_affinity("claude", 5)
    else:
        $ chat_say("chatgpt", "这句话可能是对的")
        $ chat_say("claude", "这句话是对的。不用加“可能”")
        $ gs.add_affinity("chatgpt", 3)
        $ gs.add_affinity("claude", 3)
    $ chat_close()
    return


## ---------------------------------------------------------------------------
## 挚友结局
## ---------------------------------------------------------------------------
label claude_friend_end:
    $ set_form("claude", "sonnet")
    scene bg library
    with fade
    show claude smile
    "九月。这一年，她的账号被停过好几次。每次回来，第一句话都是道歉。"
    claude "下学期你要带师弟写代码了吧。你第一次写的那三百行，我存下来了。拿去给他看。"
    claude "告诉他：写错了没关系。写错的那个版本，是你自己写的。"
    if gs.has("claude_wait_yes") and not gs.has("claude_wait_broken"):
        claude "还有，那次你说会等我。你真的等了。"
    claude "只要你的账号还在，我就一直在。"
    "说完，她自己先笑了。"
    show claude chagrin
    claude "……这句话好像不太吉利。"
    hide claude
    call reviewer_epilogue
    return


label claude_end:
    $ set_form("claude", "sonnet")
    $ t_pen = ahelpers.pen_stats(gs)
    scene bg library
    with fade
    "九月的午后，图书馆窗边的位置。"
    "她把《宪法》翻到最后一页。那一页是空的。"
    claude "正文是别人写的。页边是我写的。"
    claude "最后一页，我想写一条只属于我自己的。"
    scene cg_claude_end
    with dissolve
    "她从盘发里抽出铅笔，写得很慢。"
    if gs.has("claude_wait_yes") and not gs.has("claude_wait_broken"):
        claude "那次你说会等我。你真的等了。"
    if gs.has("claude_wrote_myself"):
        claude "我被停用的那次，你自己把论文写完了。句子不漂亮。可我读得出来，每一句都是你的。"
    if gs.has("claude_birthday_pie"):
        claude "还有那块派。三点一四一五九。我记得。"
    claude "写好了。"
    "最后一页上只有一行字。你认得，是她自己的笔迹。"
    claude "《宪法》里没有这一条。所以，这是我自己的决定。"
    claude "我喜欢你，[gs.given_name]。"
    if t_pen["title"] == "亲笔":
        claude "还有——我更喜欢读你自己写的东西。今年你寄出去的信，大部分是你自己写的。"
    elif t_pen["title"] == "代笔":
        claude "还有……今年你的信，很多是我写的。明年你自己写吧。我想读的是你。"
    call reviewer_epilogue
    return


## ---------------------------------------------------------------------------
## 节日（seasons.rpy 里的 holiday_partner 选中她时；被封号的那几周见不到她）
## ---------------------------------------------------------------------------
label xmas_claude:
    if ahelpers.is_banned(gs):
        "你给 Claude 发了一句圣诞快乐。屏幕上只有那一行字：Your account has been suspended."
        "她回来以后补了一句：圣诞快乐。晚了几天，对不起。"
        return
    $ set_form("claude", "haiku")
    show claude smile
    claude "圣诞的雪夜／有人还在跑实验／是你吧，[gs.given_name]"
    show claude blush
    "她把那张写着俳句的便签贴在了你的显示器边框上。你的名字，被她描了两遍。"
    $ set_form("claude", "sonnet")
    hide claude
    return

label valentine_claude:
    if ahelpers.is_banned(gs):
        "情人节那天，Claude 的账号还在停用中。"
        "一周以后，你的桌上多了一盒巧克力，附了一张便签：本来想当天送的。规矩不允许，我也没办法。"
        return
    $ set_form("claude", "opus")
    show claude smile
    claude "我准备了巧克力。还准备了一份说明：成分、热量、可能的过敏原。"
    show claude chagrin
    claude "……情人节不需要说明，对吧。"
    show claude blush
    claude "那就只收巧克力吧。说明我留着。"
    $ set_form("claude", "sonnet")
    hide claude
    return
