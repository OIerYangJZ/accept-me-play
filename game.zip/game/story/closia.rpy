## 克洛丝（虚构的无限远研究院）—— 工业界 / 神秘御姐

label closia_intro:
    scene bg cafe
    with fade
    "四月，学校门口的咖啡厅。你对面坐下一个戴面纱的人，点了一杯什么都不加的美式。"
    show closia veiled_smile
    closia "[gs.surname]先生，你好。克洛丝，无限远研究院。"
    closia "你的方向不错。"
    closia "我们半年前做完了。没发。"
    p "……"
    show closia cold
    closia "细节不便透露。暑期实习的薪资可以谈。"
    closia "我们有一万张卡。你在学校一年的算力，在我们那里够跑一个下午。"
    menu:
        "接受暑期实习":
            show closia veiled_smile
            closia "好。下周一起，你的算力配额会调上来。"
            closia "提醒一句：在研究院做的东西，不能写进论文。合同第七条。"
            $ gs.flag("closia_intern")
            $ gs.add_compute(200)
            $ gs.add_affinity("closia", 10)
            $ gs.add_affinity("kiwi", -4)
        "婉拒，想继续在学校做自己的研究":
            show closia watch
            closia "可以理解。大部分人第一次都拒绝。"
            closia "名片你留着。第二次，一般就不拒了。"
            $ gs.add_affinity("closia", 4)
    hide closia
    "【克洛丝】无限远研究院（虚构）的化身。她的脸始终藏在面纱后面。"
    return

label visit_closia:
    scene bg datacenter
    $ t_v = renpy.random.randint(1, 3)
    if t_v == 1:
        show closia veiled_smile
        closia "[gs.surname]先生。今天的工作，不便透露。"
        closia "你可以在这儿站一会儿。机房的温度是十八度，穿外套。"
    elif t_v == 2:
        show closia watch
        closia "研究院今天发了一份技术报告。九十页，一个公式都没有。"
        closia "外面都在猜我们做了什么。"
        show closia smile
        closia "里面有一半，我们自己也没搞清楚。这句不便透露。"
    else:
        show closia cold
        closia "你们学校的集群，一共多少张卡？"
        p "八张。"
        show closia surprised
        closia "八张。"
        show closia veiled_smile
        closia "用八张卡做出东西的人，我们组里有三个人想认识。我是其中一个。"
    hide closia
    return

label closia_datacenter:
    scene cg_closia_datacenter
    with dissolve
    "机房。成排的机柜一直延伸到看不见的地方，指示灯在黑暗里一闪一闪。"
    closia "这里一万张卡。"
    closia "每张都在训练一个还没有名字的模型。"
    closia "这里的事我不能跟任何人说。下班以后，也没人问。"
    closia "所有结果都保密。所有进展，对外都写成一句“取得了显著进步”。"
    menu:
        "“那你今天过得怎么样？”":
            closia "今天？"
            "她沉默了很久，久到你以为她没听见。"
            closia "三号机柜坏了一张卡。跑了四十天的任务断了，要从上一个检查点重来。"
            closia "我在那台机柜前面站了一下午。"
            $ gs.add_affinity("closia", 10)
        "“能透露一点细节吗？”":
            closia "不能。"
            $ gs.add_affinity("closia", 2)
    scene bg datacenter
    with dissolve
    return

label closia_report:
    scene bg cafe
    show closia veiled_smile
    "克洛丝把一沓打印稿推到你面前。是你挂在 arXiv 上的那篇，边角已经卷了。"
    closia "读了。三遍。"
    closia "第四节的消融实验，算力这么少，你用了这种办法验证。研究院没人想到。"
    p "你们不是什么都做过了吗？"
    show closia smile
    closia "我们有一万张卡。所以从来不需要想这种办法。"
    closia "我平时不在外面的论文上写字。公司规定，也是习惯。"
    "页边有一行很小的字：「很漂亮。——C.」"
    menu:
        "“下次你也写一篇吧。公开的那种。”":
            show closia surprised
            closia "公开？"
            show closia veiled_smile
            closia "那要很多人签字。法务、公关、三个副总裁。"
            closia "我去问。"
            $ gs.add_affinity("closia", 10)
            $ gs.flag("closia_open")
        "“谢谢。这句评论我会裱起来。”":
            show closia smile
            closia "不必。"
            closia "……裱吧。别挂在显眼的地方。"
            $ gs.add_affinity("closia", 8)
    hide closia
    return

label closia_unveil:
    scene bg datacenter
    show closia veiled_smile
    closia "[gs.surname]先生。有样东西给你看。"
    "她抬起手，把面纱往后撩了上去。"
    scene cg_closia_unveil
    with dissolve
    closia "研究院里没人见过这张脸。法务也没有。"
    closia "没有技术报告，没有保密协议。就这样。"
    menu:
        "“谢谢你愿意开源。”":
            closia "你真的很会破坏气氛。"
            closia "不过我很高兴。这句可以透露。"
            $ gs.add_affinity("closia", 12)
        "什么也不说，只是看着她":
            closia "别一直看。再看我戴回去了。"
            $ gs.add_affinity("closia", 10)
    scene bg datacenter
    with dissolve
    return

## ---------------------------------------------------------------------------
## 冲突：第九条（机房之后）
## ---------------------------------------------------------------------------
label closia_nda:
    scene bg cafe
    show closia cold
    "克洛丝把一份合同推到你面前，翻到第三页。"
    closia "你上次那个方向，研究院有个项目缺人。算力翻倍，署名有你。"
    closia "条件在第九条。"
    "第九条：项目相关的一切成果，在研究院公开之前，不得以任何形式提前发布，包括预印本。"
    if gs.met["kiwi"]:
        "你想起每天晚上八点那个准时响起的电话。"
    menu:
        "签。":
            show closia veiled_smile
            closia "明智。"
            $ gs.add_compute(120)
            $ gs.add_affinity("closia", 4)
            $ gs.flag("closia_nda_signed")
            if gs.met["kiwi"]:
                "那天晚上八点，可薇照常打来。念到第三篇的时候，她问你最近怎么不往她那儿挂东西了。"
                $ gs.add_affinity("kiwi", -5)
        "不签。":
            show closia surprised
            closia "……"
            show closia smile
            closia "你是第二个不签的人。第一个是我自己，三年前。"
            closia "后来我签了别的。"
            $ gs.flag("closia_no_nda")
            $ gs.add_affinity("closia", 8)
        "“第九条能不能改？”":
            show closia cold
            closia "不能。"
            closia "……我去问问。"
            "三周后，新版合同才发过来。第九条后面多了半句：经双方同意的预印本除外。"
            "法务卡了这么久，项目的算力只批下来一半。"
            $ gs.flag("closia_nda_amended")
            $ gs.add_compute(40)
            $ gs.add_affinity("closia", 6)
    hide closia
    return


## ---------------------------------------------------------------------------
## 约定：模型说明（页边评论之后）
## ---------------------------------------------------------------------------
label closia_card:
    scene bg datacenter
    show closia watch
    if gs.has("closia_open"):
        closia "开源批下来了。你说的“公开的那种”，就是这个。"
    else:
        closia "研究院要开源一个小模型。法务算过，开源比不开源省钱。"
    closia "模型说明里要写“已知缺陷”。工程师列了十一条，法务说写三条就够。"
    closia "[gs.surname]先生，你来改。"
    menu:
        "十一条全写":
            show closia smile
            closia "法务会来找我。"
            closia "让他们来。"
            $ gs.flag("closia_card_honest")
            $ gs.add_affinity("closia", 8)
        "挑最严重的五条":
            closia "折中。研究院最喜欢折中。"
            $ gs.add_affinity("closia", 5)
        "只写优点，缺陷让用户自己发现":
            show closia cold
            closia "这是研究院的写法。"
            closia "我以为你不会这么写。"
            $ gs.add_affinity("closia", 1)
    hide closia
    return


## ---------------------------------------------------------------------------
## 挚友结局
## ---------------------------------------------------------------------------
label closia_friend_end:
    scene bg cafe
    with fade
    show closia veiled_smile
    "九月，学校门口的咖啡厅。她又戴上了面纱，点的还是什么都不加的美式。"
    closia "明年的实习名额，你的名字我写在第一个。"
    closia "理由：你的方向不错。"
    show closia smile
    closia "这次是真的。"
    hide closia
    call reviewer_epilogue
    return


label closia_end:
    scene bg datacenter
    with fade
    show closia smile
    if gs.has("closia_intern"):
        "九月。实习结束那天，克洛丝亲自把你送到研究院门口。"
    else:
        "九月。你以客人的身份走进研究院。克洛丝在门口等你，手里拿着访客证。"
    if gs.has("closia_intern"):
        closia "你这个暑假做的东西，写不进论文。抱歉。"
        closia "不过研究院里用到它的人，都知道是谁写的。代码注释里有你的名字缩写。"
    if gs.has("closia_open"):
        closia "研究院下个月开源一个模型。是我提的。"
        closia "三个副总裁问我为什么。我说，会有人认真读。他们没听懂，但签了。"
    if gs.has("closia_no_nda"):
        closia "那份合同你没签。后来我把那一条从合同模板里删了。"
    elif gs.has("closia_nda_amended"):
        closia "你改过的那个第九条，现在是模板了。后面的人签的都是带那半句的版本。"
    if gs.has("closia_card_honest"):
        closia "模型说明的缺陷那一节，十一条原样发了。法务找了我三次，下载量第一天过万。"
    closia "明年夏天的实习名单，我已经先填了一个名字。"
    scene cg_closia_end
    with dissolve
    closia "没走流程。"
    hide closia
    call reviewer_epilogue
    return
