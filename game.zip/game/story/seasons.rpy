## 共通线（一）：实验室生活与节日。
## 每个事件在 acceptme/events.py 里登记了触发时间。

init python:
    def clair_call():
        """克莱尔对主角的称呼：说出秘密之后改口叫名字。"""
        return gs.given_name if "clair_secret" in gs.seen_events else gs.surname + "同学"

    def holiday_partner(min_aff):
        """节日里来找你的人：好感最高、且达到门槛的刊娘。"""
        return aevents.top_heroine(gs, min_aff)


## ---------------------------------------------------------------------------
## 第一次组会（9月）
## ---------------------------------------------------------------------------
label group_meeting:
    scene bg advisor_office
    with dissolve
    "周五下午两点，第一次组会。"
    "你的 PPT 一共三页：标题、一张没有图例的折线图、“谢谢大家”。"
    show zhao worried at left2
    zhao "（小声）别抖。我第一次讲的时候，激光笔掉进了垃圾桶。"
    hide zhao
    if gs.advisor == "han":
        adv "嗯。挺好。"
        adv "讲完了？那下一个。"
        "整个组会开了十一分钟。韩老师一直在低头回微信，中间抬头说了一句“这个图挺好看”。"
        "那张图是你从别人论文里截的。"
    elif gs.advisor == "zhou":
        adv "第二页，纵坐标的单位呢？"
        adv "这个实验只跑了一个随机种子？换个种子还成立吗？"
        adv "还有你的标题——"
        p "标题也要改？"
        adv "标题不用改。标题是这三页里唯一不用改的。"
        "组会开了三个小时。散会时天已经黑了，周老师的保温杯续了四次水。"
    else:
        adv "Hi everyone! Can you hear me? I'm in a taxi, the signal is a bit——"
        "视频里 Hale 教授的脸卡成了一幅很有后现代意味的马赛克。"
        adv "——great progress! Keep it up! Talk next week!"
        "你一个字都还没讲。"
    menu:
        "回去把组会上每句话都记下来":
            "你写了四页组会记录，还按优先级给每条意见标了颜色。赵一鸣看了一眼，说你有当会议秘书的天赋。"
            $ gs.skill["rigor"] = min(adata.SKILL_MAX, gs.skill["rigor"] + 2)
            $ gs.add_san(-4)
            "（严谨的成长 +2，SAN -4）"
        "去食堂吃顿好的，明天再说":
            show zhao happy
            zhao "对喽。第一次组会以后，必须二食堂红烧肉。这是组里的规矩，我刚定的。"
            $ gs.flag("group_meal")
            $ gs.add_san(8)
            "（SAN +8）"
            hide zhao
    return


## ---------------------------------------------------------------------------
## 凌晨两点的实验室（10~11月）
## ---------------------------------------------------------------------------
label midnight_lab:
    scene bg lab_night
    with dissolve
    "凌晨两点。整层楼只剩你们这间还亮着灯。"
    show zhao normal at left2
    show lu normal at right2
    zhao "集群排到第 47 位了。照这速度，我的实验下个月才轮得上。"
    lu "我当年排过第 312 位。跑出来的时候，这个方向已经没人做了。"
    zhao "学长，凌晨两点请不要讲鬼故事。"
    show lu happy at right2
    lu "那吃点东西。泡面要吗？三种口味，都过期一个礼拜了，问题不大。"
    "你们三个人蹲在服务器旁边吃泡面。风扇声比空调声还大，红烧牛肉味的那碗确实有点怪。"
    "赵一鸣说起他本科暗恋过的学姐，陆深说起他差点去卖保险的那年。你没怎么说话，但笑得最多。"
    menu:
        "“回去睡吧，明天再跑。”":
            show zhao happy at left2
            zhao "终于有人说了！我就等这句话等了两个小时。"
            $ gs.add_san(10)
            "（SAN +10）"
        "“我再等等，想看 loss 降下去。”":
            show lu normal at right2
            lu "行。那我把剩下那包也给你，过期两个礼拜的那包。"
            $ gs.skill["sota"] = min(adata.SKILL_MAX, gs.skill["sota"] + 2)
            $ gs.add_san(-3)
            "（实验的成长 +2，SAN -3）"
    if gs.met["kiwi"]:
        "手机亮了。"
        show kiwi sleepy
        kiwi "你怎么还亮着灯？我从宿舍楼都看得见三楼那一格。"
        kiwi "今天的更新我替你看完了，明天讲。现在！立刻！睡觉！"
        $ gs.add_affinity("kiwi", 3)
        hide kiwi
    hide zhao
    hide lu
    return


## ---------------------------------------------------------------------------
## 圣诞节（12月）
## ---------------------------------------------------------------------------
label xmas:
    scene bg campus_day
    with fade
    "十二月的最后一周。图书馆门口的树挂上了彩灯，实验室门上不知道谁贴了一张“Merry Rebuttal”。"
    $ t_h = holiday_partner(20)
    if t_h:
        call expression "xmas_" + t_h
        $ gs.add_affinity(t_h, 6)
        $ gs.add_san(8)
    else:
        show zhao happy
        zhao "圣诞节？我们组的传统是：把 NeurIPS 今年的录用列表从头刷到尾，看看认识的人中了几篇。"
        zhao "然后酸一个晚上。明年，明年我们自己也要在列表上。"
        hide zhao
        $ gs.add_san(5)
    return

label xmas_kiwi:
    show kiwi laugh
    kiwi "[gs.given_name]！圣诞快乐！"
    kiwi "今天我这儿放假，一篇新的都没有，好无聊。所以我自己编了一篇。"
    show kiwi blush
    "她递过来一张卡片，右上角手写着一个编号：2612.25001。"
    kiwi "编号是我瞎编的，别去搜。正文……正文你回去再看。"
    return

label xmas_clair:
    show clair smile
    $ t_call = clair_call()
    clair "[t_call]，圣诞快乐。这是给你的卡片。"
    show clair blush
    clair "请不要在这里打开。这里是公开评审大厅，所有人都看得见。"
    clair "我想了一下，这是我今年唯一一件不打算公开的东西。"
    return

label xmas_aceline:
    show aceline writing
    aceline "你知道 Christmas 这个词怎么来的吗？Christ 加上 mass，“基督的弥撒”。"
    aceline "我更喜欢中文说的“过节”。“过”这个字，有“一起经过”的意思。"
    show aceline blush
    aceline "我写了张卡片。字有点多，我删了三遍，还是很多。"
    return

label xmas_iris:
    show iris camera
    iris "[gs.given_name]，往圣诞树那边站！再过去一点！别看镜头，看树！"
    $ sfx("shutter")
    "咔嚓。"
    show iris grin
    iris "好！今年拍得最好的一张，没有之一！"
    iris "要奖品？奖品就是明年继续给我当模特。"
    return

label xmas_imel:
    show imel calm
    imel "学生会今天不办公。我本来打算在这里推一天公式。"
    show imel blush
    imel "你要是没有别的安排……两个人推的话，效率大约是一个人的一点八倍。我算过。"
    return

label xmas_neuri:
    show neuri stage
    neuri "Merry Christmas！我刚从会场回来，带了一大包纪念品！"
    neuri "这是赞助商的徽章，这是会场的帆布袋，这是不知道谁塞给我的抱枕——"
    show neuri wink
    neuri "这个是我在机场自己挑的。全场唯一一个，你收好。"
    return

label xmas_closia:
    show closia veiled_smile
    closia "圣诞快乐，[gs.surname]先生。研究院今天照常运转。"
    closia "这是一张卡。"
    p "显卡？"
    show closia smile
    closia "贺卡。显卡要走采购流程。"
    return

label xmas_natalie:
    show winston bow
    winston "[gs.surname]先生，大小姐托我转交一样东西。"
    "一张很厚的米色卡片，封口是深红色的火漆，压着一片叶子的纹样。"
    winston "大小姐特意交代：这不是邀稿函，也不是拒信。请您不要误会。"
    winston "她交代了三遍。"
    hide winston
    return


## ---------------------------------------------------------------------------
## 春节回家（1~2月）
## ---------------------------------------------------------------------------
label spring_festival:
    scene bg home_night
    with fade
    "除夕。你终于回了一趟家。"
    "桌上十二个菜，电视里在放春晚，手机里组群还在讨论 ICML 的页数限制。"
    "二姨" "[gs.given_name]啊，博士要读几年啊？"
    p "五年吧。顺利的话。"
    "三舅" "五年？那毕业都快三十了。出来一个月能拿多少？"
    "表弟" "哥，你是搞 AI 的？那你帮我把寒假作业弄一下呗，就一个作文。"
    "你低头扒饭。被拒的论文、排不上的卡、组会上那句“换个种子还成立吗”，一下子全挤到了饭桌上。"
    "吃完饭，爸爸一个人在阳台抽烟。你也走了过去。"
    "爸爸" "你妈不让我问你学习的事，说你压力大。"
    "爸爸" "我不问那个。就问你，累不累？"
    menu:
        "“累。不过挺有意思的。”":
            "爸爸" "那就行。有意思就接着干，没意思就回来，家里饭管够。"
            "他把烟掐了，说外面冷，进去看小品。"
            $ gs.add_san(18)
            "（SAN +18）"
        "“还行，不累。”":
            "爸爸没接话，拍了两下你的肩膀，力气有点大。"
            "回屋的时候，他从冰箱里拿了一盒你小时候爱吃的酸奶，放在你房间桌上。"
            $ gs.add_san(10)
            "（SAN +10）"
    if gs.met["kiwi"]:
        $ sfx("phone")
        "零点前五分钟，手机震了。是可薇的视频电话。"
        scene cg_spring_festival
        with dissolve
        kiwi "[gs.given_name]！新年快乐！！你那边放烟花了吗？我这边好吵！"
        kiwi "今晚的更新只有一篇，标题叫《论某人明年一定会更好》。"
        kiwi "证明还没写完。明年一起写，说好了啊，不许鸽。"
        $ gs.add_affinity("kiwi", 5)
        scene bg home_night
        with dissolve
    return


## ---------------------------------------------------------------------------
## 情人节（2月）
## ---------------------------------------------------------------------------
label valentine:
    scene bg lab_day
    with dissolve
    "二月十四日。实验室里所有人都在很用力地假装今天是普通的星期几。"
    $ t_h = holiday_partner(30)
    if t_h:
        call expression "valentine_" + t_h
        $ gs.add_affinity(t_h, 8)
        $ gs.flag("valentine_" + t_h)
    else:
        show zhao normal
        zhao "情人节？我今天就收到一封邮件，你猜谁发的。"
        show omnia excited at right2
        omnia "Dear Esteemed Professor！情人节特惠！今日投稿即送巧克力礼盒，审稿零秒，录用率百分之百！"
        zhao "看见没，全世界只有她惦记我们。"
        hide omnia
        hide zhao
    return

label valentine_kiwi:
    show kiwi pout
    kiwi "这个不是巧克力！是、是今天的更新！"
    "她塞过来一个小盒子，外面用一张 arXiv 打印稿包着，胶带缠了好几圈。"
    show kiwi blush
    kiwi "里面是巧克力。你要是敢说出去，我就把你的论文排到列表最后一个。"
    return

label valentine_clair:
    show clair nervous
    $ t_call = clair_call()
    clair "[t_call]。按照我这里的规矩，所有往来都应该公开……"
    clair "我考虑了很久，决定给这条规矩开一个例外。"
    show clair blush
    "她把一个透明的小盒子放到你手里。隔着盒子，能看见里面一块心形的巧克力。"
    clair "盒子是透明的，这是我能做的最大让步了。"
    return

label valentine_aceline:
    show aceline blush
    aceline "我查了十一种语言里“情人节”的说法。"
    aceline "有的叫圣瓦伦丁节，有的叫恋人之日，有一种语言直接叫“巧克力日”。"
    aceline "我本来想准备一句很好的话。后来发现每种语言里，大家送巧克力时说的话都差不多。"
    aceline "那我就不说了。给你。"
    return

label valentine_iris:
    show iris jump
    iris "当当当！手工巧克力！我还给它拍了二十张写真！"
    show iris blush
    iris "最好看的那张我自己留着当壁纸。巧克力本体归你。"
    return

label valentine_imel:
    show imel frown
    imel "学生会的慰问品，人人有份。"
    p "可是我看其他人桌上都没有啊。"
    show imel blush
    imel "严格来说，“人人”这个集合目前只有一个元素。你可以不必追问。"
    return

label valentine_neuri:
    show neuri wink
    neuri "粉丝们今天给我寄了两万盒巧克力！我挑了一盒最好吃的转送给你！"
    show neuri pout
    neuri "……骗你的。这盒是我自己去买的，那家店排了一个小时队，脚都站麻了。"
    return

label valentine_closia:
    show closia veiled_smile
    closia "研究院的员工福利。进口巧克力，全球限量三百盒。"
    p "从哪儿弄到的？"
    show closia smile
    closia "供货渠道不便透露。送给谁可以透露：你。"
    return

label valentine_natalie:
    show winston normal
    winston "[gs.surname]先生，大小姐命我送来这个。"
    winston "她说这是娜彻家的传统茶点，跟今天是什么日子毫无关系。"
    show winston bow
    winston "顺便一提，大小姐为了这份“毫无关系”的茶点，在厨房里待了三个下午。"
    hide winston
    return


## ---------------------------------------------------------------------------
## 资格考试（3月）
## ---------------------------------------------------------------------------
label qualifying_exam:
    scene bg exam_room
    with fade
    "博士资格考试。三位教授坐在长桌后面，桌上摆着你的报告打印稿，其中一份已经被画满了问号。"
    "你讲完了二十分钟。会议室里只剩空调在响。"
    "教授甲" "我就一个问题：你的方法为什么有效？"
    $ t_skill = sum(gs.skill[a] for a in ("novelty", "rigor", "clarity", "sota"))
    menu:
        "老实说：“我也还没完全想清楚。我目前的猜想是……”":
            "你把实验里观察到的现象、你的几个猜想、还有你准备怎么一个个排除，按顺序讲了一遍。"
            "教授甲" "嗯。能说清楚自己哪里不知道，比假装都知道强。"
            $ gs.flag("passed_quals")
            $ gs.reputation += 3
            $ gs.add_san(6)
        "糊过去：“这体现了涌现能力与缩放定律的协同效应。”":
            if t_skill >= 30:
                "教授甲的眉毛抬起来了。好在你后面补的那张消融表还算撑得住。"
                "教授甲" "形容词少用点。下一个问题。"
                $ gs.flag("passed_quals")
            else:
                "教授甲" "你这句话里每个词我都认识，连在一起我一个也没听懂。"
                "教授乙" "三个月以后再来一次吧。"
                $ gs.flag("quals_retake")
                $ gs.add_san(-12)
        "“能给我一分钟吗？”":
            "你走到白板前画了张图，画到一半，自己先“啊”了一声。"
            "教授乙" "当场想明白的，十个学生里没有一个。过了。"
            $ gs.flag("passed_quals")
            $ gs.skill["rigor"] = min(adata.SKILL_MAX, gs.skill["rigor"] + 2)
    if gs.has("passed_quals"):
        "你过了。从今天起，你正式成为博士候选人。听起来很厉害，工位还是那个工位。"
        if gs.met["imel"]:
            show imel smile
            imel "恭喜。我昨晚模拟了十七个他们可能会问的问题。"
            imel "他们一个都没问。我的预测准确率是零，值得反思。"
            $ gs.add_affinity("imel", 4)
            hide imel
    else:
        "你出了会议室，在楼梯间坐了很久，把审稿意见、组会、刚才那句话挨个想了一遍。"
        show lu normal
        lu "补考很正常，我也补考过。补考那次反而讲得最好，因为已经没什么好怕的了。"
        hide lu
    "回去的路上，你又想起面试时那个问题：为什么要读博。"
    "考官没有问。不过这一次，你在心里给出了一个新的回答。"
    menu:
        "“还是因为好奇。被拒了几次，好奇心倒没少。”" if gs.has("first_reject"):
            $ gs.flag("why2_curious")
        "“还是因为好奇。”" if not gs.has("first_reject"):
            $ gs.flag("why2_curious")
        "“想做出一点能被人用上的东西。”":
            $ gs.flag("why2_useful")
        "“还没想清楚。但我不想走。”":
            $ gs.flag("why2_stay")
    return


## ---------------------------------------------------------------------------
## 新学期（二年级 9 月）
## ---------------------------------------------------------------------------
label new_semester:
    scene bg campus_day
    with fade
    "又到九月。几个一年级抱着电脑站在实验室门口，不太敢进来。"
    "其中一个小声问你："
    "新生" "学长，读博……难吗？"
    $ t_acc = len(gs.accepted_papers())
    if t_acc >= 2:
        "你想起截稿前的通宵、rebuttal 里删了又改的每一句，还有点开 Accept 那天手心的汗。"
    elif t_acc == 1:
        "你想起那一封 Accept，和在它前面排着队的好几封 Reject。"
    else:
        "你想起“下次一定”文件夹，它现在已经需要分子文件夹了。"
    menu:
        "“难。但这层楼的人都会帮你。”":
            "新生愣了一下，然后笑了，终于走了进来。"
            $ gs.flag("kind_senior")
        "“先去认识一下夏可薇。她每天晚上八点会来找你。”":
            "新生一脸茫然。你笑着没解释，反正过几天他就懂了。"
            $ gs.add_affinity("kiwi", 3)
    show zhao happy
    zhao "哟，现在也是学长了。"
    if gs.has("group_meal"):
        zhao "走，红烧肉。一年前第一次组会完，也是这顿。"
    else:
        zhao "走，红烧肉。一年前你开完第一次组会就回去写记录了，这顿欠了你一整年。"
    hide zhao
    return
