## 通用剧情：NPC 事件、投稿/出分时的反应、学年结算与结局。

label zhao_intel:
    scene bg lab_day
    show zhao normal
    zhao "情报。克莱尔今年还是全公开审稿，你的意见、你的回复，路人全看得见。"
    zhao "所以 rebuttal 千万别写“审稿人显然没读懂”，会被截图挂到网上，挂三年。"
    zhao "还有个审稿人，据说戴面具，只用红笔。大家叫他 Reviewer #2。"
    p "为什么是 2？"
    show zhao worried
    zhao "不知道。他排第几都叫 #2。就跟“考试最后一题”一样，是个职位，不是编号。"
    show zhao happy
    zhao "想知道哪位刊娘最近心情怎么样，来问我。这层楼的八卦都经过我的工位。"
    menu:
        "“请你喝奶茶，换一条情报。”":
            $ t_tip = zhao_tip()
            show zhao happy
            if t_tip:
                zhao "成交！独家情报：[t_tip]。别说是我讲的。"
            else:
                zhao "成交！不过你一个刊娘都还没认识……这杯先欠着。"
            $ gs.add_san(-1)
        "“八卦我就不听了。”":
            show zhao worried
            zhao "行吧，学霸。有事再来找我。"
            $ gs.add_san(2)
    hide zhao
    return

label lu_story:
    scene bg lab_night
    show lu normal
    "凌晨一点，实验室里除了你只剩一个人。据说他读到第六年了。"
    lu "还不走？我陆深。别叫学长，叫学长显得我很老。虽然确实很老。"
    lu "我刚入学那会儿，大家还在调 ResNet 的学习率。后来出了 Transformer，我换方向。"
    lu "再后来，我做了两年的课题，被一个大模型的版本更新顺手解决了。更新日志里就一行字。"
    show lu happy
    lu "你这表情，跟我导师当时一模一样。"
    menu:
        "“那你为什么还在做？”":
            show lu normal
            lu "上礼拜有个实验，凌晨三点跑出来了。结果跟我猜的一样。"
            lu "我在楼道里走了三圈才睡得着。就为这个吧。挺没出息的。"
            $ gs.add_san(8)
            $ gs.flag("lu_hope")
        "“我一定在三年级之前毕业。”":
            show lu worried
            lu "好。这句话我当年在这个位置也说过，就这张椅子。"
            lu "加油，我是认真的。你毕业那天我请你吃饭——如果那时候我还在的话。"
            $ gs.add_san(-3)
    hide lu
    return

label paradigm_shift:
    scene bg lab_day
    show zhao surprised
    zhao "出事了！无限远研究院发了个新模型，十二个榜单全刷了一遍！"
    zhao "组群里已经有三个人在问“现在换方向还来得及吗”。"
    python:
        hit = [pp for pp in gs.papers if pp.topic == "llm" and pp.status in ("draft", "rejected")]
        for pp in hit:
            pp.attrs["novelty"] *= 0.85
    if hit:
        "你点开了你那篇大模型课题的 baseline 表格。新模型比你的方法高了四个点。"
        "还好，不是十个点。你在心里默默地把“创新性”那一栏改小了一号字体。"
        $ gs.add_san(-8)
    else:
        "幸好你做的不是大模型。你松了口气，然后又有点说不清的失落——好像错过了什么热闹。"
    show lu normal at right2
    lu "范式转移嘛，一两年一次，跟换季差不多。记得多穿点。"
    menu:
        "连夜把新模型的论文读完":
            "读到凌晨三点。新模型确实强，但你在附录里找到了它没解决的一个问题。"
            $ paper_buff(novelty=4)
            $ gs.ideas += 1
            $ gs.add_san(-5)
        "关掉群聊，接着做自己的":
            "你把组群设成了免打扰。外面怎么刮风，这周先不管了。"
            $ gs.add_san(5)
    hide lu
    hide zhao
    return


## ---------------------------------------------------------------------------
## 出分时的通用反应
## ---------------------------------------------------------------------------
label react_generic_accept:
    "你把那封邮件看了五遍，又刷新了一次邮箱，确认 ACCEPT 这几个字母没有变成别的。"
    if gs.met["kiwi"]:
        show kiwi laugh
        kiwi "[gs.given_name]！我看到了！！我把你那篇的编号设成今天的头条了！"
        kiwi "虽然我这儿本来就没有头条这个功能。我刚刚手动加的。"
        hide kiwi
    return

label react_generic_reject:
    if gs.low_san:
        scene bg lab_night at low_san_filter
        "又是这样。"
        "你盯着拒信看了很久，开始认真考虑楼下奶茶店招不招人。"
    else:
        "被拒了。你把审稿意见拖进一个叫“下次一定”的文件夹，文件夹里已经有了它的兄弟姐妹。"
    if gs.met["kiwi"] and gs.has("kiwi_failure"):
        show kiwi normal
        kiwi "拒信发我一份？我想看看审稿人到底说了什么。骂得不对的地方我帮你骂回去。"
        hide kiwi
        $ gs.add_san(5)
    return


## ---------------------------------------------------------------------------
## 第一学年结算
## ---------------------------------------------------------------------------
label year_end:
    $ renpy.block_rollback()
    scene bg campus_day
    with fade
    "九月快过完了。银杏开始黄了，食堂的红烧肉涨了一块钱。"
    "一年级就这么结束了。"
    $ year_sum = aending.summary(gs)
    if autoplay:
        $ ap_trace("year_end %r" % (year_sum,))
    call screen year_summary(year_sum)
    call expression year_sum["ending"]
    if autoplay:
        $ aauto.CONFIG["finished_week"] = gs.week
        $ aauto.CONFIG["finished_ending"] = year_sum["ending"]
        $ ap_trace("finished")
    "—— 第一学年 · 完 ——"
    "感谢游玩《Accept Me!》MVP 版本。二年级，敬请期待。"
    return

label normal_end:
    scene bg lab_day
    with fade
    if gs.has("zhao_left"):
        "赵一鸣的工位空了。桌上贴着一张便利贴：“八卦交接清单（共三页）”，第一条写着“二食堂周三的红烧肉最大块”。"
        "你给他发消息说一年了。他回得很快：“报个数，还活着吗？周末回来请你吃饭。”"
    else:
        show zhao happy
        zhao "一年了。你还活着吗？报个数。"
        p "活着。比去年这个时候，稍微知道自己在干嘛了一点。"
        if gs.has("zhao_stayed"):
            zhao "我那篇中了。你说得对，就差一点。今天红烧肉我请，两份。"
        else:
            zhao "一点就够了。我去年连这一点都没有。走，今天我请，二食堂。"
        hide zhao
    $ t_why = why_lines()
    if t_why:
        python:
            for _l in t_why:
                renpy.say(narrator, _l)
        "一年过去，你还在这间实验室。工位上的打印稿摞得比显示器还高。"
    call reviewer_epilogue
    $ t_almost = almost_heroine()
    if t_almost:
        "晚上，手机亮了一下。"
        $ renpy.say(narrator, ALMOST_MSG[t_almost])
    return

label rest_end:
    scene bg dorm_night
    with fade
    "这一年你倒下了两次。第二次是在组会上，PPT 才翻到第二页。"
    "校医让你多睡觉。导师签了休学申请，签完又在后面补了一句“好好吃饭”。"
    show lu normal
    lu "休学不丢人，我二年级也休过一学期。回来的时候，我那个方向已经没人做了。"
    lu "所以你看，论文跑不了。人得先在。"
    hide lu
    if gs.met["kiwi"]:
        show kiwi lonely
        kiwi "休学的时候，我晚上八点还是会来的。"
        show kiwi normal
        kiwi "不念论文。就问你今天吃了什么，有没有出门晒太阳。你敢说没有试试看。"
        hide kiwi
    "你在宿舍楼下站了一会儿。太阳挺好的。"
    return

## 审稿人的结局：你最终成为了怎样的审稿人
label reviewer_epilogue:
    $ t_title = aending.reviewer_title(gs)
    if sum(gs.karma.values()) == 0:
        "这一年你一份审稿意见都没写过。不过系统迟早会给你分稿子的，大概在你最忙的那一周。"
        return
    "这一年，你也审了别人的稿子。"
    if gs.karma["harsh"] >= 2 and gs.karma["harsh"] >= gs.karma["careful"]:
        "某天晚上整理邮件，你翻到自己写的一份审稿意见，第一句是：“作者显然不了解这个领域。”"
        "你盯着这句话看了半天。这口气，你在哪儿见过。"
        if gs.has("rev2_unmasked"):
            "你想起咖啡厅里那张疲惫的脸，把这句删了，重写了一份。写到凌晨两点。"
    elif gs.karma["llm"] >= 2 and gs.karma["llm"] >= gs.karma["careful"]:
        "有位作者在回复里写：“感谢审稿人 commendable 且 comprehensive 的意见。”"
        "你怀疑他也是用大模型写的回复。你们俩的大模型聊得挺开心。"
    else:
        "你写过的每一份意见，都是读完整篇论文才写的。有一篇你还顺手帮作者找出了一个公式下标错误。"
        if gs.has("helped_delve"):
            "戴尔夫发来消息：“这次八篇，全是我自己读的。审完人都瘦了。”"
        if gs.has("rev2_unmasked"):
            "听说那个戴面具的人，最近在审稿意见里写了一句“这个想法很有意思”。全组的人都以为他被盗号了。"
    "（审稿人称号：[t_title]）"
    return
