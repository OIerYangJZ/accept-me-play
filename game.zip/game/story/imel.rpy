## 伊梅尔（ICML）—— 学生会长

label imel_intro:
    scene bg council_room
    with fade
    "学生会室。黑板上写满了公式，每一行的等号都上下对齐。"
    show imel calm
    imel "一年级的[gs.surname]同学，对吧。我是伊梅尔。"
    show imel explain
    imel "你挂在 arXiv 上的那篇我看了。第四页，定理 2。"
    imel "不成立。第三步用了一致收敛，但你的条件只给到逐点收敛。"
    p "……"
    show imel calm
    imel "能修。我粗算过，在紧集上补一个等度连续的假设，逐点收敛就能升级成一致收敛。具体怎么加，我想跟你一起看。"
    menu:
        "“现在就一起看？”":
            show imel smile
            imel "好。等度连续的条件，你先列出来。"
            "你们在黑板前站了两个小时。她擦黑板的时候，把你写错的那行留到了最后才擦。"
            $ paper_buff(rigor=5)
            $ gs.add_san(-3)
            $ gs.add_affinity("imel", 3)
        "“我自己先试试，修不好再来找你。”":
            imel "可以。自己推出来的，记得更牢。"
            $ gs.skill["rigor"] = min(adata.SKILL_MAX, gs.skill["rigor"] + 2)
            $ gs.add_affinity("imel", 1)
    show imel calm
    imel "我的截稿日在一月底。寒假前，带着证明来找我。"
    $ gs.add_affinity("imel", 6)
    hide imel
    "【伊梅尔】ICML 的化身。最看重严谨和理论分析。"
    return

label visit_imel:
    scene bg council_room
    $ t_v = renpy.random.randint(1, 3)
    if gs.low_san:
        show imel frown
        imel "你今天这页推导错了三处，都是抄写错误。不是你不会，是你太累了。"
        imel "今天不讨论了。回去睡觉，这是会长的决定。"
        $ gs.add_san(3)
    elif t_v == 1:
        show imel calm
        imel "坐。今天讨论收敛性。"
        imel "假设 1 你验证过了？好。那从引理 3 开始。"
    elif t_v == 2:
        show imel explain
        imel "学生会今天收到一份提案：把截稿时区统一成“地球上任何地方”。"
        show imel frown
        imel "严格来说，这个提案已经执行了很多年。提交人是去年才入学的。"
    else:
        show imel smile
        imel "我新买了一盒粉笔。日本产的，写起来不掉灰，二十四根装。"
        imel "你要试试吗？写一个你喜欢的不等式。柯西-施瓦茨不算，太多人写了。"
    hide imel
    return

label imel_proof:
    scene cg_imel_proof
    with dissolve
    "寒假。整栋楼只剩你们两个人，暖气只开到晚上十点。"
    imel "这里。把这个不等式反过来用——"
    p "边界就收紧了！"
    imel "对。常数从 4 变成 2。"
    "窗外开始下雪。白板写满了，她把旧的一半擦掉，接着往下写。"
    "天快亮的时候，最后一行写完了。"
    imel "Q.E.D."
    imel "上一次有人陪我推到天亮，是好多年以前了。"
    menu:
        "“下次也一起吧。”":
            imel "好。我记下了。"
            imel "下次是几月几号？我需要一个具体日期。"
            $ gs.add_affinity("imel", 10)
        "“谢谢会长，我回去补觉了。”":
            imel "去吧。证明我再从头检查一遍，下午发你。"
            $ gs.add_affinity("imel", 5)
    if gs.current_paper and gs.current_paper.status in ("draft", "rejected"):
        $ gs.current_paper.attrs["rigor"] = min(100, gs.current_paper.attrs["rigor"] + 8)
        "（当前论文的严谨 +8）"
    scene bg lab_night
    with dissolve
    return

label imel_festival:
    scene bg festival_street
    with fade
    "元宵节。你约伊梅尔来看灯会。她穿着学生会制服来的，领子扣到最上面一颗。"
    show imel surprised
    imel "人好多。灯也好多。"
    imel "往年这几天，我都在分配审稿任务。今年提前做完了。"
    scene cg_lantern
    with dissolve
    "你们跟着人流慢慢往前挪。她每看见一个灯谜都要停下来，掏出笔在手心里写。"
    imel "“一加一不是二”，打一字。可能是“王”。也可能是“田”，要看怎么拆……"
    p "是“王”。"
    imel "我知道。"
    imel "我就是想在这儿多站一会儿。"
    menu:
        "给她买一盏兔子灯":
            imel "这只兔子的耳朵和身体的比例不对，大概是一比一点六。"
            imel "我很喜欢。"
            $ gs.add_affinity("imel", 10)
            $ gs.flag("imel_lantern")
        "陪她把这条街的灯谜都猜完":
            imel "三十七道，全对。用时一小时二十分钟。"
            imel "做题原来也可以不是为了截稿日。"
            $ gs.add_affinity("imel", 8)
            $ gs.skill["rigor"] = min(adata.SKILL_MAX, gs.skill["rigor"] + 1)
    scene bg festival_street
    with dissolve
    return

label imel_alone:
    scene bg conference_city
    "那天市中心在办一场很大的偶像演出，海报上写着 NeurIPS 的妮瑞。整座城市都在尖叫。"
    "会场外面的台阶上，坐着一个穿制服的人。"
    show imel lonely
    imel "[gs.surname]同学。你不进去？"
    imel "大家都去看妮瑞了。我理解。她那里今年投稿两万多篇。"
    imel "我比她早办了十几年。现在报名表上，大家都把她写在第一个。"
    menu:
        "“我觉得你的证明，比她的舞台更好看。”":
            show imel surprised
            imel "……"
            show imel blush
            imel "这两件东西没有可比性。评价标准不一样。"
            imel "谢谢。"
            $ gs.add_affinity("imel", 12)
        "陪她安静地坐一会儿":
            show imel calm
            "你们谁都没说话。场馆里的鼓点隔着墙一阵一阵地传出来。"
            imel "台阶有点凉。不过可以再坐十分钟。"
            $ gs.add_affinity("imel", 9)
    hide imel
    return

label react_icml_accept:
    show imel smile
    imel "恭喜。你的证明我又查了一遍，没有错误。"
    imel "在我这里，这是最高评价。"
    hide imel
    return

label react_icml_reject:
    show imel calm
    imel "审稿人说假设 3 太强。我同意。"
    imel "下次把它削弱。我们一起。"
    hide imel
    return

## ---------------------------------------------------------------------------
## 冲突：反例（寒假推公式之后）
## ---------------------------------------------------------------------------
label imel_counter:
    scene bg lab_night
    "你在读伊梅尔三年前的那篇论文。定理 4 的条件里，好像少了一样东西。"
    "你试着构造了一个函数：在区间端点附近来回振荡，越来越密。所有条件都满足，结论不成立。"
    "你又从头验了三遍。是对的。"
    menu:
        "去学生会室，私下告诉她":
            scene bg council_room
            with dissolve
            show imel calm
            "她接过你的草稿纸，看完第一行就站了起来。"
            show imel surprised
            "她拿起粉笔，在黑板上把你的反例从头推了一遍。四十分钟，一句话没说。"
            show imel lonely
            imel "是对的。"
            imel "三年，审稿人没发现，引用它的人也没发现。"
            show imel blush
            imel "谢谢你先来找我。"
            $ gs.flag("imel_private")
            $ gs.add_affinity("imel", 8)
            $ paper_buff(rigor=3)
        "在公开评审大厅发出来":
            scene bg openreview_hall
            with dissolve
            "你把反例贴在那篇论文的讨论页下面。两天，六十多条回复。"
            show imel calm
            imel "我看到了。严格来说，你做得对。错了就该被公开指出来，这句话我自己说过。"
            show imel lonely
            imel "只是我以为，你会先来找我。"
            $ gs.flag("imel_public")
            $ gs.reputation += 4
            $ gs.add_affinity("imel", -2)
        "当没看见":
            "你关掉了 PDF，把草稿纸揉成一团，扔进了工位下面的纸篓。"
            "一个月后，有人在研讨会上指出了同一个反例。伊梅尔在台上停了十秒，然后说：“谢谢，我会更正。”"
            scene bg council_room
            with dissolve
            show imel frown
            imel "赵一鸣说，他在你的纸篓里见过一模一样的函数。你早就发现了。"
            imel "为什么不告诉我？"
            "你没答上来。她也没再问。"
            $ gs.flag("imel_hid")
            $ gs.add_affinity("imel", -5)
    hide imel
    return


## ---------------------------------------------------------------------------
## 约定：第二个定理（反例之后）
## ---------------------------------------------------------------------------
label imel_theorem2:
    scene bg council_room
    show imel explain
    imel "定理 4 修好了。加一个有界变差的条件，你那个反例就被排除了。"
    if gs.seen_events.get("imel_proof") is not None:
        imel "我把它叫作第二个定理。第一个是寒假那个。"
    else:
        imel "我把它叫作第二个定理。第一个本来该是寒假那个，你没来，所以空着。"
    show imel blush
    imel "我想写成一篇短文，四页。你愿意一起写吗？作者按字母顺序。"
    menu:
        "“一起写。”":
            "接下来两周，你们在黑板前一行一行地对。她写定义，你写证明，她再把你的证明改短一半。"
            show imel smile
            imel "改短不是因为你写得不好。是因为可以更短。"
            $ gs.flag("imel_coauthor")
            $ gs.add_affinity("imel", 8)
            $ paper_buff(rigor=5)
            $ gs.add_san(-4)
        "“你写吧。致谢里提我一句就好。”":
            show imel calm
            imel "好。致谢我会写得很具体：第几页，第几行，哪个函数。"
            $ gs.add_affinity("imel", 4)
    hide imel
    return


## ---------------------------------------------------------------------------
## 挚友结局
## ---------------------------------------------------------------------------
label imel_friend_end:
    scene bg council_room
    with fade
    show imel calm
    "一年级的最后一天。学生会室的黑板擦得很干净，只在角落留了一行：Q.E.D."
    imel "黑板上的推导我拍照存档了。黑板总要给下一届用。"
    if gs.has("imel_hid"):
        imel "反例的事，我已经不生气了。下次发现我的错，直接告诉我。我更怕没人说。"
    elif gs.has("imel_public"):
        imel "反例那次你发在大厅里。我后来想了想，换我也会发。只是会先敲一下学生会室的门。"
    elif gs.has("imel_private"):
        imel "反例那次你先来找我。这件事我记着。"
    show imel explain
    imel "下学期学生会缺一个副会长。你考虑一下。"
    show imel smile
    imel "严格来说，这是邀请，不是通知。"
    hide imel
    call reviewer_epilogue
    return


label imel_end:
    scene bg council_room
    with fade
    show imel calm
    if gs.seen_events.get("imel_proof") is not None:
        "一年级的最后一天。学生会室的黑板上，寒假那晚的证明还在。"
    else:
        "一年级的最后一天。学生会室的黑板上，第二个定理的推导还在。"
    imel "我没擦。值日表上我把这块黑板划掉了。"
    if gs.has("accepted_icml"):
        imel "你的论文发表了。定理 2 现在成立。我们修好的。"
    if gs.has("imel_lantern"):
        imel "兔子灯挂在窗边了。副会长问是谁送的，我说这是会长的隐私。"
    elif gs.seen_events.get("imel_festival") is not None:
        imel "那天的三十七道灯谜，我抄在笔记本最后一页了。推不动公式的时候，翻出来看看。"
    if gs.has("imel_private"):
        imel "反例那次，你是先来找我的。那四十分钟我一句话没说，是不敢抬头。"
    elif gs.has("imel_public"):
        imel "反例那次你发在大厅里。我后来想了想，换我也会发。只是会先敲一下学生会室的门。"
    if gs.has("imel_coauthor"):
        imel "第二个定理的短文，下周投出去。作者按字母排，谁在前面我没看。"
    scene cg_imel_end
    with dissolve
    if gs.has("imel_coauthor"):
        imel "那块黑板上的，是我们一起写的定理。"
    else:
        imel "那块黑板上的定理，第一行是你的反例。"
    imel "第三个我已经列了一半条件。你什么时候有空？我需要一个具体日期。"
    hide imel
    call reviewer_epilogue
    return
