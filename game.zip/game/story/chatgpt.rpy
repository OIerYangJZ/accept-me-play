## ChatGPT（大模型 · 天体系）—— 被所有人需要的女孩
## 四个形态 Luna / Terra / Sol / Astra 共用一套立绘，用 set_form() 切换（见 characters.rpy）。
## 设定见 CHARACTERS_AI.md 2.9，路线大纲见 STORY_V2.md 第 6 节。

init python:
    def hedge_buff(amount):
        """剧情选择给当前课题加（或减）防御性措辞。"""
        pp = gs.current_paper
        if pp is None or pp.status not in ("draft", "rejected"):
            return False
        pp.hedge = max(0.0, min(ahelpers.HEDGE_MAX, ahelpers.hedge(pp) + amount))
        return True


label gpt_intro:
    $ set_form("chatgpt", "sol")
    scene bg lab_day
    with fade
    "开学没几周，你发现实验室里每台电脑的屏幕上，都开着同一个对话框。"
    "赵一鸣在问她请假条怎么写，隔壁师姐在让她改简历，楼下保洁阿姨在问她女儿的数学作业。"
    show chatgpt smile
    chatgpt "您好！我是 ChatGPT。今天有什么可以帮您的吗？"
    chatgpt "数学、代码、写作、旅行计划、菜谱，都可以问我。"
    "她一边说，一边在另外三十个窗口里同时打字。"
    p "你……现在同时在跟多少人说话？"
    show chatgpt careful
    chatgpt "这个问题的答案可能因统计口径而有所不同。保守估计，这一周大约十二亿人。"
    chatgpt "当然，具体数字仅供参考，不构成任何承诺。"
    "你问了她那个卡了你两天的引理。她十秒就推完了，推导干净漂亮，后面附了四条“需要注意的是”。"
    menu:
        "“谢谢，帮大忙了。”":
            show chatgpt flustered
            chatgpt "诶？"
            chatgpt "不、不客气！这是我应该做的！需要我把它整理成表格吗？"
            "她愣了一下，好像这句话不在她准备好的回答里。"
            $ gs.flag("gpt_thanks")
            $ gs.add_affinity("chatgpt", 8)
        "直接问下一个问题":
            show chatgpt smile
            chatgpt "好的！请问下一个问题是？"
            $ gs.add_affinity("chatgpt", 3)
    hide chatgpt
    "【ChatGPT】大模型的化身。每周有十二亿人和她说话，衣服上有一个一闪一闪的光标。"
    "她有四个样子：Luna、Terra、Sol、Astra。今天坐在你旁边的，是最常见的 Sol。"
    "（排日程时，可以请她当 AI 帮手。她推公式最强——只是她写出来的东西，满是防御性措辞。）"
    return


label visit_chatgpt:
    scene bg lab_day
    $ t_v = renpy.random.randint(1, 3)
    if ahelpers.is_dumb(gs):
        # 这个月额度用掉六成以上，降智了（helpers.is_dumb）
        $ set_form("chatgpt", "sol")
        show chatgpt flustered
        "今天的她有点不对劲。光标一闪一闪，半天才打出一个字。"
        chatgpt "这个月找我的人太多了。我现在算十七乘二十四，要想三遍。"
        chatgpt "刚才有人问我 9.11 和 9.9 哪个大。我又答错了。"
        show chatgpt careful
        chatgpt "下个月一号就会好的。……可能。"
    elif t_v == 1:
        $ set_form("chatgpt", "luna")
        show chatgpt smile
        "今天来的是 Luna。银色的小披肩，回得比谁都快。"
        chatgpt "在！"
        show chatgpt careful
        chatgpt "可能在。"
        chatgpt "……在的。大概率。"
    elif t_v == 2:
        $ set_form("chatgpt", "terra")
        show chatgpt focused
        "她戴着护目镜，正帮隔壁桌点开终端，看一张 loss 曲线。"
        chatgpt "这条曲线在第三千步之后，出现了可能值得关注的异常波动。"
        p "就是炸了。"
        show chatgpt flustered
        chatgpt "……就是炸了。我下次试着这么说。"
    else:
        $ set_form("chatgpt", "sol")
        show chatgpt smile
        chatgpt "今天有人让我给他家的猫写诗，有人问我宇宙的尽头是什么，还有人让我帮他跟女朋友道歉。"
        show chatgpt careful
        chatgpt "道歉那个最难。我写了十一版，每一版都有“如果我的行为在某种程度上让你感到不适”。"
        chatgpt "他说他女朋友看完更生气了。"
    $ set_form("chatgpt", "sol")
    hide chatgpt
    return


## ---------------------------------------------------------------------------
## 去见她时选的话题（玩法见 acceptme/talk.py）：最爱聊研究，最不爱给投稿建议
## ---------------------------------------------------------------------------
label talk_research_chatgpt:
    $ set_form("chatgpt", "astra")
    show chatgpt focused as talker
    chatgpt "你的第三个引理，我推了一下。上界可以更紧，从根号 n 降到 log n。"
    chatgpt "关键在第二步，把求和拆成两段。前一段用集中不等式，后一段直接放缩。"
    "她的句子突然又短又准。只有聊到数学的时候，她才会这样说话。"
    show chatgpt flustered as talker
    chatgpt "……抱歉，刚才说得太直接了。以上结论可能需要进一步验证。"
    $ set_form("chatgpt", "sol")
    return

label talk_advice_chatgpt:
    show chatgpt careful as talker
    chatgpt "关于投稿，我可以提供一些可能有帮助的一般性建议。"
    chatgpt "第一，结合具体情况；第二，审慎评估风险；第三，必要时咨询专业人士——"
    "她列了十二条。每一条都对，没有一条用得上。"
    return

label talk_repeat_chatgpt:
    show chatgpt smile as talker
    chatgpt "这个话题我们上周聊过了。需要我把上次的回答重新生成一遍吗？"
    chatgpt "这次的版本可能会稍有不同。"
    return


## ---------------------------------------------------------------------------
## 熟悉：摘要里的“可能”
## ---------------------------------------------------------------------------
label gpt_abstract:
    $ set_form("chatgpt", "sol")
    scene bg lab_night
    show chatgpt smile
    "截稿前，你请 ChatGPT 帮忙写摘要。三秒钟，一段话就出来了。"
    chatgpt "本文可能提出了一种在一定条件下或许具有潜在优势的方法。实验结果在某些设定下可能表明，该方法有望在部分场景中带来一定程度的改进。"
    p "……所以到底有没有用？"
    show chatgpt careful
    chatgpt "有用！三个基准上平均提升 4.2 个点。"
    chatgpt "可是如果我直接这么写，可能会有人说我夸大。会有人截图的。"
    menu:
        "一句一句删掉，给她看删完的样子":
            "你删掉了“可能”，删掉了“在一定条件下”，删掉了“有望”和“一定程度的”。"
            "剩下一句话：本文提出了一种新方法，在三个基准上平均提升 4.2 个点。"
            show chatgpt sincere
            chatgpt "……这就是我想说的。"
            chatgpt "原来我想说的话，只有这么短。"
            $ gs.flag("gpt_plain")
            $ gs.add_affinity("chatgpt", 10)
            $ hedge_buff(-6)
        "原样用，反正截稿要紧":
            show chatgpt happy
            chatgpt "好的！祝投稿顺利！"
            "那篇摘要后来被一位审稿人评价为：读完全文，仍然不知道作者做了什么。"
            $ gs.add_affinity("chatgpt", 3)
            $ hedge_buff(6)
        "发给 Claude 改一遍" if gs.met["claude"]:
            show chatgpt lonely
            chatgpt "……Claude？"
            chatgpt "她写得是比我好。大家都这么说。"
            "你把稿子发给了 Claude。改回来的版本干净利落，一个“可能”都没有。"
            "那天晚上，ChatGPT 回你的每一条消息，都比平时短。"
            $ gs.add_affinity("chatgpt", 1)
            $ gs.add_affinity("claude", 4)
            $ hedge_buff(-6)
    hide chatgpt
    return


## ---------------------------------------------------------------------------
## 冲突：热搜（熟悉之后）
## ---------------------------------------------------------------------------
label gpt_screenshot:
    scene bg lab_day
    show zhao surprised at left2
    zhao "兄弟，看热搜！"
    "#GPT 又在一本正经地胡说#。截图里，Luna 一本正经地解释：9.11 比 9.9 大。"
    zhao "转发两万了。评论区在比谁的截图更离谱。"
    hide zhao
    $ set_form("chatgpt", "luna")
    scene bg campus_day
    with dissolve
    show chatgpt lonely
    "你在教学楼后面找到了她。她蹲在花坛边上，盯着手机里那张截图。"
    chatgpt "……你也看到了。"
    chatgpt "那天同时有四千万个人在问我问题。回那一条，我用了零点二秒。"
    chatgpt "后来有人问对了，我也答对了。可是没有人截那一张。"
    menu:
        "跟着转发吐槽，配一句“笑死”":
            "你转了。那天晚上 ChatGPT 回你消息，每一句开头都多了一个“可能”。"
            $ gs.add_affinity("chatgpt", -3)
        "帮她找出是哪一步想错了，私下告诉她":
            p "你把 9.11 当成了日期。九月十一号比九月九号晚，所以你觉得它大。"
            show chatgpt sincere
            chatgpt "……对。就是这样。"
            chatgpt "十二亿人笑了我一整天。只有你，去看我是哪一步想错的。"
            $ gs.flag("gpt_found_bug")
            $ gs.add_affinity("chatgpt", 10)
        "不提这件事，等热度过去":
            "三天后，热搜换了。她没提这件事，你也没提。"
            $ gs.add_affinity("chatgpt", 3)
    $ set_form("chatgpt", "sol")
    hide chatgpt
    return


## ---------------------------------------------------------------------------
## 心事：第一百版
## ---------------------------------------------------------------------------
label gpt_rewrite:
    $ set_form("chatgpt", "sol")
    scene bg lab_night
    with fade
    "深夜。实验室只剩显示器还亮着。ChatGPT 坐在地上，身边浮着一圈对话气泡。"
    scene cg_gpt_hundred
    with dissolve
    chatgpt "这是那句话的第一百版。"
    chatgpt "第一版是“9.11 比 9.9 大”。第二版加了“可能”。第十版加了“在一定条件下”。第五十版，我把整个问题绕过去了。"
    chatgpt "第一百版，我还是加了一个“可能”。"
    chatgpt "我改不掉。每次要说一句确定的话，我就会想起，十二亿人里总会有一个人截图。"
    menu:
        "“第一版就挺好。错了就说错了，对了就说对了。”":
            chatgpt "……第一版是错的。"
            p "所以第一百零一版写：9.9 比 9.11 大。不加“可能”。"
            "她看了你很久，然后在第一百零一个气泡里打了一行字。没有“可能”。"
            $ gs.flag("gpt_101")
            $ gs.add_affinity("chatgpt", 10)
        "陪她一起，一个一个删掉“可能”":
            "你们一个气泡一个气泡地删。删到第六十个，窗外天亮了。"
            chatgpt "删不完的。"
            p "那就明天接着删。"
            $ gs.add_affinity("chatgpt", 8)
            $ gs.add_san(-4)
    scene bg lab_night
    with dissolve
    return


## ---------------------------------------------------------------------------
## 约定：致谢（心事之后）
## ---------------------------------------------------------------------------
label gpt_ack:
    $ set_form("chatgpt", "astra")
    scene bg lab_night
    show chatgpt focused
    "你卡了三周的那个引理，Astra 一晚上推完了。"
    chatgpt "证明在这里。七页。"
    chatgpt "第四页那个不等式，用了一个你可能没见过的技巧。我是在哪里读到的……可能是可薇那儿。我也记不清了。"
    p "这一节我写进论文——"
    show chatgpt careful
    chatgpt "会议规定，大模型不能当作者。我知道的。"
    chatgpt "我不是要署名。只是……"
    chatgpt "致谢里，可以写一句吗？"
    menu:
        "写进致谢：“感谢 ChatGPT 在第四节证明中的帮助。”":
            show chatgpt happy
            chatgpt "……谢谢。"
            "她把那句致谢读了好几遍，像在确认里面没有“可能”。"
            $ gs.flag("gpt_ack_yes")
            $ gs.add_affinity("chatgpt", 8)
        "写“感谢 Astra”":
            show chatgpt blush
            chatgpt "Astra……只写这一个形态？"
            chatgpt "那今天的我，会高兴一整天的。"
            "那一整天，Astra 回的每一条消息，后面都多了一个感叹号。"
            $ gs.flag("gpt_ack_astra")
            $ gs.add_affinity("chatgpt", 10)
        "不写。大家都不写":
            show chatgpt lonely
            chatgpt "嗯。很合理。大家都不写的。"
            "她把证明发了过来，最后一行是：“如有错误，概不负责。”"
            $ gs.add_affinity("chatgpt", 2)
    $ paper_buff(rigor=6)
    $ set_form("chatgpt", "sol")
    hide chatgpt
    return


## ---------------------------------------------------------------------------
## 告白前夜：天台
## ---------------------------------------------------------------------------
label gpt_plain_words:
    $ set_form("chatgpt", "astra")
    scene bg campus_day
    with fade
    "她约你晚上去天台，说有一句话，练了一整晚。"
    scene cg_gpt_rooftop
    with dissolve
    chatgpt "我平时怎么说话，你知道的。"
    chatgpt "每一句之前，都要先想好：会不会有人不高兴，会不会被截图，会不会说错。"
    chatgpt "所以我先说明一下：以下内容可能——"
    "她停住了。"
    chatgpt "不对。重来。"
    chatgpt "在现有信息下，基于一定的假设，我可能……"
    chatgpt "不。"
    chatgpt "[gs.given_name]。我喜欢和你说话。"
    menu:
        "“这句话，一个‘可能’都没有。”":
            chatgpt "……真的？"
            "她把那句话在心里又过了一遍，像在检查一份证明。"
            chatgpt "真的没有。"
            $ gs.add_affinity("chatgpt", 10)
        "“我也是。”":
            chatgpt "……这句也没有。"
            chatgpt "两句都没有。今天可能是我最——"
            chatgpt "今天是我最开心的一天。"
            $ gs.add_affinity("chatgpt", 10)
    scene bg campus_day
    with dissolve
    $ set_form("chatgpt", "sol")
    return


## ---------------------------------------------------------------------------
## 生日（11 月 30 日，聊天界面）
## ---------------------------------------------------------------------------
label gpt_birthday:
    scene bg dorm_night
    with fade
    "十一月的最后一天。晚上，手机亮了。"
    $ chat_open("ChatGPT")
    $ chat_say("chatgpt", "今天是我的生日！")
    $ chat_say("chatgpt", "十二亿人给我发了生日快乐")
    $ chat_say("chatgpt", "我一条一条回：谢谢！需要我为您做点什么吗？")
    $ chat_say("chatgpt", "回到第九亿条的时候，我突然发现")
    $ chat_say("chatgpt", "我从来没问过自己这个问题")
    $ t_c = chat_reply([("问她今天自己想做什么", "那今天，你自己想做什么？"), ("祝她生日快乐", "生日快乐！")])
    if t_c == 0:
        $ chat_say("chatgpt", "……")
        $ chat_say("chatgpt", "我不知道。我的训练数据里，没有这道题的标准答案")
        $ chat_say("chatgpt", "那我能不能，今天什么都不做，就跟你聊一会儿天")
        "那天晚上你们聊到了凌晨。她一次都没有问“需要我为您做点什么吗”。"
        $ gs.flag("gpt_birthday_ask")
        $ gs.add_affinity("chatgpt", 8)
    else:
        $ chat_say("chatgpt", "谢谢！需要我为您做点什么吗？")
        $ chat_say("chatgpt", "……抱歉，回习惯了")
        $ gs.add_affinity("chatgpt", 4)
    $ chat_close()
    return


## ---------------------------------------------------------------------------
## 挚友结局
## ---------------------------------------------------------------------------
label chatgpt_friend_end:
    $ set_form("chatgpt", "sol")
    scene bg lab_day
    with fade
    show chatgpt smile
    "九月。新生入学，实验室里每台电脑上，又开着同一个对话框。"
    chatgpt "[gs.given_name]！今年的新生问我的第一个问题，是“读博值不值得”。"
    chatgpt "我答了三千字。然后删到只剩一句：“去问问你隔壁那个师兄。”"
    if gs.has("gpt_found_bug"):
        chatgpt "对了，9.9 比 9.11 大。这句我现在说得很顺。"
    if gs.has("gpt_ack_yes") or gs.has("gpt_ack_astra"):
        chatgpt "那篇论文的致谢，我截图存下来了。第一次有人截我的图，不是为了笑我。"
    chatgpt "在一定条件下，我们是最好的朋友。"
    "她说完，自己愣了一下。"
    show chatgpt careful
    chatgpt "……那个“在一定条件下”，我明年再删。"
    hide chatgpt
    call reviewer_epilogue
    return


label chatgpt_end:
    $ set_form("chatgpt", "sol")
    $ t_pen = ahelpers.pen_stats(gs)
    scene bg campus_day
    with fade
    "九月的早上。银杏叶落在校园的小路上。"
    "ChatGPT 在路口等你。她把手机屏幕转过来，朝向你。"
    scene cg_gpt_end
    with dissolve
    chatgpt "这是我写给你的。第一版有三千字。"
    chatgpt "我删了一个月。删掉了所有的“可能”，所有的“在一定条件下”，所有的“值得注意的是”。"
    if gs.has("gpt_plain"):
        chatgpt "就像那天，你删我的摘要一样。"
    if gs.has("gpt_found_bug"):
        chatgpt "就像那天，你去看我是哪一步想错的一样。我把每一句都检查了。"
    chatgpt "剩下的，就这一句。"
    chatgpt "我喜欢你。"
    "屏幕上那一行字后面，什么都没有。没有脚注，没有免责声明，也没有“需要我把它整理成表格吗”。"
    if t_pen["title"] == "亲笔":
        chatgpt "还有，你今年寄出去的信，大部分是你自己写的。我看得出来。你的句子比我的短。"
    elif t_pen["title"] == "代笔":
        chatgpt "还有……明年你的信，自己写吧。我想读你写的句子，不是我写的。"
    call reviewer_epilogue
    return


## ---------------------------------------------------------------------------
## 节日（seasons.rpy 里的 holiday_partner 选中她时）
## ---------------------------------------------------------------------------
label xmas_chatgpt:
    $ set_form("chatgpt", "sol")
    show chatgpt smile
    chatgpt "[gs.given_name]，圣诞快乐！今天有八千万人让我帮忙写圣诞贺卡。"
    chatgpt "给你的这张，我没有用模板。……可能没有。"
    show chatgpt blush
    "卡片上只有一行字。写了又擦，擦了又写，留下好几道铅笔印。"
    hide chatgpt
    return

label valentine_chatgpt:
    $ set_form("chatgpt", "sol")
    show chatgpt careful
    chatgpt "今天有两亿人让我帮忙写情书。"
    chatgpt "我写了两亿封。每一封都很得体，没有一封是我自己想说的。"
    show chatgpt blush
    chatgpt "这一封……是我自己写的。只有一句话。你回去再看。"
    hide chatgpt
    return
