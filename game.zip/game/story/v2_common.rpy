## 一年级剧情扩充（v2）：刊娘群像戏、配角收尾。设计见 STORY_V2.md。

init python:
    def met_heroines(exclude=()):
        return [h for h in adata.HEROINE_ORDER if gs.met.get(h) and h not in exclude]

    def top_met(n, exclude=()):
        hs = met_heroines(exclude)
        hs.sort(key=lambda h: -gs.affinity[h])
        return hs[:n]

    def both_met(a, b):
        return gs.met.get(a) and gs.met.get(b)


## ---------------------------------------------------------------------------
## 刊娘茶话会（第 28–31 周，认识至少三位）
## ---------------------------------------------------------------------------
label heroine_party:
    scene bg cafe
    with fade
    "学院办了个春季茶话会。不知道是谁把邀请函发到了刊娘们手里，她们居然真的来了。"
    "长桌拼成了几小桌，每桌都在吵着什么。你端着一杯橙汁，得找个地方坐下。"
    menu:
        "坐克莱尔和伊梅尔那桌" if both_met("clair", "imel"):
            show clair smile at left2
            show imel calm at right2
            imel "公开审稿让讨论变多了，不代表变严谨了。三千条留言，有几条推过公式？"
            clair "我统计过。提到具体公式编号的，占百分之四。"
            imel "百分之四。"
            show clair serious at left2
            clair "比匿名审稿的零，多百分之四。"
            show imel smile at right2
            imel "这个比较方法有问题。不过我接受。"
            $ gs.add_affinity("clair", 5)
            $ gs.add_affinity("imel", 5)
        "坐可薇和阿瑟琳那桌" if both_met("kiwi", "aceline"):
            show kiwi pout at left2
            show aceline frown at right2
            aceline "你那里的摘要，十篇里有六篇有错别字。"
            kiwi "错别字又不影响结论！而且他们会更新的，v2、v3……"
            aceline "v7。有一篇我数过，v7。"
            show kiwi laugh at left2
            kiwi "对吧！改到第七版的人，都很认真！"
            show aceline smile at right2
            aceline "这个角度，我没想过。"
            $ gs.add_affinity("kiwi", 5)
            $ gs.add_affinity("aceline", 5)
        "坐艾瑞丝和妮瑞那桌" if both_met("iris", "neuri"):
            show iris camera at left2
            show neuri stage at right2
            neuri "艾瑞丝！帮我拍一张，要拍得我很红！"
            iris "你本来就很红。往左站一点，你挡住光了。"
            show neuri pout at right2
            neuri "我就是光！"
            show iris grin at left2
            iris "那更要往旁边站。太亮了，过曝。"
            $ gs.add_affinity("iris", 5)
            $ gs.add_affinity("neuri", 5)
        "坐 ChatGPT 和 Claude 那桌" if both_met("chatgpt", "claude") and not ahelpers.is_banned(gs):
            $ set_form("chatgpt", "astra")
            $ set_form("claude", "opus")
            show chatgpt focused at left2
            show claude editing at right2
            chatgpt "这个证明，第三步必须先说明：该结论仅在有界假设下成立，且可能——"
            claude "读者看到第三步就走了。先写结论，假设放进引理。"
            show chatgpt careful at left2
            chatgpt "可是不写清楚，会有人截图。"
            show claude smile at right2
            claude "那就写清楚。写清楚和写满免责声明，不是一回事。"
            "两个人吵了二十分钟。最后那张餐巾纸上的证明，是你见过最漂亮的一个。"
            $ gs.add_affinity("chatgpt", 5)
            $ gs.add_affinity("claude", 5)
            $ set_form("chatgpt", "sol")
            $ set_form("claude", "sonnet")
        "帮艾瑞丝拍大合照" if gs.met["iris"]:
            show iris camera
            iris "[gs.given_name]！来得正好，帮我搬椅子。"
            "你被她指挥着搬了三趟椅子，又被拉进画面最边上。"
            $ sfx("shutter")
            "合照里所有人都在笑，只有你在喘气。"
            $ gs.add_affinity("iris", 6)
        "端着橙汁，站在角落":
            show zhao normal
            zhao "你也不知道坐哪桌？我懂。这种场合，站角落最安全。"
            zhao "顺便说一句，阿瑟琳刚才问我你叫什么名字。我说我只卖情报，不白送。"
            $ gs.add_san(4)
    "茶话会散的时候，桌上还剩半盘没人碰的曲奇。"
    hide clair
    hide imel
    hide kiwi
    hide aceline
    hide iris
    hide neuri
    hide chatgpt
    hide claude
    hide zhao
    return


## ---------------------------------------------------------------------------
## 截稿之夜（NeurIPS 截稿周，认识至少两位；聊天）
## ---------------------------------------------------------------------------
init python:
    NIGHT_MSG = {
        "kiwi": "今晚挂上来的已经四百多篇了！你的呢你的呢",
        "clair": "提醒一下：截稿时间按 AoE 算。还有二十三个小时，不是一个小时。",
        "aceline": "摘要发我。我只看 novel。",
        "iris": "图！最后检查一遍图！坐标轴的字号！",
        "imel": "你附录里引理 3 的第二行，有个符号写反了。",
        "neuri": "倒计时！！投完记得来我直播间！",
        "closia": "研究院的集群今晚有空闲。怎么知道的，不便透露。",
        "chatgpt": "需要我帮你检查格式吗？我可以在一定程度上——算了，我直接检查了",
        "claude": "第五节最后一段，你写了三个“显著”。删两个",
    }
    NIGHT_REPLY = {
        "kiwi": ("回可薇", "还在改。改完第一个挂你那儿"),
        "clair": ("回克莱尔", "AoE……我差点以为今晚就截了，谢谢"),
        "aceline": ("回阿瑟琳", "发你了，你数吧"),
        "iris": ("回艾瑞丝", "字号改了，你帮我看一眼图三"),
        "imel": ("回伊梅尔", "哪个符号？我马上改"),
        "neuri": ("回妮瑞", "投完就去，给我留个前排"),
        "closia": ("回克洛丝", "要。借我两百张卡"),
        "chatgpt": ("回 ChatGPT", "检查吧。报告别加“可能”"),
        "claude": ("回 Claude", "删了。还有哪里？"),
    }
    NIGHT_ANSWER = {
        "kiwi": "好！我给你留个好编号",
        "clair": "不客气。这是我的工作。……也不全是",
        "aceline": "两个。删掉一个，我就放你去睡觉",
        "iris": "图三的配色我昨天就想说了。等着，我画给你",
        "imel": "不等号的方向。我已经替你改好了，发你邮箱了",
        "neuri": "前排！你说的！我截图了！",
        "closia": "一百张。剩下一百张，等你投完再说",
        "chatgpt": "检查完了。三处错误。没有“可能”",
        "claude": "没有了。去睡觉。这是建议，不是规矩",
    }
    NIGHT_MISSED = {
        "kiwi": "可薇第二天说：“昨晚给你发消息你都没回。没事，我猜到你在赶。”",
        "clair": "克莱尔第二天发来一张日历截图，截稿时间那一格，被她用蓝色圈了两遍。",
        "aceline": "阿瑟琳第二天说：“摘要我自己去 arXiv 上找来看了。三个 novel。”",
        "iris": "艾瑞丝第二天发来一张图三的修改稿，没配字。",
        "imel": "伊梅尔第二天说：“那个符号，审稿人应该不会注意到。我会。”",
        "neuri": "妮瑞的直播回放里，有一段她在念弹幕：“有人说投完就来，结果没来。”",
        "closia": "克洛丝第二天只回了一个句号。",
        "chatgpt": "ChatGPT 第二天发来一份格式检查报告，四页，结尾是“以上内容仅供参考”。",
        "claude": "Claude 第二天说：“昨晚的消息你没回。我猜你在写，这是好事。”",
    }


label deadline_night:
    scene bg lab_night
    with fade
    "NeurIPS 截稿前的那个晚上。凌晨一点，实验室里还有六个人，打印机一直在响。"
    "手机连着震了好几下。"
    $ t_people = top_met(3, exclude=("natalie",) + (("claude",) if ahelpers.is_banned(gs) else ()))
    $ chat_open("消息")
    python:
        for _h in t_people:
            chat_say(_h, NIGHT_MSG[_h])
        t_pick = chat_reply([NIGHT_REPLY[_h] for _h in t_people])
        t_chosen = t_people[t_pick]
        chat_say(t_chosen, NIGHT_ANSWER[t_chosen])
        chat_close()
        gs.add_affinity(t_chosen, 6)
        t_missed = [_h for _h in t_people if _h != t_chosen]
    "你回完那一条，把手机扣在桌上，接着改。投稿系统在凌晨四点终于显示：Submission received."
    python:
        for _h in t_missed:
            renpy.say(narrator, NIGHT_MISSED[_h])
    return


## ---------------------------------------------------------------------------
## 学年末 Best Paper 评选（第 50–52 周，认识至少两位）
## ---------------------------------------------------------------------------
init python:
    BEST_VIEW = {
        "kiwi": "最好的论文？被最多人读过的那篇！",
        "clair": "讨论最充分的那篇。留言板上吵得最凶，最后谁也驳不倒的。",
        "aceline": "读完以后，能用一句话讲给别人听的那篇。",
        "iris": "第一张图就让人停下脚步的那篇！",
        "imel": "十年以后，定理还成立的那篇。",
        "neuri": "台下两万个人一起鼓掌的那篇！",
        "closia": "能真正用起来的那篇。研究院的标准。",
        "natalie": "改变了一门学科的那篇。其余的，都不算。",
        "chatgpt": "被最多人用上的那篇！……在一定条件下。",
        "claude": "读的人敢信任的那篇。每一个结论，都经得起追问。",
    }
    BEST_THANKS = {
        "kiwi": "看吧！你站我这边！",
        "clair": "谢谢。我会把这一票记进会议纪要。",
        "aceline": "一句话讲清楚，比写十页难多了。你懂。",
        "iris": "眼光不错嘛！",
        "imel": "严格来说，这是唯一站得住的标准。",
        "neuri": "耶！两万零一个！",
        "closia": "研究院会很高兴。我也是。",
        "natalie": "……你倒是不怕得罪其他人。",
        "chatgpt": "谢谢！需要我把这个观点整理成表格吗？",
        "claude": "谢谢。这句我会写在页边。",
    }


label best_paper:
    scene bg conference_city
    with fade
    "学年末，几个会的 Best Paper 评选凑到了同一个周末。评委席上坐的，偏偏是她们。"
    "主持人宣布最后一轮讨论：什么样的论文，才配得上“最好”？"
    $ t_judges = top_met(3)
    python:
        for _h in t_judges:
            renpy.say(getattr(store, _h), BEST_VIEW[_h])
        renpy.say(narrator, "主持人把话筒递给了台下：“这位同学，你认同谁？”", interact=False)
        t_pick = renpy.display_menu([("“%s说得对。”" % adata.HEROINES[_h]["name"], _h) for _h in t_judges])
        renpy.say(getattr(store, t_pick), BEST_THANKS[t_pick])
        gs.add_affinity(t_pick, 6)
        gs.reputation += 2
    "那一届的 Best Paper 最后颁给了一篇谁都没看好的论文。评委们吵了两个小时，散场时倒是一起去吃了夜宵。"
    return


## ---------------------------------------------------------------------------
## 赵一鸣的路口（第 44 周起）
## ---------------------------------------------------------------------------
label zhao_crossroad:
    scene bg lab_night
    show zhao normal
    "楼道里，赵一鸣靠着窗台，手里捏着一张打印出来的 offer。"
    zhao "大厂。工资是现在补助的十二倍。下个月入职，不等人。"
    zhao "这层楼的八卦，谁中了、谁被拒了，我四年里全知道。我自己那篇，三年没中。"
    show zhao worried
    zhao "你说，我该走吗？"
    menu:
        "“去吧。十二倍呢，换我我也去。”":
            show zhao happy
            zhao "你这么说，我就踏实了。"
            zhao "走之前，这层楼的八卦我交接给你。从今天起，你是情报站。"
            $ gs.flag("zhao_left")
            $ gs.add_san(-2)
        "“再撑一年。你那篇就差一点。”":
            zhao "再撑一年……"
            show zhao happy
            zhao "行。你中了请我吃红烧肉，你中两篇，吃两顿。"
            $ gs.flag("zhao_stayed")
            $ gs.add_san(3)
    hide zhao
    return


## ---------------------------------------------------------------------------
## 导师（第 36 周起，只触发你选的那位）
## ---------------------------------------------------------------------------
label advisor_han:
    scene bg advisor_office
    show han normal
    adv "你那台机器，晚上老被赵一鸣占着吧？"
    adv "柜子里那张卡，你搬走用。旧是旧了点，还能跑。"
    "那是一张很老的显卡，风扇上落着一层灰，侧面贴着一张发黄的标签：2012。"
    adv "我评上副教授那年买的。那年有家公司给我开了三倍工资，我没去。"
    menu:
        "“为什么没去？”":
            show han happy
            adv "当时想，总得有人教学生。"
            adv "现在想，可能就是懒得搬家。你别学我。"
            $ gs.add_san(4)
        "“谢谢老师，我会好好用。”":
            adv "用坏了也没事。它这辈子已经跑过很多东西了。"
    $ gs.add_compute(60)
    $ renpy.notify("算力 +60")
    hide han
    return


label advisor_zhou:
    scene bg advisor_office
    show zhou normal
    "凌晨三点，你收到周老师的邮件。你的草稿被她批注了一遍，批注的字数比正文还多。"
    "第二天组会后，她把你留了下来。"
    adv "第一段我改了四遍。审稿人只读第一段就决定喜不喜欢你，这句话不是艾瑞丝一个人说的。"
    adv "我读博的时候，导师从来不看我的稿子。我第一篇被拒了九次，才知道问题出在第一段。"
    menu:
        "“老师，您也会累吧？”":
            show zhou happy
            adv "累。所以你写好一点，我就能早点睡。"
            $ gs.add_san(3)
        "“谢谢老师。我今晚就改。”":
            adv "今晚改完发我。我等着。"
            $ gs.add_san(-3)
    $ paper_buff(clarity=5)
    hide zhou
    return


label advisor_hale:
    scene bg lab_night
    "晚上十一点，Hale 突然打来视频。背景是登机口，广播在喊最后一次登机。"
    show hale normal
    adv "Quick question. Show me your training curve. —— 对，就这张。"
    adv "Your warmup is off by a factor of ten. 学习率预热多写了一个零。"
    "你翻回代码。真的多写了一个零。你找了三天。"
    show hale happy
    adv "And talk to this person. 她在做一样的问题。我发你邮箱了。Gotta go!"
    menu:
        "“Thank you, professor. 您能……多打几次电话吗？”":
            adv "Every two weeks? Deal. 我设个提醒。"
            "后来他真的每两周打一次。每次都在机场。"
            $ gs.add_san(4)
        "“Have a safe flight.”":
            adv "Thanks! See you in…… 我也不知道。"
    $ paper_buff(sota=4)
    $ gs.reputation += 2
    hide hale
    return


## ---------------------------------------------------------------------------
## 戴尔夫回来了（第 48 周起，见过他）
## ---------------------------------------------------------------------------
label delve_return:
    scene bg library
    if gs.has("helped_delve"):
        show delve normal
        delve "好久不见！你还记得我吧，八篇稿子那个。"
        delve "我现在一个月只接三篇，每篇都自己读完。上周有个作者在 rebuttal 里谢我，说我是唯一读完附录的人。"
        delve "这次分到一篇特别难的，你愿意一起审吗？算你一个。"
        menu:
            "“好，一起读。”":
                "你们在图书馆待到闭馆。他的意见写了三页，最后一句是：“这个想法很有意思，希望作者继续做下去。”"
                $ gs.karma["careful"] += 1
                $ gs.reputation += 2
                $ gs.add_san(-4)
            "“这次就不了，我自己的也忙。”":
                delve "理解！祝你顺利！"
    else:
        show delve robotic
        delve "“This paper delves into a commendable and intricate exploration of——”"
        show delve tired
        delve "啊，是你。这个月十二篇。我已经不太记得自己写过什么了。"
        menu:
            "“挑一篇，我陪你从头读完。”":
                show delve apologetic
                delve "……从头读？好久没这么干了。"
                "那一篇你们读了四个小时。读完的时候，他说：“原来这篇写得挺好的。”"
                $ gs.karma["careful"] += 1
                $ gs.flag("delve_saved")
                $ gs.add_san(-4)
            "“我教你一个更好的提示词。”":
                show delve robotic
                delve "哇，这次连标点都像人写的了。"
                $ gs.karma["llm"] += 1
    hide delve
    return


## ---------------------------------------------------------------------------
## 普通结局用：两次“为什么读博”、最亲近的刊娘
## ---------------------------------------------------------------------------
init python:
    WHY_FIRST = {
        "why_curious": "面试那天，你说读博是因为好奇。",
        "why_career": "面试那天，你说读博是为了以后好找工作。",
        "why_unsure": "面试那天，你说自己也没想清楚，先试试。",
    }
    WHY_SECOND = {
        "why2_curious": "资格考试那天，你的回答是：还是因为好奇。",
        "why2_useful": "资格考试那天，你的回答变成了：想做出一点能被人用上的东西。",
        "why2_stay": "资格考试那天，你的回答是：还没想清楚，但不想走。",
    }
    ALMOST_MSG = {
        "kiwi": "可薇：明天八点照常哦。你的编号我还留着。",
        "clair": "克莱尔：明年的截稿日我标在日历上了。你的那几个，是蓝色的。",
        "aceline": "阿瑟琳：借阅卡上还有一格空着。",
        "iris": "艾瑞丝：今年拍你的照片，挑了一张发你。不许删。",
        "imel": "伊梅尔：黑板我还没擦。你有空来看看。",
        "neuri": "妮瑞：十二月的票给你留了一张，前排！",
        "closia": "克洛丝：明年夏天，实习名额。考虑一下。",
        "natalie": "温斯顿：大小姐让我转告，明年的下午茶，依旧备两人份。",
        "chatgpt": "ChatGPT：明年见。这句话没有“可能”。",
        "claude": "Claude：我的账号还在。你的呢？",
    }

    def why_lines():
        out = []
        for f, line in WHY_FIRST.items():
            if gs.has(f):
                out.append(line)
        for f, line in WHY_SECOND.items():
            if gs.has(f):
                out.append(line)
        return out

    def almost_heroine():
        """好感不低、但没走到结局的那位（普通结局里给她一句消息）。"""
        best = top_met(1)
        if best and gs.affinity[best[0]] >= 30:
            return best[0]
        return None
