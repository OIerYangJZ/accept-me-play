## 克莱尔（ICLR）—— 透明系少女

label clair_intro:
    scene bg openreview_hall
    with fade
    "公开评审大厅。玻璃墙，玻璃地板，抬头连天花板都是透明的。"
    show clair smile
    clair "你好，欢迎。我是克莱尔，这里的负责人。"
    clair "先说明一下规则：在我这里，投稿、审稿意见、作者回复，全部公开。"
    clair "任何人都能看，任何人都能留言。注册账号就行，不需要邀请码。"
    p "被拒的也公开？"
    show clair serious
    clair "被拒的也公开。"
    clair "我知道有人觉得这样太狠了。不过我的看法是，讨论摆在明处，大家吵完都能学到点东西。"
    menu:
        "“公开挺好。被骂也能被看见。”":
            show clair happy
            clair "新人里这么说的不多。我记一下。"
            $ gs.add_affinity("clair", 4)
        "“那我得先把稿子打磨好再来。”":
            clair "很合理。打磨过的稿子，在我这里会被更多人认真读。"
            $ paper_buff(clarity=3)
    show clair smile
    clair "你的第一篇稿子，考虑投给我吗？截稿日还有几周，时间够的。"
    $ gs.add_affinity("clair", 6)
    hide clair
    "【克莱尔】ICLR 的化身。审稿全程公开，rebuttal 有两轮。"
    return

label visit_clair:
    scene bg openreview_hall
    $ t_v = renpy.random.randint(1, 3)
    if t_v == 1:
        show clair smile
        $ t_cat = renpy.random.choice(["support", "neutral", "meme"])
        $ t_line = pick_line("openreview_crowd", t_cat)
        clair "今天留言板上有一条：「[t_line]」"
        clair "我每天都会读一遍新留言。难听的也读，我把它们归在另一个文件夹里。"
    elif t_v == 2:
        show clair puzzled
        clair "[gs.surname]同学，有个现象我想请教你。今天有位作者的回复写了三千字。"
        clair "审稿人只回了一句：“谢谢，维持原分。”"
        show clair nervous
        clair "我在考虑要不要在作者须知里加一条字数建议。你觉得写多少合适？八百词？"
    else:
        show clair happy
        clair "今天光线很好。大厅里的玻璃都在反光，留言板的字也比平时清楚。"
        clair "我喜欢清楚的东西。你上次那张图的坐标轴标注就很清楚。"
    hide clair
    return

label submitted_iclr:
    show clair smile
    clair "收到。从这一秒开始，它就是公开的了。"
    clair "我会按顺序认真读，你那篇排在第三千零几号。别着急。"
    hide clair
    return

label reviews_iclr:
    show clair nervous
    clair "审稿意见已经放出来了。现在在线人数有点多。"
    if gs.low_san:
        "侧边栏的评论一条一条往上滚。你只看得见难听的那几条。"
    hide clair
    return

label clair_midnight:
    scene bg openreview_hall
    "深夜的公开评审大厅里一个人也没有，只剩屏幕的光。"
    show clair lonely
    "克莱尔一个人坐在留言板前，手指一下一下地往下划。"
    "「这种论文也能投？」「审稿人是来搞笑的吧」「建议 ICLR 改名叫抽奖大会」"
    p "克莱尔？"
    show clair nervous
    clair "啊，[gs.surname]同学。你都看到了？"
    clair "拒绝是公开的，所以大家的火气也都发在这里。删不掉的，规则上我不能删。"
    clair "我一直觉得公开就是公平。可是被拒的人的名字，会一直挂在这一页上。"
    clair "我是不是做错了？"
    menu:
        "“我见过一篇被拒的论文，下面有人留言说，它启发了他。”":
            show clair puzzled
            clair "哪一篇？你还记得编号吗？"
            show clair smile
            clair "我明天去找。要是真的有，那至少有一个人，是因为公开才被看见的。"
            $ gs.add_affinity("clair", 9)
        "“那就别看了。我陪你关掉它。”":
            show clair puzzled
            clair "关掉？这个页面从上线到现在，我没关过。"
            show clair blush
            clair "那就关五分钟。我计时。"
            $ gs.add_affinity("clair", 7)
    hide clair
    return

label clair_rain:
    scene bg rainy_street
    with dissolve
    "晚上下起了大雨。公开评审大厅门口，克莱尔站在屋檐下，手里拿着一把收起来的伞。"
    show clair nervous
    clair "[gs.surname]同学。我在等雨停。"
    clair "伞我带了，是透明的。撑着它走在路上，所有人都看得见我。平时没关系，今天不太想。"
    "你把自己的伞递过去。她看了一会儿，摇摇头，把那把透明伞撑开了。"
    scene cg_rain_umbrella
    with dissolve
    clair "那就一起被看见好了。"
    "雨点打在透明的伞面上，一道一道往下流。她走路很慢，伞一直往你这边偏。"
    clair "[gs.surname]同学，我想拜托你一件事。"
    clair "今晚的事，不要写进任何地方。不发到网上，不写日记，也别告诉夏可薇。"
    menu:
        "“好。这是我们两个人的。”":
            clair "嗯。谢谢。"
            $ gs.add_affinity("clair", 10)
            $ gs.flag("clair_promise")
        "“可是我很想告诉别人，今晚很开心。”":
            clair "那就只告诉我一个人。"
            clair "你说给我听，就不算公开。这个解释，在我的规则里是成立的。"
            $ gs.add_affinity("clair", 8)
    scene bg rainy_street
    with dissolve
    return

label clair_secret:
    scene cg_clair_secret
    with dissolve
    clair "[gs.surname]同学，我想问你一件事。"
    clair "我这里什么都是公开的。规则、评分标准，连我的心情，大家都能从留言板上猜出来。"
    clair "所以我没有秘密。一条都没有。"
    clair "能不能有一件事，只有你知道？"
    menu:
        "把一张只写给她的纸条递过去":
            "她把纸条打开，看了很久，又照着原来的折痕折好，放进了外套里面的口袋。"
            clair "这个不归档。"
            clair "谢谢你，[gs.given_name]。"
            $ gs.add_affinity("clair", 12)
        "“那我们约好，下次截稿前，一起去看海。”":
            clair "看海？这个需要写进日程表吗？"
            clair "不写了。好，这是我们的秘密。"
            $ gs.add_affinity("clair", 10)
    scene bg openreview_hall
    with dissolve
    return

label react_iclr_accept:
    show clair happy
    clair "恭喜。这次的结果，大家都看到了。"
    clair "留言板上有人说：“这篇 rebuttal 写得真好。”我点了赞。用的是管理员账号，可能不太合规。"
    hide clair
    return

label react_iclr_reject:
    show clair lonely
    clair "对不起。这次的结果也是公开的。"
    clair "不过你回复审稿人的每个字都还在这一页上。以后会有人翻到的。"
    hide clair
    $ gs.add_affinity("clair", 3)
    return

## ---------------------------------------------------------------------------
## 冲突：被截图挂到网上（深夜留言板之后）
## ---------------------------------------------------------------------------
label clair_screenshot:
    scene bg lab_day
    show zhao surprised
    zhao "你火了。"
    "他把手机怼到你面前。上周你在留言板上替一篇被骂惨的论文说了句话：“这篇的消融其实做得很仔细。”"
    "有人把这句截了图，配文：“作者小号，实锤。”转发两千三。"
    hide zhao
    scene bg openreview_hall
    with dissolve
    show clair nervous
    clair "[gs.surname]同学，你看到了。"
    clair "按规则，留言板上的内容我不能删。截图在别的网站，我也管不到。"
    clair "我能做的，是在原帖下面加一条管理员说明，写清楚你和作者没有关系。"
    menu:
        "“能不能把我那条留言删了？就这一次。”":
            show clair serious
            clair "不能。"
            clair "发出去的留言不能删，作者本人也不行。为你破一次，下个月就会有人来求第二次。"
            show clair lonely
            clair "对不起。说明我今晚加上。"
            $ gs.add_affinity("clair", -1)
        "“不用你出面。我自己回一条。”":
            "你在原帖下面写：我不认识作者。消融做得仔细，就是做得仔细，不信可以去看附录 C。"
            "第二天，你那条下面多了一句：“去看了，确实。”"
            show clair happy
            clair "我看到了。管理员账号不能点赞。"
            clair "不过那一页我刷新了很多遍。"
            $ gs.flag("clair_faced")
            $ gs.add_affinity("clair", 8)
            $ gs.reputation += 2
        "“算了，过两天就没人记得了。”":
            "三天后，截图确实沉下去了。那之后，你在留言板上再也没替谁说过话。"
            show clair lonely
            "克莱尔什么也没说。那条帖子下面多了一条管理员说明，措辞非常克制。"
            $ gs.add_affinity("clair", 3)
            $ gs.add_san(-4)
    hide clair
    return


## ---------------------------------------------------------------------------
## 约定：年度透明度报告（雨夜之后）
## ---------------------------------------------------------------------------
label clair_report:
    scene bg openreview_hall
    show clair smile
    clair "年度透明度报告的初稿出来了。"
    clair "每位作者的投稿数、被拒数、rebuttal 写了多少字，都在里面。默认匿名，也有几位作者主动要求署名。"
    $ t_subs = sum(1 for x in gs.submissions if x.venue == "iclr")
    $ t_rej = sum(1 for x in gs.submissions if x.venue == "iclr" and x.outcome == "reject")
    if t_subs == 0:
        clair "你今年没投给我，投稿那一栏是零。不过留言板发言那一栏，你排第三。"
    show clair puzzled
    clair "[gs.surname]同学，你那一行要写名字吗？"
    menu:
        "“写吧。没什么好藏的。”":
            show clair happy
            if t_subs:
                clair "好。第三十七行：[gs.player_name]，投稿 [t_subs]，被拒 [t_rej]。"
            else:
                clair "好。第三十七行：[gs.player_name]，投稿 0，留言板发言第三。"
            show clair blush
            clair "我把这一行的字号调大了一点。规则里没写不可以。"
            $ gs.flag("clair_report_yes")
            $ gs.add_affinity("clair", 8)
        "“匿名吧。”":
            clair "好。匿名也是你的权利。"
            "报告发出去那天，她在说明里加了一条：匿名作者的被拒次数同样计入总数。"
            $ gs.add_affinity("clair", 4)
    hide clair
    return


## ---------------------------------------------------------------------------
## 挚友结局
## ---------------------------------------------------------------------------
label clair_friend_end:
    scene bg openreview_hall
    with fade
    show clair smile
    "一年级的最后一天。公开评审大厅的灯开得很亮。"
    clair "[gs.surname]同学，今年的讨论我都存档了。"
    clair "按回复数排，你是我在留言板上回得最多的人。九十一条。"
    show clair blush
    clair "这个数字，不在公开档案里。"
    show clair smile
    clair "明年的截稿日，我已经在日历上标好了。你会投的那几个，用的是蓝色。"
    clair "到时候按规则，我会公平地读。不会因为是你，就多看一眼。"
    show clair blush
    clair "……大概不会。"
    hide clair
    call reviewer_epilogue
    return


label clair_end:
    scene bg openreview_hall
    with fade
    show clair smile
    "一年级的最后一天。公开评审大厅的灯开得很亮。"
    clair "[gs.given_name]，今年的所有讨论我都存档了。你的、别人的，好的、坏的。"
    if gs.has("accepted_iclr"):
        clair "你那篇被接收的论文下面，一共四十二条路人评论。我全部读过，有三条在问代码。"
    elif any(s.venue == "iclr" and s.outcome == "reject" for s in gs.submissions):
        clair "你被我拒掉的那篇，上个月下面多了一条留言。有人说，它给了他一个新思路。"
        clair "我截图了。本来想第二天就发给你，拖到了现在。"
    else:
        clair "你今年没投给我。不过你常来大厅看留言板，我都看见了。"
        clair "你在一篇别人的论文下面站了四十分钟。我计时了。"
    if gs.has("clair_faced"):
        clair "截图那次，你自己去回了那条帖子。现在那条回复下面有一百多个“+1”。管理员账号没点，我用小号点了。"
    if gs.has("clair_report_yes"):
        clair "透明度报告第三十七行，是我今年打开次数最多的一行。"
    show clair blush
    clair "只有一样东西，我没放进公开档案。"
    if gs.has("clair_promise"):
        clair "那天晚上下雨。你答应过的，对吧？"
    clair "那个归你，也归我。"
    scene cg_clair_end
    with dissolve
    "她把发带上透明的那一段解下来，系在你手腕上，打了个很规整的结。"
    clair "这一段不公开。"
    hide clair
    call reviewer_epilogue
    return
