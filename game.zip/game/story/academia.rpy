## 共通线（二）：学术圈。Reviewer #2 的身世、戴尔夫、AC 艾茜、陆深的求职、去开会。

## ---------------------------------------------------------------------------
## Reviewer #2 的影子（第一次被他审过之后）
## ---------------------------------------------------------------------------
label rev2_shadow:
    $ t_rev2_title = rev2_paper_title()
    scene bg library
    with dissolve
    "晚上十点，图书馆五楼。最里面那排过刊架子旁边，站着一个穿黑色长大衣的人。"
    show rev2 normal
    "他戴着一张只露出嘴的白色面具，手里一支红笔，正在一本发黄的会议论文集上写批注。写得很密。"
    p "不好意思……这排书现在能借吗？"
    rev2 "能。不过你应该先把相关工作补全。"
    rev2 "《[t_rev2_title]》，第二节，漏了三篇。我在审稿意见里写过了。"
    p "你是——"
    show rev2 smirk
    rev2 "审过的稿子，我每一篇都记得。作者们倒是很快就忘了我，只记得我难伺候。"
    menu:
        "“那三篇，我回去就补。”":
            show rev2 normal
            rev2 "……很好。下次落到我手里，我会看你补了没有。"
            $ gs.flag("rev2_respect")
        "“你的意见太刻薄了。”":
            show rev2 smirk
            rev2 "刻薄？你还没见过我刻薄的样子。"
            $ gs.flag("rev2_grudge")
    hide rev2
    "你低头看了一眼书架编号，再抬头，人已经不见了。"
    "那本论文集还摊在桌上。被红笔圈住的是一篇十几年前的论文，作者那一栏被涂黑了。"
    $ gs.flag("rev2_mystery")
    return

init python:
    def rev2_paper_title():
        for s in reversed(gs.submissions):
            if any(r.persona == "rev2" for r in s.reviews):
                return gs.paper(s.paper_id).title
        return gs.papers[0].title if gs.papers else "你的论文"


## ---------------------------------------------------------------------------
## 戴尔夫：被八篇稿子压垮的审稿人
## ---------------------------------------------------------------------------
label delve_meet:
    scene bg library
    with dissolve
    "图书馆三楼的角落，有个人对着笔记本电脑小声念英文。"
    show delve robotic
    delve "“This paper delves into a commendable and intricate exploration of——”"
    delve "不行，delve 这周已经用了五次了。换一个。“This paper presents a comprehensive——”"
    p "你在写审稿意见？"
    show delve tired
    delve "啊。被抓到了。我叫戴尔夫，二年级。这个月系统给我分了八篇。"
    delve "我自己的论文还差一节实验，导师每天发消息问“进度”，房东每天发消息问“房租”，八篇稿子后天截止。"
    show delve apologetic
    delve "所以我让大模型帮我起了个草稿。就起个草稿。"
    if gs.has("met_delve"):
        p "（这开头……我好像收到过一份一模一样的。）"
    menu:
        "“分我四篇，我们一人一半，今晚读完。”":
            show delve normal
            delve "啊？你自己不忙吗？"
            "你们在图书馆待到闭馆，又搬到二十四小时自习室。八篇读完的时候，天快亮了。"
            "戴尔夫的最后一份意见写了两页半，比前七份加起来都长。其中有一句是：“第三个实验设计得很巧，建议作者多讲讲。”"
            show delve apologetic
            delve "我好久没把一篇别人的论文从头读到尾了。挺……挺好看的其实。"
            $ gs.karma["careful"] += 1
            $ gs.flag("helped_delve")
            $ gs.add_san(-5)
        "“你这个提示词不行，我教你一个。”":
            show delve robotic
            delve "哇。写出来的东西像真人写的一样，连语气都有点刻薄。"
            "他高高兴兴地合上电脑走了。你坐在原地，想起自己收到过的那份“commendable”。"
            $ gs.karma["llm"] += 1
        "“理解。辛苦了。”":
            show delve tired
            delve "嗯。你也是。祝你别被分到八篇。"
    hide delve
    return


## ---------------------------------------------------------------------------
## AC 艾茜：rebuttal 到底写给谁看
## ---------------------------------------------------------------------------
label aisy_ac:
    scene bg conference_city
    with dissolve
    "学院办了个“rebuttal 写作”工作坊。海报上写着主讲人做过九次 AC，台下坐满了被拒过的人。"
    show aisy normal
    aisy "我叫艾茜。今年我负责的领域收到六百一十四篇稿子，我手下有两百多个审稿人。"
    aisy "先说结论：rebuttal 不是写给审稿人看的，是写给 AC 看的。也就是我。"
    "台下有人倒吸了一口凉气，有人开始疯狂记笔记。"
    show aisy stern
    aisy "大部分审稿人看完 rebuttal 不会改分。他们很忙，也要面子。"
    aisy "但最后拍板的是我。所以别跟审稿人吵架，吵赢了也没用。"
    aisy "第一段就告诉我：哪几个问题你补实验解决了，哪几个是误读，哪几个你承认是局限。三句话，别绕。"
    show aisy smile
    aisy "还有，把“we thank the reviewer for the insightful comment”删了。我一天要读三百遍这句话。"
    menu:
        "举手问：“碰到 Reviewer #2 怎么办？”":
            show aisy surprised
            aisy "你也听说他了？"
            show aisy normal
            aisy "他让你引的那几篇，去看一眼。有时候他是对的，只是嘴太臭。"
            aisy "这话别说出去是我讲的。"
            $ gs.flag("aisy_rev2_hint")
        "把她说的每句话都记下来":
            "你记了满满两页，最后一行是：“删掉 insightful。”"
    $ gs.flag("ac_tip")
    "（从此以后，你写的每份 rebuttal，AC 都会读得更顺一点。）"
    hide aisy
    return


## ---------------------------------------------------------------------------
## 陆深的求职
## ---------------------------------------------------------------------------
label lu_job_market:
    scene bg lab_night
    with dissolve
    show lu normal
    "陆深今天穿了一身西装。袖子长了一截，领带是借赵一鸣的。他刚面试回来。"
    if gs.has("lu_hope"):
        show lu happy
        lu "拿到了。一所不大的学校，一个不大的位置，一间朝北的办公室。"
        lu "最后一轮有个老师问我，读了六年为什么还不走。"
        lu "我把凌晨三点跑出结果、在楼道里走三圈的事讲了。说完我自己都觉得好土。"
        lu "他们说就要这样的。谢了，[gs.given_name]。那天你要是不问，我不会记得这件事这么清楚。"
        $ gs.add_san(10)
    else:
        show lu worried
        lu "没过。第十一所了。"
        lu "我在想要不要去大厂。卡多，钱多，不用写基金申请书。"
        menu:
            "“再投一家吧。最后一家。”":
                show lu normal
                lu "你这语气，跟我妈一模一样。"
                lu "行，最后一家。没过的话，你得请我吃饭。"
                $ gs.flag("lu_hope")
            "“去大厂挺好的，真的。”":
                lu "嗯，挺好的。"
                "他把领带解下来叠好，放回赵一鸣的桌上。叠了两遍才叠整齐。"
    hide lu
    return


## ---------------------------------------------------------------------------
## Reviewer #2 的过去
## ---------------------------------------------------------------------------
label rev2_cafe:
    scene bg cafe
    with dissolve
    "学校门口的咖啡厅，靠窗那桌。戴面具的人面前摊着一份泛黄的打印稿，页边全是红笔。"
    show rev2 normal
    rev2 "又是你。"
    p "这份稿子是你的？"
    rev2 "我的第一篇论文。投了十二次。"
    rev2 "第十二次的审稿意见就一句：“作者显然不了解这个领域。”我把这句话贴在桌子上，贴了三年。"
    show rev2 angry
    rev2 "后来我了解了。比谁都了解。我开始审别人的稿子，一个字都不放过。"
    rev2 "我跟自己说，这叫守标准。"
    show rev2 normal
    rev2 "上个月我翻自己以前写的审稿意见，在一封拒信里看到了那句话。“作者显然不了解这个领域。”"
    rev2 "是我写的。"
    menu:
        "“你让我引的那几篇，我都看了。第二篇确实该引。”":
            show rev2 unmasked
            "他看了你很久，然后把面具摘了下来。面具下面是一张很普通的中年人的脸，眼睛下面两团青黑。"
            rev2 "第二篇是我学生写的。他后来转行了，没人引过。"
            rev2 "谢谢。下次你的稿子落到我手里，我会读得仔细一点。"
            $ gs.flag("rev2_unmasked")
        "“那你为什么还要这样对别人？”":
            show rev2 smirk
            rev2 "因为没人教过我别的写法。"
            rev2 "等你开始审稿就知道了，凌晨一点，第六篇，你也会想写这句话。"
    hide rev2
    return


## ---------------------------------------------------------------------------
## 去开会：ICLR（论文被 ICLR 录用时）
## ---------------------------------------------------------------------------
label iclr_conference:
    scene bg airport
    with fade
    "春末。这辈子第一次，为了一篇论文坐飞机。"
    show zhao happy
    zhao "会议 T 恤帮我多拿两件，L 码！贴纸也要！还有那种印着 logo 的袜子，要是有的话！"
    zhao "……算了，你先玩开心。T 恤也要。"
    hide zhao
    scene bg openreview_hall
    with dissolve
    "会场有好几个足球场那么大。海报一排排地立着，一直排到走廊尽头的咖啡机。"
    "你的海报在第 417 号，靠近厕所。来的人不多，但有个人站了二十分钟，问了你七个问题。"
    menu:
        "一个一个认真答完":
            "第七个问题你没答上来。你把它记进了手机备忘录。"
            $ gs.reputation += 3
            $ gs.ideas += 1
        "答到第三个，借口去拿咖啡":
            "你在咖啡机前，撞见了正在到处找你的克莱尔。"
            $ gs.add_affinity("clair", 3)
    show clair happy
    $ t_call = clair_call()
    clair "[t_call]！我找了三个展区。"
    clair "在我这里，你的论文一直是留言板上的一页。今天它是一张会被人站着看二十分钟的海报。"
    show clair blush
    clair "旁边还站着它的作者，表情很紧张。我拍下来了，不公开。"
    $ gs.add_affinity("clair", 8)
    $ gs.reputation += 5
    if gs.met["neuri"]:
        show clair smile at left2
        show neuri wink at right2
        neuri "哟，[gs.given_name]君！跑来别人家的会场踩点？"
        neuri "十二月记得来我的！我的会场是这里的三倍大，咖啡是这里的五倍难喝！"
        hide neuri
    hide clair
    "晚上，你一个人在陌生城市的街上走了很久，路过三家便利店，买了一瓶看不懂名字的饮料。"
    return


## ---------------------------------------------------------------------------
## 去开会：CVPR（论文被 CVPR 录用时）
## ---------------------------------------------------------------------------
label cvpr_conference:
    scene bg poster_hall
    with fade
    "夏天，CVPR。海报区人多到要侧着身子走，有人举着手机直接对着你的海报拍照就走了。"
    show iris jump
    iris "[gs.given_name]！这边！我帮你抢到了一个靠窗的位置，下午三点阳光正好打在第一张图上！"
    iris "相信我，路过的人看三秒就会停下来。不停下来我请你喝一周咖啡。"
    "那个下午你讲了四十多遍。讲到后来嗓子哑了，海报边上贴满了别人留的便利贴，有一张写着“代码开源吗”。"
    menu:
        "在下面写：“下周开源”":
            "第二天，那张便利贴下面多了一排“+1”。"
            $ gs.flag("code_open")
            $ gs.reputation += 2
        "在下面写：“整理好了就放”":
            "你知道“整理好了”通常是什么意思。写下去的时候，笔顿了一下。"
    show iris camera
    iris "最后一张，你跟海报合影。笑一下，嗓子哑了脸又没哑。"
    $ sfx("shutter")
    "咔嚓。"
    show iris blush
    iris "这张不修了。修了反而不像你。"
    $ gs.add_affinity("iris", 8)
    $ gs.reputation += 5
    hide iris
    return
