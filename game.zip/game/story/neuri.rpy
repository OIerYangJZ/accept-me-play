## 妮瑞（NeurIPS）—— 顶流偶像

label neuri_intro:
    scene bg concert_stage
    with fade
    "三月。全城的大屏幕都在放同一段预告片。"
    show neuri stage
    neuri "Hello everyone～！今年也是两万人的大场子哦！"
    neuri "五月截稿！十二月开唱！每年换一座城市！"
    "台下的应援牌一片一片亮起来。每块牌子上写的都是一篇论文的标题。"
    show neuri wink
    neuri "那边那个一年级的！对，就是你，别往后看！"
    menu:
        "（朝台上挥手）":
            neuri "叫什么名字？[gs.given_name]？OK，记住啦！今天第一个挥手的一年级！"
            $ gs.add_affinity("neuri", 4)
        "（假装没听见，低头看手机）":
            show neuri pout
            neuri "诶——居然无视我！"
            show neuri wink
            neuri "那更要记住你了。你叫什么？[gs.given_name]？好，跑不掉了！"
            $ gs.add_affinity("neuri", 2)
            $ gs.add_san(2)
    neuri "[gs.given_name]君，五月要来我的舞台哦～"
    p "（两万个人。她真记得住吗？）"
    $ gs.add_affinity("neuri", 6)
    hide neuri
    "【妮瑞】NeurIPS 的化身。投稿量全游戏最大，审稿结果的随机性也最大。"
    return

label visit_neuri:
    scene bg concert_stage
    $ t_v = renpy.random.randint(1, 3)
    if gs.low_san:
        show neuri serious
        neuri "诶，你状态不对啊。来，冰美式，我的，喝一口。"
        neuri "我彩排前都喝这个。不好喝，但是能撑住。"
        $ gs.add_san(4)
    elif t_v == 1:
        show neuri stage
        neuri "[gs.given_name]君！今天彩排超顺！你那篇 work 呢？够 solid 吗？有没有 ablation？"
    elif t_v == 2:
        show neuri wink
        neuri "偷偷告诉你，今年投稿编号快排到两万了。我给每篇都起了外号。"
        if any(s.venue == "neurips" for s in gs.submissions):
            neuri "你那篇叫“凌晨三点那个”。提交时间是 2:58，我看见了。"
        else:
            neuri "等你投过来，我也给它起一个。先预定一个：“让我等了好久那个”。"
    else:
        show neuri pout
        neuri "弹幕今天又在刷“NeurIPS 就是抽签”。"
        neuri "才不是抽签！我是……我是真的看不过来嘛。"
    hide neuri
    return

label submitted_neurips:
    scene bg lab_night
    show zhao worried
    zhao "截稿前最后一小时，全楼的卡全满了。"
    zhao "有人在走廊里跑，有人在楼梯间打电话哭，投稿系统崩了以后还有人开始在群里写诗。"
    hide zhao
    show neuri wink
    neuri "Received～！[gs.given_name]君的论文，编号一万九千八百多！"
    neuri "放心，我会一篇一篇看的！应该吧！"
    hide neuri
    return

label neuri_concert:
    scene bg concert_stage
    show neuri stage
    "彩排结束了。舞台上的灯还没关，台上只剩妮瑞一个人，在拿脚尖数地板上的走位标记。"
    neuri "[gs.given_name]君！你来啦！"
    show neuri pout
    neuri "跟你说，今年又破纪录了。投稿比去年多了四千篇。"
    neuri "然后大家就说我是抽签，说结果全看运气。"
    show neuri serious
    neuri "可是我每篇都有在看的。每篇都在看。"
    menu:
        "“我知道。你记住了我的名字。”":
            show neuri surprised
            neuri "你还记得那天啊？"
            show neuri wink
            neuri "嘿嘿，那当然，idol 的基本功！"
            $ gs.add_affinity("neuri", 9)
        "“两万篇，谁都看不完的。”":
            show neuri pout
            neuri "我知道。被你这么直接说出来，还是有点扎心。"
            $ gs.add_affinity("neuri", 4)
    hide neuri
    return

label neuri_city:
    scene bg conference_city
    with fade
    $ sfx("phone")
    "零点过五分，手机响了。妮瑞打来的视频。"
    show neuri stage
    neuri "[gs.given_name]君！看！下一届的会场城市！"
    "镜头晃得厉害：港口、霓虹灯、凌晨还亮着灯的面馆、明年会场的大门。"
    neuri "我每年都提前来踩点。哪里吃饭，哪里开 party，哪里可以躲起来哭——"
    show neuri surprised
    neuri "啊，最后那个当我没说。"
    show neuri tired
    neuri "每到一个新城市，第一天晚上我都睡不着。"
    neuri "这里现在没人认识我。等十二月一到，所有人都会挤过来喊我的名字。"
    neuri "有时候我搞不清楚，他们喜欢的是我，还是我手里那张录用通知。"
    menu:
        "“我喜欢的是会在凌晨给我打视频的你。”":
            show neuri cry
            neuri "犯规。你这是犯规，黄牌。"
            show neuri wink
            neuri "那，明年你可以第一个来找我。VIP 待遇。"
            $ gs.add_affinity("neuri", 10)
        "“那你今晚就先睡吧。我陪你挂着电话。”":
            show neuri tired
            neuri "嗯。不许先挂。"
            "那天晚上，电话那头一直有海浪的声音。后来不知道谁先睡着了。"
            $ gs.add_affinity("neuri", 8)
            $ gs.add_san(5)
    hide neuri
    return

label neuri_backstage:
    scene cg_neuri_backstage
    with dissolve
    "全场彩排结束后的后台。化妆镜边上的灯泡一个一个灭掉。"
    "卸了妆的妮瑞穿着一件宽大的 T 恤，手里握着一杯冰早就化了的美式。"
    neuri "啊。被你看到了。"
    neuri "十二月会有两万个人在台下喊我。我连他们一半人的论文标题都记不住。"
    neuri "我是不是挺过分的？"
    neuri "我有时候会想，明年大家要是都不来了怎么办。说不定我就是个泡沫。"
    menu:
        "“明年我也会来。不管投不投稿。”":
            neuri "笨蛋。哪有不投稿还来看的。"
            neuri "那说好了。两万个人里，我先找你。"
            $ gs.add_affinity("neuri", 12)
        "“泡沫也是很漂亮的。”":
            neuri "这是安慰？听着不太像。"
            neuri "算了，收下了。"
            $ gs.add_affinity("neuri", 7)
    scene bg backstage
    with dissolve
    return

label react_neurips_accept:
    show neuri stage
    neuri "[gs.given_name]君！你的论文进歌单了！十二月，新城市见！"
    show neuri wink
    neuri "这次是真的记住了。标题、作者，还有你。"
    hide neuri
    return

label react_neurips_reject:
    show neuri pout
    neuri "呜，sorry，[gs.given_name]君。抽签……不是，审稿结果出来了。"
    show neuri serious
    neuri "你的 rebuttal 我看了。第三段写得特别好。我没骗你。"
    hide neuri
    $ gs.add_affinity("neuri", 3)
    return

## ---------------------------------------------------------------------------
## 冲突：限投（彩排后的舞台之后）
## ---------------------------------------------------------------------------
label neuri_cap:
    scene bg concert_stage
    show neuri serious
    "后台的桌上摊着一张表。投稿数一栏是两万四，审稿人一栏是一万一。"
    neuri "[gs.given_name]君，你帮我想想。"
    neuri "审稿人不够，一个人要审七八篇。大家开始用大模型凑意见，作者又骂我抽签。"
    neuri "委员会说，干脆每人限投三篇。可是这样，那些想多试几次的新人怎么办？"
    show neuri pout
    neuri "你说，公不公平？"
    menu:
        "“支持限投。先让审稿人能好好读。”":
            show neuri serious
            neuri "嗯……审稿人也是人。这个理由我能接受。"
            $ gs.flag("neuri_cap_yes")
            $ gs.add_affinity("neuri", 4)
        "“反对。新人就是靠多试几次才进来的。”":
            show neuri wink
            neuri "你是在替自己说话吧？一年级。"
            neuri "不过你说得对，舞台不能只给熟面孔。"
            $ gs.flag("neuri_cap_no")
            $ gs.add_affinity("neuri", 4)
        "“先别管公平。你看起来三天没睡了。”":
            show neuri surprised
            neuri "……诶？"
            "她愣了一下，然后笑了。不是舞台上那种，嘴角歪着，有点难看。"
            show neuri tired
            neuri "四天。被你看出来了。"
            neuri "那我今天先睡。那张表，明天再看。"
            $ gs.flag("neuri_rest")
            $ gs.add_affinity("neuri", 8)
    hide neuri
    return


## ---------------------------------------------------------------------------
## 约定：失声（视频通话之后，聊天）
## ---------------------------------------------------------------------------
label neuri_voice:
    scene bg backstage
    with fade
    "离演出还有两天。妮瑞让你来后台，见了面却不说话，只把手机递给你。"
    $ chat_open("妮瑞")
    $ chat_say("neuri", "嗓子哑了")
    $ chat_say("neuri", "医生说两天不能说话，一个字都不行")
    $ chat_say("neuri", "彩排今晚就要走台。经纪人在外面打电话找替补主持")
    $ chat_say("neuri", "%s君，我该怎么办" % gs.given_name)
    $ t_c = chat_reply([("陪她走台，替她举提词板", "我给你举提词板。今晚你只管走位，要说的话我写在板子上"), ("劝她这次推迟", "推迟吧。演出明年还有，嗓子坏了就没了")])
    if t_c == 0:
        $ chat_say("neuri", "你会写很丑的字吧")
        $ chat_say("neuri", "……好。丑也行")
        "那天晚上你在台侧举了两个小时的白板。她每次走到台口，都朝你比一个手势，像在说“下一句”。"
        "两天后医生松了口：可以唱，少说话。演出那晚，歌是她自己唱的，串场的话还是写在你举的白板上，投到了大屏幕上。"
        $ gs.flag("neuri_stay")
        $ gs.add_affinity("neuri", 8)
        $ gs.add_san(-5)
    else:
        $ chat_say("neuri", "推迟的话，两万个人会很失望")
        $ chat_say("neuri", "但你说得对。我去跟他们说")
        "第二天，演出推迟一周的公告挂上了官网。评论区有人骂，更多的人在说“好好休息”。"
        $ gs.add_affinity("neuri", 5)
    $ chat_close()
    return


## ---------------------------------------------------------------------------
## 挚友结局
## ---------------------------------------------------------------------------
label neuri_friend_end:
    scene bg conference_city
    with fade
    show neuri wink
    "九月。下一场演唱会的城市公布了。"
    neuri "[gs.given_name]君！新城市，新场馆，两万五千个座位！"
    neuri "给你留了一张后台通行证。工作人员那种，不是观众那种。"
    if gs.has("neuri_rest"):
        neuri "限投那件事我后来想通了。规则慢慢改，先让人睡觉。你那天说的。"
    elif gs.has("neuri_cap_yes"):
        neuri "限投最后定了每人五篇。今年审稿人那一栏，第一次涨得比投稿数快。"
    elif gs.has("neuri_cap_no"):
        neuri "限投没通过。今年新人那一栏，多了三千个名字。"
    show neuri stage
    neuri "你是我认识的人里，唯一一个看过我卸妆、还没被吓跑的。"
    neuri "这种人，要留在后台。"
    hide neuri
    call reviewer_epilogue
    return


label neuri_end:
    scene bg conference_city
    with fade
    show neuri wink
    "九月。下一场演唱会的城市公布了。"
    if gs.has("accepted_neurips"):
        neuri "[gs.given_name]君！十二月你要站上我的舞台了！海报位置我去看过，离出口很近，方便你紧张了跑路。"
    else:
        neuri "[gs.given_name]君！今年你没上来。没事，明年截稿前一个月，我提前叫你。"
    if gs.has("neuri_stay"):
        neuri "失声那次，你举了两个小时提词板。手酸了吧？我当时就想，以后得请你吃饭。现在还欠着。"
    if gs.has("neuri_rest"):
        neuri "限投那件事我后来想通了。规则慢慢改，先让人睡觉。你那天说的。"
    elif gs.has("neuri_cap_yes"):
        neuri "限投最后定了每人五篇。今年审稿人那一栏，第一次涨得比投稿数快。"
    elif gs.has("neuri_cap_no"):
        neuri "限投没通过。今年新人那一栏，多了三千个名字。"
    neuri "到时候台下还是两万个人。"
    scene cg_neuri_end
    with dissolve
    neuri "我会先找你。"
    neuri "卸了妆的样子也只给你看。别截图。"
    hide neuri
    call reviewer_epilogue
    return
