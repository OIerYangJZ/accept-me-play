## 开场：名字、导师、主攻方向。

label prologue:
    scene bg campus_day
    with fade
    "九月。星海大学计算机系，三楼最里面那间实验室。"
    "大二那年，你在宿舍用一张二手显卡跑通了人生第一个模型。"
    "loss 从 2.3 降到 0.4 的那个晚上，你对着屏幕傻笑了半小时，室友以为你谈恋爱了。"
    "然后你就报了博士。"

    $ t_sur = renpy.input("你姓什么？（直接回车用默认）", default="林", length=4).strip()
    $ gs.surname = t_sur or "林"
    $ t_given = renpy.input("名字呢？（直接回车用默认）", default="知远", length=6).strip()
    $ gs.given_name = t_given or "知远"

    scene bg lab_day
    with dissolve
    show zhao happy
    zhao "新来的吧？我赵一鸣，你隔壁工位。"
    zhao "先跟你说三件事。饮水机是坏的，空调遥控器在韩老师抽屉里，集群别在周五晚上提交任务。"
    p "周五晚上怎么了？"
    show zhao normal
    zhao "全楼都在赶 deadline，你排到下周一。"
    zhao "哦对，还有第四件——你得认识一下这儿的“刊娘”。"
    p "刊……什么？"
    zhao "每个会、每个期刊都有个化身，长得跟人一模一样。投稿就是给她们写信，审稿就是她们拆信。"
    zhao "别用那种眼神看我。读博的都看得见。看不见的，要么毕业了，要么转行了。"

    "你的导师是——"
    menu:
        "韩建国 · 放养型（自由度高，几乎没有算力）":
            $ gs.advisor = "han"
        "周静 · 卷王型（资源多，每周组会掉一层皮）":
            $ gs.advisor = "zhou"
        "Martin Hale · 大厂兼职型（算力管够，人见不着）":
            $ gs.advisor = "hale"

    scene bg advisor_office
    with dissolve
    show expression gs.advisor + " normal" as advisor
    if gs.advisor == "han":
        adv "来了？坐。茶叶在那个铁盒里，自己泡。"
        adv "做什么方向你自己定，我不管。卡的事……你去找赵一鸣，他知道哪台机器晚上没人用。"
    elif gs.advisor == "zhou":
        adv "欢迎。组里今年的目标是十篇顶会，你占一篇。"
        adv "下周组会，每个人讲三个 idea。你是新人，讲两个就行。"
        adv "今晚十二点前把第一个发我邮箱。"
    else:
        adv "Hi! Welcome! Sorry, I'm at the airport, my flight is boarding in five minutes."
        adv "GPU 随便用，公司那边给我们配了很多。有事发邮件，我一般……两周内会回。"
        "视频挂断了。整个面谈持续了四分钟，其中一分半是他在找耳机。"

    "你打算主攻哪个方向？"
    menu:
        "通用机器学习（ICLR / ICML / NeurIPS 是主场）":
            $ gs.track = "ml"
        "计算机视觉（CVPR / ICCV 是主场）":
            $ gs.track = "cv"
        "自然语言处理（ACL 是主场）":
            $ gs.track = "nlp"

    if gs.advisor == "hale":
        hide advisor
        "当天晚上，邮件到了，只有一行：Keep working on your undergrad thesis. Next deadline: 4 weeks. —M."
    else:
        adv "行。你本科那篇毕业论文，接着往下做吧。听说挂过 arXiv？"
        p "挂过。不过写得挺烂的。"
        adv "烂才有得改。最近的截稿日在四周以后。"
        hide advisor
    scene bg campus_day
    with dissolve
    "回宿舍的路上，你想起面试时被问过的那个问题：为什么要读博？"
    menu:
        "“因为好奇。想知道模型到底是怎么学会的。”":
            $ gs.flag("why_curious")
            "那天你说完，面试老师在纸上记了一笔。你到现在也不知道他记的是什么。"
        "“为了以后好找工作。博士毕业，起薪高一截。”":
            $ gs.flag("why_career")
            "那天你说完，面试老师笑了一下，说：“诚实。”"
        "“说实话，没想清楚。先试试。”":
            $ gs.flag("why_unsure")
            "那天你说完，面试老师点点头：“大部分人都没想清楚。下一个问题。”"
    "【玩法提示】在手账右页排好接下来几周的日程，按「开始」就会自动推进。截稿日到了就能投稿。"
    "【玩法提示】日程有搭配：先跑实验再写论文、读完论文再推公式，效果更好；连轴转太久会额外掉 SAN。"
    "【玩法提示】去见刊娘时，聊她喜欢的话题好感涨得更快。她的反应会告诉你她喜欢什么。"
    return
