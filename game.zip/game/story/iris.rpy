## 艾瑞丝（CVPR）—— 人气王

label iris_intro:
    scene bg poster_hall
    with fade
    "海报区。人挤人，空气里全是咖啡和刚打印出来的海报的味道。"
    show iris camera
    iris "看这边！"
    $ sfx("shutter")
    "咔嚓。"
    show iris grin
    iris "抓拍成功！表情有点懵，不过眼神光很好。我是艾瑞丝！"
    iris "你论文的第一张图做好了没？审稿人看三秒就决定喜不喜欢你，三秒！"
    p "还没画。"
    show iris pout
    iris "那不行。图丑的话，方法再好也没人往下翻。"
    menu:
        "“那你帮我看看现在这张草图？”":
            show iris camera
            iris "灰配灰！主角先换成橙色。看，是不是一下就跳出来了？"
            $ paper_buff(clarity=2, hype=3)
            $ gs.add_affinity("iris", 3)
        "“我觉得方法比图重要。”":
            show iris stunned
            iris "……你是认真的？"
            show iris grin
            iris "有意思。那等你的方法让我服气。"
            $ paper_buff(rigor=2)
            $ gs.add_affinity("iris", 1)
    show iris wink
    iris "画好了拿来给我看。配色我包了。"
    $ gs.add_affinity("iris", 6)
    hide iris
    "【艾瑞丝】CVPR 的化身。看重实验结果和表达，身边永远挤满了人。"
    return

label visit_iris:
    scene bg poster_hall
    $ t_v = renpy.random.randint(1, 3)
    if t_v == 1:
        show iris grin
        iris "今天又有人刷新纪录了，涨了零点三！全场鼓掌！"
        show iris lonely
        iris "掌声挺响的。"
    elif t_v == 2:
        show iris camera
        iris "[gs.given_name]，帮我看一下这张 teaser。是不是太满了？"
        p "左上角那个箭头指的是什么？"
        show iris stunned
        iris "指的是……什么都没指。作者说加个箭头显得专业。"
    else:
        show iris wink
        iris "海报区有条小路，绕过所有人流直通咖啡机。"
        iris "就告诉你一个。别带别人走。"
    hide iris
    return

label iris_poster:
    scene bg poster_hall
    show iris camera
    iris "[gs.given_name]，今天人超多，拉着我袖子，别走散！"
    "她带着你从人缝里钻过去，一张海报一张海报地看。"
    iris "这篇涨了 0.4，这篇 0.2，这篇 0.1，但是作者笑得最开心。"
    p "那这篇为什么有效？"
    show iris stunned
    iris "啊？"
    iris "为什么有效？"
    show iris lonely
    iris "来找我的人都问“涨了多少”。“为什么”这个问题，好像没人问过我。"
    menu:
        "“我们一起去问作者吧。”":
            show iris jump
            iris "走！我帮你挤！"
            $ gs.add_affinity("iris", 9)
        "“涨点也很重要啦。”":
            show iris grin
            iris "对，很重要。"
            $ gs.add_affinity("iris", 4)
    hide iris
    return

label iris_rank:
    scene bg lab_night
    show iris pout
    "深夜，艾瑞丝坐在你工位旁边，下巴搁在你的显示器上沿，盯着一张排行榜。"
    iris "你的方法在这个数据集上，离第一名差 0.1。"
    iris "换个随机种子，或者把测试集的预处理稍微动一动，就第一了。"
    show iris lonely
    iris "大家都这么干的。我见得多了。"
    menu:
        "“那就试试吧。第一名总比第二名好看。”":
            show iris grin
            iris "好！第一张图上写 SOTA，加粗，红色！"
            "你换了七个随机种子。第七个，你成了第一。"
            "那天晚上你两点躺下，四点还睁着眼，在脑子里一遍一遍地数那七个种子。"
            if gs.current_paper:
                $ gs.current_paper.attrs["sota"] = min(100, gs.current_paper.attrs["sota"] + 8)
                $ gs.current_paper.water += 6
            $ gs.add_affinity("iris", 4)
        "“我不想要那 0.1 个点。我想知道它为什么只差 0.1。”":
            show iris stunned
            iris "为什么只差 0.1……"
            "你们花了一整晚翻错误样本。最后发现你的方法在夜景图片上特别强，在逆光图片上特别弱。"
            show iris jump
            iris "逆光！我就知道！这个比第一名好玩多了，我要把它画成第一张图！"
            if gs.current_paper:
                $ gs.current_paper.attrs["rigor"] = min(100, gs.current_paper.attrs["rigor"] + 6)
            $ gs.add_affinity("iris", 10)
            $ gs.flag("iris_why")
    hide iris
    return

label iris_photo:
    scene cg_iris_photo
    with dissolve
    iris "[gs.given_name]，站那儿别动。"
    $ sfx("shutter")
    "咔嚓。"
    iris "这张不用调色，不用裁，也不用跟谁比。"
    iris "直出。"
    menu:
        "“那换我给你拍一张。”":
            iris "我？我一般都在镜头后面的。"
            iris "那你蹲低一点，从下往上拍显腿长。光从左边来，别让我眯眼。"
            $ gs.add_affinity("iris", 12)
        "“能发我一份吗？”":
            iris "可以！原图发你。我自己这份放私人相册，不发朋友圈。"
            $ gs.add_affinity("iris", 8)
    scene bg poster_hall
    with dissolve
    return

label react_cvpr_accept:
    show iris jump
    iris "中了中了！海报我来配色，标题字号要大，大到隔三排都能看见！"
    hide iris
    return

label react_cvpr_reject:
    show iris pout
    iris "那几个审稿人肯定没认真看你的第一张图！"
    iris "没事，我妹妹奥德今年开张，三月截稿。去她那儿试试？"
    hide iris
    return

label react_iccv_accept:
    show iris jump
    iris "奥德收下啦！我们姐妹都喜欢你的图！"
    hide iris
    return

label react_iccv_reject:
    show iris pout
    iris "奥德说你的图还能再好看点。她比我还挑。"
    hide iris
    return

label submitted_iccv:
    show odd normal
    odd "姐姐说你挺有意思的。我是奥德，只在奇数年出现。"
    odd "明年就换我妹妹伊芙了。所以，抓紧。"
    hide odd
    return

## ---------------------------------------------------------------------------
## 冲突：测试集泄漏（差 0.1 之后）
## ---------------------------------------------------------------------------
label iris_leak:
    scene bg poster_hall
    show iris lonely
    "海报区今天没开放。艾瑞丝一个人坐在空展板前面，相机放在膝盖上。"
    iris "你看新闻了吗？去年我这儿分数最高的那篇，测试集混进了训练集。"
    iris "提升三个点，全是漏的。我当时还给它拍了好多张，挂在入口最显眼的地方。"
    iris "我看了它三秒就喜欢上了。"
    show iris pout
    iris "[gs.given_name]，我是不是看人的眼光很差？"
    menu:
        "“这是作者的错，不是你的。”":
            show iris grin
            iris "嗯。你这么说，我就当真了。"
            $ gs.add_affinity("iris", 6)
        "“只看分数的话，迟早会出这种事。”":
            show iris stunned
            if gs.has("iris_why"):
                iris "你说得对。"
                iris "那次差 0.1 你没刷，你是有资格这么说我的人。"
                $ gs.add_affinity("iris", 5)
            else:
                iris "你说得轻松。"
                "她把相机挂回脖子上，起身走了。走到一半又回头：“你说得对，我只是不想听。”"
                $ gs.add_affinity("iris", -2)
        "“那我们写一份检查清单。以后每篇都先过一遍。”":
            show iris jump
            iris "清单！好！第一条你来写。"
            "你在纸上写下第一条：“测试集在哪？”她在旁边画了一个放大镜。"
            "清单写了十七条。最后一条是她加的：“图好看不代表结果对。”"
            $ gs.flag("iris_checklist")
            $ gs.add_affinity("iris", 8)
            $ paper_buff(rigor=3)
    hide iris
    return


## ---------------------------------------------------------------------------
## 约定：暗房（泄漏之后）
## ---------------------------------------------------------------------------
label iris_darkroom:
    scene bg poster_hall
    show iris camera
    iris "今天不拍数码的。跟我来，带你去个地方。"
    "她带你去了学校角落一间暗房。红灯，药水味，晾衣绳上夹着几张湿照片。"
    iris "胶片要冲、要晾。暗房一周只开两个晚上，这卷排到了三天以后。"
    iris "我平时最受不了等。按一下就要看到，涨一个点就要立刻发出去。"
    show iris blush
    iris "这卷里有好几张是你。冲出来之前，我也不知道拍得怎么样。"
    menu:
        "“那就三天以后，一起看。”":
            show iris grin
            iris "说好了。不许提前问我。"
            "三天后你们一起把底片对着窗户看。第十二张，你在笑，焦点刚好对在你身上。"
            $ gs.flag("iris_wait")
            $ gs.add_affinity("iris", 8)
        "“冲好了发我就行。”":
            show iris pout
            iris "也行。"
            "三天后她发来一张照片，没有配字。"
            $ gs.add_affinity("iris", 4)
    hide iris
    return


## ---------------------------------------------------------------------------
## 挚友结局
## ---------------------------------------------------------------------------
label iris_friend_end:
    scene bg poster_hall
    with fade
    show iris grin
    "一年级的最后一天，海报区空荡荡的。"
    iris "今年的照片我整理好了，四千多张。有你的有两百张左右。"
    iris "大多数是你在海报区，盯着别人的图看半天不走。"
    show iris camera
    iris "最后来一张合影！站我旁边，别站那么远。"
    $ sfx("shutter")
    "咔嚓。"
    iris "明年第一张图，还是先拿给我看。配色我包。"
    hide iris
    call reviewer_epilogue
    return


label iris_end:
    scene bg poster_hall
    with fade
    show iris camera
    "一年级的最后一天，海报区空荡荡的，展板拆得只剩架子。"
    iris "人都走了。我还挺喜欢这个时候的。"
    iris "光线干净，背景也干净，镜头里只放一个人就够了。"
    if gs.has("iris_why"):
        show iris grin
        iris "那天晚上画的逆光那张图，我一直存着。有人问我“为什么只差 0.1”，我就拿出来给他们看。"
        iris "看的人还挺多的。比看排行榜的人站得久。"
    if gs.has("iris_checklist"):
        show iris grin
        iris "那份检查清单，今年的审稿人都在用。第一条还是你写的：“测试集在哪？”"
    if gs.has("iris_wait"):
        iris "暗房那卷胶片，第十二张最好看。你等了三天，值了吧？"
    scene cg_iris_end
    with dissolve
    iris "[gs.given_name]，站那儿别动。"
    $ sfx("shutter")
    "咔嚓。"
    iris "这张不给别人看。年度最佳，评委就我一个。"
    hide iris
    call reviewer_epilogue
    return
