## 娜塔莉（Nature）—— 隐藏大小姐

label natalie_letter:
    scene bg lab_day
    "你的桌上多了一封信。厚厚的米色信封，深红色火漆封口，印着一片金色的叶子。"
    show winston bow
    winston "冒昧打扰。鄙人是娜彻家的管家，温斯顿。"
    winston "大小姐留意到了您那篇用 AI 解决科学问题的工作。"
    show winston normal
    winston "她吩咐我转告：倘若有朝一日，您的工作能改变一门学科——"
    winston "娜彻家的大门，会为您打开。"
    menu:
        "“请转告大小姐，我会写出值得她读的论文。”":
            show winston bow
            winston "我会一字不差地转告。"
            winston "（小声）大小姐不太喜欢“值得”这个词。不过我还是会转告。"
            $ gs.add_affinity("natalie", 2)
        "“我做研究，不是为了被谁接收。”":
            winston "这句话，我会原样转告。"
            winston "大小姐大概会读两遍。"
            $ gs.add_affinity("natalie", 5)
            $ gs.flag("natalie_letter_answer")
    show winston normal
    winston "当然，在那之前，您的稿件须先经过我的书桌。我的书桌不太好说话。"
    $ gs.flag("nature_unlocked")
    $ gs.add_affinity("natalie", 5)
    hide winston
    "【娜塔莉】Nature 的化身。只对 AI for Science 方向的工作感兴趣。"
    "【玩法提示】现在你可以在每周计划界面里随时把 AI for Science 论文投给 Nature。编辑会先做初筛。"
    return

label natalie_tea:
    scene bg mansion
    with dissolve
    show winston bow
    winston "[gs.surname]先生，请进。大小姐吩咐，今日下午茶备两人份。"
    hide winston
    show natalie cold
    natalie "坐。今年你是头一个进这间屋子的作者。"
    natalie "别多想。我不过是好奇，写那篇论文的是个什么样的人。"
    "红茶很香。娜塔莉端着杯子，始终没喝。"
    natalie "许多人以为，被我收下，人生便会不一样。"
    show natalie tired
    natalie "我收下的论文，十年以后，大半已无人记得。"
    natalie "被记住的，倒常常是当年被我退回去、后来自己长成了的东西。"
    menu:
        "“那你为什么还要拒绝那么多人？”":
            show natalie cold
            natalie "因为我只有这么多页。"
            show natalie tired
            natalie "也因为，倘若我来者不拒，被我收下这件事便一文不值了。我知道这不近人情。"
            $ gs.add_affinity("natalie", 8)
        "“我不是为了被你接收才做研究的。”":
            show natalie surprised
            natalie "……"
            show natalie smile
            natalie "很好。今年听过的回答里，这一句最好。"
            $ gs.add_affinity("natalie", 10)
            $ gs.flag("natalie_answer")
    show winston normal at right2
    winston "（小声）[gs.surname]先生，大小姐为了这次下午茶，换了三套衣服。"
    show natalie surprised
    natalie "温斯顿！"
    winston "失言了。是四套。"
    hide winston
    hide natalie
    return

label visit_natalie:
    scene bg mansion
    $ t_v = renpy.random.randint(1, 2)
    show winston normal
    if t_v == 1:
        winston "大小姐今日不见客。请留下您的稿件，以及足以改变世界的理由。后者可以简短些。"
    else:
        winston "大小姐正在审阅今日来信，共计三百一十二封。"
        winston "已退回三百零九封。余下三封，她看得很慢。"
    hide winston
    "你抬头看了一眼二楼的窗户。窗帘动了一下。"
    $ gs.add_affinity("natalie", 1)
    return

label natalie_window:
    scene bg mansion
    "娜彻家的宅邸。温斯顿难得没拦你，只朝楼梯的方向欠了欠身。"
    scene cg_natalie_window
    with dissolve
    natalie "你又来了。"
    natalie "我每年收到上万封信，几乎都退回去了。"
    natalie "来的人都只问一件事：要怎样才能被我收下。"
    natalie "这些年，没有人问过我累不累。温斯顿也没有。他只问我茶要几分热。"
    menu:
        "“你会累吗？”":
            natalie "……"
            natalie "会。"
            natalie "谢谢你问。"
            $ gs.add_affinity("natalie", 12)
        "“我会写出让你接受的论文。”":
            natalie "人人都这么说。"
            natalie "然后呢？被我收下以后，你又想要什么？"
            $ gs.add_affinity("natalie", 4)
            $ gs.flag("natalie_question")
    scene bg mansion
    with dissolve
    return

label react_nature_accept:
    scene bg mansion
    show natalie smile
    natalie "我收下了。"
    show natalie cold
    natalie "如今你得到了。然后呢？"
    "你张了张嘴，没答上来。"
    show natalie true_smile
    natalie "不急。答案不在我这里。"
    hide natalie
    return

label react_nature_reject:
    show winston normal
    winston "大小姐读完了您的稿件。她让我转告：很遗憾，这一次不行。"
    winston "另外，结论那一段她读了两遍。这一句她没让我转告。"
    hide winston
    return

## ---------------------------------------------------------------------------
## 心事：温斯顿的书桌（下午茶之后）
## ---------------------------------------------------------------------------
label natalie_desk:
    scene bg mansion
    show winston normal
    winston "[gs.surname]先生，大小姐在午睡。若您不介意，鄙人带您参观一样东西。"
    "那是一张很大的胡桃木书桌。左边一摞是退回的稿件，每一份上面都夹着一张手写便笺。"
    winston "初筛由鄙人负责。每一封退稿信，都是鄙人亲笔。"
    winston "这一封，作者的数据是好的，可惜问题不新。这一封，问题是新的，数据却撑不住。"
    show winston bow
    winston "冒昧一问：若是您来写，会如何落笔？"
    menu:
        "“写真话：哪里好，哪里不够，怎么改。”":
            show winston normal
            winston "真话最难写，也最费墨水。"
            winston "鄙人抄一份，放在左上角。"
            $ gs.flag("natalie_desk_honest")
            $ gs.add_affinity("natalie", 7)
        "“写客气话：感谢投稿，期待再投。”":
            winston "鄙人年轻时也这么写。后来发现，作者读得出来哪些字是客气。"
            $ gs.add_affinity("natalie", 3)
        "“不写，原样退回。”":
            show winston stern
            winston "这是最省事的一种，也是最伤人的一种。"
            $ gs.add_affinity("natalie", 1)
    "楼上传来开门的声音。温斯顿把书桌上的便笺理整齐，若无其事地站回原位。"
    winston "鄙人什么都没给您看过。"
    hide winston
    return


## ---------------------------------------------------------------------------
## 挚友结局
## ---------------------------------------------------------------------------
label natalie_friend_end:
    scene bg mansion
    with fade
    show natalie smile
    "一年级的最后一天。娜彻家的下午茶，照例备了两人份。"
    natalie "你今年的工作，我读过。还不到改变一门学科的程度。"
    natalie "但方向是对的。我很少这么说。"
    show winston normal at right2
    winston "（小声）大小姐今年只这么说过一次。"
    show natalie surprised
    natalie "温斯顿。"
    show natalie smile
    natalie "明年再来喝茶。稿子带不带，随你。"
    hide winston
    hide natalie
    call reviewer_epilogue
    return


label natalie_end:
    scene bg mansion
    with fade
    show natalie true_smile
    "一年级的最后一天。二楼那扇窗开着，娜塔莉站在窗边等你。"
    if gs.has("accepted_nature"):
        natalie "你的论文，我收下了。"
        natalie "如今你得到了。然后呢？"
        "你想了想，说：“然后，明天接着做。”"
        natalie "嗯。答对的人不多。"
    elif gs.has("natalie_answer"):
        natalie "你说过，你做研究不是为了被我收下。"
        natalie "那句话，我记到了现在。"
    if gs.has("natalie_desk_honest"):
        natalie "温斯顿说，你那三句话他抄了一份，压在书桌左上角。他现在写退稿信，都先看一眼。"
    scene cg_natalie_end
    with dissolve
    natalie "我还会退回很多人的稿子。这是我的职分。"
    natalie "不过，你下回来——"
    natalie "可以不带稿子。"
    hide natalie
    call reviewer_epilogue
    return
