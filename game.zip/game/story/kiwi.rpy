## 夏可薇（arXiv）—— 青梅竹马 / 真结局线

label kiwi_intro:
    scene bg dorm_night
    with fade
    $ sfx("phone")
    "开学第一天晚上。八点整，手机响了。"
    show kiwi laugh
    kiwi "[gs.given_name]！今日更新！"
    kiwi "cs 分类今天上新四百多篇，我帮你挑了跟你方向有关的——嗯，八十篇。不多吧？"
    p "可薇？你怎么知道我在这儿？"
    show kiwi pout
    kiwi "你本科毕业论文挂在我这里呀。编号我能背出来，要不要听？"
    kiwi "你给我的第一封信嘛，当然记得。"
    show kiwi normal
    kiwi "听说你要接着做那篇？那以后每天八点我都来，给你送今日更新。不许嫌烦。"
    $ t_title = pick_line("arxiv_headlines", "titles")
    kiwi "比如这篇——「[t_title]」。好不好玩！"
    menu:
        "“好玩。正文我今晚就看。”":
            show kiwi laugh
            kiwi "说好了！明天八点我要考你的！"
            $ gs.add_affinity("kiwi", 4)
            $ gs.ideas += 1
        "“八十篇……可薇，我还有自己的论文要写。”":
            show kiwi pout
            kiwi "知道啦知道啦。那我挑三篇，最多三篇！"
            $ gs.add_san(4)
    $ gs.add_affinity("kiwi", 8)
    hide kiwi
    "【夏可薇】arXiv 的化身。她不审稿，什么都收。"
    "【玩法提示】“挂 arXiv / 宣传”可以提升热度。和她分享你的失败，也会让她更亲近你。"
    return

label visit_kiwi:
    scene bg dorm_night
    $ t_title = pick_line("arxiv_headlines", "titles")
    if gs.low_san:
        show kiwi lonely
        kiwi "[gs.given_name]，你脸色好差。今天更新不念了，我们随便聊聊。"
        kiwi "晚饭吃了没？昨晚几点睡的？不许说“等这个实验跑完”。"
        $ gs.add_san(4)
    else:
        $ t_v = renpy.random.randint(1, 3)
        if t_v == 1:
            show kiwi laugh
            kiwi "今日更新！「[t_title]」！"
            p "这篇我看过了，方法部分只有半页。"
            kiwi "你居然真的点开了！我要记一笔。"
        elif t_v == 2:
            show kiwi pout
            kiwi "有个作者今天把同一篇论文更新到 v7 了。"
            kiwi "v7 啊！他改一个错别字我就得重新发一次邮件提醒。"
            show kiwi laugh
            kiwi "不过算啦。改到第七版的人，肯定是很想把它弄好嘛。"
        else:
            show kiwi normal
            kiwi "今天换我问你。"
            kiwi "你今天干嘛了？没成的也算。"
            p "跑了一个实验，结果比基线还差。"
            show kiwi laugh
            kiwi "好，记下了！这条算今天的头条。"
    hide kiwi
    return

label kiwi_8pm:
    scene cg_kiwi_8pm
    with dissolve
    "晚上八点零五分。可薇抱着枕头趴在你桌子边上念今天的更新，声音越来越小。"
    kiwi "第三百二十七篇，「Towards」……第三百二十八篇，「Towards」……怎么又是 Towards……"
    p "可薇，你不用每篇都念给我听。"
    kiwi "可是大家都是把东西往我这儿一放，就去找别人了呀。"
    kiwi "截稿日一过，所有人一窝蜂地来：“先挂上去，占个坑。”挂完就再也不回来看一眼。"
    kiwi "我就想有个人，能坐下来，好好看看它们。"
    menu:
        "“那以后我陪你看。一天看十篇也行。”":
            kiwi "十篇也太少了吧。"
            kiwi "……行，十篇就十篇。说好了啊。"
            $ gs.add_affinity("kiwi", 8)
        "“你也不用对每个人都这么好。”":
            kiwi "我就是这样嘛。什么都收，是我唯一会做的事。"
            $ gs.add_affinity("kiwi", 3)
    scene bg dorm_night
    with dissolve
    return

label kiwi_snack:
    scene bg dorm_night
    show kiwi sleepy
    "凌晨一点。宿舍楼下，可薇提着一袋夜宵站在路灯底下，穿着拖鞋。"
    kiwi "我猜你又没吃晚饭。"
    p "你怎么知道？"
    show kiwi pout
    kiwi "你九点挂了一篇，十点改了一次，十一点又改了一次。"
    kiwi "吃饱的人才不会这么急。"
    "你们坐在宿舍楼前的台阶上，分一碗已经有点凉的关东煮。萝卜被她先挑走了。"
    show kiwi normal
    kiwi "你还记得本科毕业那天晚上吗？"
    kiwi "你的毕业论文是凌晨三点挂上来的。挂完你给我发消息：“可薇，我是不是写得很烂？”"
    show kiwi laugh
    kiwi "我回你：“编号已经给你了，烂不烂以后再说。”"
    menu:
        "“那句话，我一直记着。”":
            show kiwi blush
            kiwi "骗人的吧。"
            kiwi "那我以后还这么说。烂不烂以后再说，先给你编号。"
            $ gs.add_affinity("kiwi", 9)
        "“那篇确实写得很烂。”":
            show kiwi laugh
            kiwi "对！烂透了！但我是第一个读完的！"
            $ gs.add_affinity("kiwi", 6)
    $ gs.add_san(8)
    hide kiwi
    return

label kiwi_failure:
    scene bg dorm_night
    $ sfx("phone")
    "第一次被拒的那天晚上，八点整，手机照样响了。"
    show kiwi anxious
    kiwi "今日更——[gs.given_name]？你在吗？"
    menu:
        "把审稿意见和失败的实验都发给她":
            show kiwi normal
            kiwi "我看完了。"
            kiwi "你那个消融实验的思路挺好的，就是还没做完。有一条意见根本没看懂你的实验，你别听。"
            kiwi "以后没成的东西也发我吧。我想知道你每天在干嘛，不是只想知道你做成了什么。"
            $ gs.add_affinity("kiwi", 10)
            $ gs.add_san(10)
            $ gs.flag("kiwi_failure")
        "“没事，下次再说。”":
            show kiwi lonely
            kiwi "嗯。那我明天八点再来。"
            $ gs.add_affinity("kiwi", 1)
    hide kiwi
    return

label kiwi_scoop:
    scene bg lab_day
    show kiwi cry
    kiwi "[gs.given_name]，对不起。"
    kiwi "那篇跟你撞了的论文，是昨天下午挂到我这儿的。我一看摘要就知道要糟。"
    kiwi "可是我没法不收它。我从来都没法不收。"
    menu:
        "“这不是你的错。”":
            show kiwi lonely
            kiwi "嗯。"
            kiwi "那你下次早点把东西给我。我帮你把时间记下来，记你先做出来的那个时间。"
            $ gs.add_affinity("kiwi", 8)
        "“反正挂在你这里又不算正式发表。”":
            show kiwi lonely
            "可薇没说话。"
            "那天晚上八点，手机没有响。"
            $ gs.add_affinity("kiwi", -10)
            $ gs.flag("hurt_kiwi")
    hide kiwi
    return

label kiwi_heart:
    scene bg campus_day
    show kiwi normal
    kiwi "跟你说个数字。我这儿现在有两百多万篇论文。"
    kiwi "里面有好多，到最后也没被哪个会、哪个期刊收过。"
    kiwi "可它们都还在呀。有编号，有日期，某天晚上有人点开过。"
    show kiwi blush
    kiwi "所以我觉得吧，被收下不是唯一要紧的事。"
    kiwi "被人看见也算。"
    menu:
        "“我看见你了。”":
            show kiwi cry
            kiwi "笨蛋，突然说这个干嘛。"
            show kiwi laugh
            kiwi "那我也把你记下来。编号就叫“今天”。"
            $ gs.add_affinity("kiwi", 12)
        "“我会写出一篇真正被接收的论文给你看。”":
            show kiwi normal
            kiwi "好啊，我等着。不过不管收没收，我都要第一个读。"
            $ gs.add_affinity("kiwi", 6)
    hide kiwi
    return

## ---------------------------------------------------------------------------
## 冲突：要不要设门槛（关东煮之后）
## ---------------------------------------------------------------------------
label kiwi_gate:
    scene bg dorm_night
    "前一天晚上八点，手机没响。八点十分，八点半，也没有。"
    "你点开 arXiv，今日更新照常挂着，就是没人念。"
    scene bg campus_day
    with dissolve
    show kiwi anxious
    kiwi "昨晚对不起！我在开会，一直开到两点。"
    kiwi "有篇预印本上了热搜，说给大模型喂咖啡因相关的语料它就会变聪明。实验跑了三次，图是手画的。"
    show kiwi lonely
    kiwi "评论区都在骂我什么都收。委员会有人提议，以后挂上来之前先审一遍。"
    kiwi "我弃权了。[gs.given_name]，我是不是该学着拒绝别人了？"
    menu:
        "“你别变。挂个东西，凭什么要人批准。”":
            show kiwi blush
            kiwi "你这话，跟我自己写在首页上的那句差不多。"
            kiwi "行。下次开会，弃权改反对。"
            $ gs.flag("kiwi_stay_open")
            $ gs.add_affinity("kiwi", 8)
        "“加一点门槛也好，至少挡掉那种。”":
            show kiwi normal
            kiwi "嗯。那篇确实挺离谱的。"
            "她低头踢了一下台阶边上的小石子，没再说话。"
            $ gs.flag("kiwi_gate_yes")
            $ gs.add_affinity("kiwi", 3)
        "“你想怎么做都行。要吵架的话，我陪你去。”":
            show kiwi laugh
            kiwi "你又不是委员会的！"
            kiwi "不过谢谢。昨晚那期，我今晚补给你，双倍。"
            $ gs.flag("kiwi_gate_with")
            $ gs.add_affinity("kiwi", 6)
            $ gs.add_san(-3)
    "那天晚上八点，手机响了。比平时晚一分钟。"
    hide kiwi
    return


## ---------------------------------------------------------------------------
## 约定：服务器维护的晚上（聊天）
## ---------------------------------------------------------------------------
label kiwi_maintenance:
    scene bg dorm_night
    with fade
    "晚上八点，手机亮了。不是电话，是一条消息。"
    $ chat_open("可薇")
    $ chat_say("kiwi", "今晚服务器维护，更新挂不上去")
    $ chat_say("kiwi", "八点了诶，好安静")
    $ chat_say("kiwi", "不念点什么，手都不知道往哪放")
    $ t_c = chat_reply([("今晚换我念给你", "那今晚换我给你念今日更新"), ("难得清闲，早点休息", "难得清闲，早点睡吧")])
    if t_c == 0:
        $ chat_say("kiwi", "！！！")
        $ chat_say("kiwi", "念什么念什么")
        $ t_c = chat_reply([("我这周跑砸的实验", "念我这周跑砸的三个实验"), ("一篇标题很好笑的论文", "念一篇标题很好笑的"), ("我本科那篇的摘要", "念我本科毕业论文的摘要")])
        if t_c == 0:
            $ chat_say("kiwi", "好！失败的最好听")
            "你一条一条打过去：batch size 写成了 1，数据集下错了版本，第三个……你自己想不起来了。"
            $ chat_say("kiwi", "第三个是忘了固定随机种子。你上周二说的")
            $ gs.flag("kiwi_read_fail")
        elif t_c == 1:
            $ chat_say("kiwi", "《论猫为什么总把杯子推下桌：一个贝叶斯视角》")
            $ chat_say("kiwi", "这篇是我收的！作者还附了三段视频")
        else:
            $ chat_say("kiwi", "编号我背得出来")
            $ chat_say("kiwi", "摘要第二句有个错别字，你到现在都没改")
        $ chat_say("kiwi", "下次换我念给你。说好了")
        "你们一直聊到服务器修好。她发来最后一条：“编号恢复正常。晚安。”"
        $ gs.add_affinity("kiwi", 8)
    else:
        $ chat_say("kiwi", "嗯，也是")
        $ chat_say("kiwi", "晚安")
        "过了十分钟，又来一条：“其实还不困。”你回了个“我也是”。"
        $ gs.add_affinity("kiwi", 3)
    $ chat_close()
    return


## ---------------------------------------------------------------------------
## 挚友结局
## ---------------------------------------------------------------------------
label kiwi_friend_end:
    scene bg dorm_night
    with fade
    show kiwi normal
    "一年级的最后一个晚上。八点整。"
    kiwi "今日更新！今天这期是你今年写的东西。挂过的按编号排，没挂的我排在后面。"
    kiwi "被拒的、被撞的、写一半扔掉的，都在。"
    if gs.has("kiwi_gate_yes"):
        kiwi "对了，委员会最后决定，挂之前做一次格式检查。我投了赞成。"
        kiwi "挡掉一点也好。就是检查的第一天，有个学生因为页边距不对被退了回去。那封退回通知，我盯着看了好久。"
    elif gs.has("kiwi_stay_open"):
        kiwi "门槛那次，我最后投了反对票。没通过。"
    elif gs.has("kiwi_gate_with"):
        kiwi "门槛的事后来又吵了两次会。每次散会我都想起来，有人说过要陪我去吵。"
    show kiwi blush
    kiwi "[gs.given_name]，我有件事想——"
    show kiwi laugh
    kiwi "算啦，等你哪天也有一篇想第一个给我看的，再说。"
    "她把列表塞进你手里，最底下一行空着。"
    kiwi "明年八点，照旧。"
    hide kiwi
    call reviewer_epilogue
    return


label kiwi_end:
    scene bg dorm_night
    with fade
    show kiwi normal
    "一年级的最后一个晚上。八点整。"
    kiwi "今日更新！"
    kiwi "今天这篇比较特别。是你今年写的全部东西，挂过的按编号排，没挂的我排在后面。"
    $ t_acc = len(gs.accepted_papers())
    if t_acc:
        $ t_which = "几" if t_acc > 1 else "一"
        kiwi "被收的那[t_which]篇，我在编号后面画了小星星。画得有点歪。"
    kiwi "被拒的、被撞的、写了一半扔掉的，也都在。"
    if gs.has("hurt_kiwi"):
        show kiwi lonely
        kiwi "你那次说，挂在我这儿不算发表。"
        kiwi "我气了好几天。后来想想，你那时候是吓坏了吧。"
        show kiwi normal
        kiwi "行啦，翻篇。"
    if gs.has("kiwi_failure"):
        kiwi "还有那些只发给我的失败实验。我也都存着，存了一个文件夹，名字叫“[gs.given_name]的今日更新”。"
    if gs.has("kiwi_read_fail"):
        kiwi "服务器维护那晚你念给我的三个实验，也在里面。第三个你自己都忘了，我替你记着。"
    if gs.has("kiwi_stay_open"):
        kiwi "门槛那次，我最后投了反对票。散会以后第一个想打电话的人，是你。"
    elif gs.has("kiwi_gate_yes"):
        kiwi "委员会最后定了，挂之前做一次格式检查。我投的赞成。第一天就退回去一篇，页边距不对。"
    elif gs.has("kiwi_gate_with"):
        kiwi "门槛的事后来又吵了两次会。每次散会我都想起来，有人说过要陪我去吵。"
    show kiwi blush
    kiwi "一整年，满满一页。"
    scene cg_kiwi_end
    with dissolve
    "她把一张打印出来的列表塞进你手里。最底下一行只有一个编号，标题还空着。"
    kiwi "这个号先给你留着。"
    kiwi "下一篇挂上来的时候，我还是八点来念。"
    hide kiwi
    call reviewer_epilogue
    return
