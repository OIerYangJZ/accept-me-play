## 去见刊娘：没有触发剧情事件时，选一个话题聊（玩法见 acceptme/talk.py）。
## “问问她最近怎么样”沿用各自的 visit_<刊娘> 闲聊；另外两个话题的台词在这里。
## 台词本身会透露她喜不喜欢这个话题，玩家可以慢慢摸清每个人的喜好。

init python:
    TALK_SCENE = {
        "kiwi": ("dorm_night", "normal"), "clair": ("openreview_hall", "smile"),
        "aceline": ("old_library", "smile"), "iris": ("poster_hall", "grin"),
        "imel": ("council_room", "calm"), "neuri": ("concert_stage", "wink"),
        "closia": ("datacenter", "veiled_smile"), "natalie": ("mansion", "cold"),
        "chatgpt": ("lab_day", "smile"), "claude": ("library", "smile"),
    }
    TALK_GREET = {
        "kiwi": "来啦！今天想聊什么？先说好，不许只聊论文。",
        "clair": "{surname}同学。今天是来讨论问题的吗？",
        "aceline": "来借书，还是来找我说话？",
        "iris": "{given}！带图来了吗？",
        "imel": "坐。今天讨论什么？",
        "neuri": "{given}君！今天来找我玩吗～",
        "closia": "{surname}先生。",
        "natalie": "你又来了。坐吧。",
        "chatgpt": "您好！今天想聊什么？我会在一定程度上尽力提供帮助。",
        "claude": "{given}，今天想聊什么？",
    }


label talk(h):
    $ t_bg, t_expr = TALK_SCENE[h]
    scene expression "bg " + t_bg
    with dissolve
    show expression h + " " + t_expr as talker
    python:
        # 招呼语和三个话题一起显示（和 on_situation 一样的写法）
        renpy.say(getattr(store, h), TALK_GREET[h].format(surname=gs.surname, given=gs.given_name), interact=False)
        t_topic = renpy.display_menu([("聊聊我的研究", "research"), ("问问她最近怎么样", "her"), ("请教投稿的事", "advice")])
    $ t_repeat = gs.last_topic.get(h) == t_topic
    $ t_res = atalk.talk(gs, h, t_topic)
    if t_repeat:
        call expression "talk_repeat_" + h
    elif t_topic == "her":
        if t_res["tier"] == "cool":
            call expression "talk_her_cool_" + h
        elif h == "natalie":
            call visit_natalie_talk
        else:
            hide talker
            call expression "visit_" + h
    else:
        call expression "talk_%s_%s" % (t_topic, h)
    hide talker
    $ renpy.notify("　·　".join(t_res["lines"]))
    return


## ---------------------------------------------------------------------------
## 夏可薇：最爱闲聊；对投稿建议兴趣不大（她又不审稿）
## ---------------------------------------------------------------------------
label talk_research_kiwi:
    show kiwi laugh as talker
    kiwi "进度给我看看——哇，比上周多了一大截嘛！写完第一个发我！"
    return
label talk_advice_kiwi:
    show kiwi pout as talker
    kiwi "投稿的事问我干嘛呀，我又不审稿。"
    kiwi "……非要说的话：先挂我这儿，宣传起来快，被抢发的时候也有个时间戳。"
    return
label talk_repeat_kiwi:
    show kiwi pout as talker
    kiwi "你上次也聊这个！换个话题嘛。"
    return
label talk_her_cool_kiwi:
    return


## ---------------------------------------------------------------------------
## 克莱尔：最爱讲规则和经验；不太愿意聊自己
## ---------------------------------------------------------------------------
label talk_advice_clair:
    show clair happy as talker
    clair "好。我讲一条规则之外的经验。"
    clair "rebuttal 先回应最严重的那条。分数按“解决了多少”来改，小问题答得再漂亮，也抵不过一个大问题没回。"
    return
label talk_research_clair:
    show clair puzzled as talker
    clair "你的课题，留言板上有人讨论过。有人觉得基线偏少。"
    clair "我只是转述，不代表我的立场。"
    return
label talk_repeat_clair:
    show clair serious as talker
    clair "这个问题你上次问过了。答案没有变。"
    return
label talk_her_cool_clair:
    show clair nervous as talker
    clair "我的事？……留言板上都写着呢，你可以自己看。"
    return


## ---------------------------------------------------------------------------
## 阿瑟琳：最爱聊书和词；你的模型她兴趣一般
## ---------------------------------------------------------------------------
label talk_advice_aceline:
    show aceline reading as talker
    aceline "投之前，把摘要大声读一遍。"
    aceline "读不顺的地方，审稿人也读不顺。我这里，写得清楚比什么都重要。"
    return
label talk_research_aceline:
    show aceline frown as talker
    aceline "结果很好。可是你描述它的那段话，用了三个“显著”。"
    aceline "……我们还是聊点别的吧。"
    return
label talk_repeat_aceline:
    aceline "这个话题我们聊过了。换个说法也行。"
    return
label talk_her_cool_aceline:
    return


## ---------------------------------------------------------------------------
## 艾瑞丝：最爱看你的图和结果；不爱讲“投稿技巧”
## ---------------------------------------------------------------------------
label talk_research_iris:
    show iris camera as talker
    iris "给我看看第一张图！……构图可以，颜色太灰了。"
    iris "主角换成对比色，审稿人一眼就能抓住重点。来，我给你挑！"
    return
label talk_advice_iris:
    show iris pout as talker
    iris "投稿技巧？看图就知道了嘛！"
    iris "……好吧认真说：实验结果是我最看重的，别的都往后排。"
    return
label talk_repeat_iris:
    show iris pout as talker
    iris "又是这个？上次说过啦～"
    return
label talk_her_cool_iris:
    return


## ---------------------------------------------------------------------------
## 伊梅尔：最爱讨论推导；不聊私事
## ---------------------------------------------------------------------------
label talk_research_imel:
    show imel explain as talker
    imel "你的推导，第二个不等式可以收得更紧。"
    imel "我写给你。……这里，常数从 4 变成 2。"
    return
label talk_advice_imel:
    imel "严谨不到三十的论文，rebuttal 里补理论分析很容易失败。"
    imel "先把基础打牢，再谈说服别人。"
    return
label talk_repeat_imel:
    imel "这个上次讨论过。结论没有变。"
    return
label talk_her_cool_imel:
    show imel frown as talker
    imel "我的事？学生会今天开了三个会。就这些。"
    return


## ---------------------------------------------------------------------------
## 妮瑞：最爱闲聊；下班时间不想谈 work
## ---------------------------------------------------------------------------
label talk_advice_neuri:
    show neuri stage as talker
    neuri "投我的话，热度很重要哦！大家都会先去看热门的 work。"
    neuri "还有……审稿结果真的有一点点看运气。多投几次也不丢人！"
    return
label talk_research_neuri:
    show neuri pout as talker
    neuri "work 的事等五月再说嘛～现在是下班时间！"
    return
label talk_repeat_neuri:
    show neuri pout as talker
    neuri "这个上次聊过啦，换一个嘛～"
    return
label talk_her_cool_neuri:
    return


## ---------------------------------------------------------------------------
## 克洛丝：最在意有没有人问她过得怎么样；投稿建议“不便透露”，但会借你算力
## ---------------------------------------------------------------------------
label talk_research_closia:
    show closia watch as talker
    closia "你的方向，我们做过类似的。细节不便透露。"
    closia "不过，你的消融设计比我们的好。"
    return
label talk_advice_closia:
    show closia cold as talker
    closia "投稿建议，不便透露。"
    closia "……算力可以借你一点。别告诉别人。"
    return
label talk_repeat_closia:
    show closia cold as talker
    closia "这个问题，你上次问过。"
    return
label talk_her_cool_closia:
    return


## ---------------------------------------------------------------------------
## 娜塔莉：最想听你的工作改变了什么；不回答“怎样才能被我接受”
## ---------------------------------------------------------------------------
label talk_research_natalie:
    show natalie smile as talker
    natalie "说说你的工作。不是方法，是它改变了什么。"
    natalie "……嗯。这个说法，我记下了。"
    return
label talk_advice_natalie:
    natalie "你在问我，怎样才能被我收下？"
    natalie "人人都这么问。我的回答一直是：做你觉得重要的事。"
    return
label talk_repeat_natalie:
    natalie "同样的问题，我不回答第二遍。"
    return
label talk_her_cool_natalie:
    return

## 娜塔莉的“她的事”不走 visit_natalie（那段是温斯顿挡驾），单独写
label visit_natalie_talk:
    show natalie tired as talker
    natalie "我的事？……今天退回了三百零九封信。"
    natalie "温斯顿说我该出门走走。我说，信还没看完。"
    return
