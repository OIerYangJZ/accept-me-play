## 角色、图片与文本池的定义。

init -10 python:
    import json
    import acceptme
    from acceptme import data as adata
    from acceptme import helpers as ahelpers

    def load_pool(name):
        with renpy.open_file("data/pools/%s.json" % name) as f:
            return json.loads(f.read().decode("utf-8"))

    POOLS = {n: load_pool(n) for n in (
        "review_comments", "reviewer_replies", "arxiv_headlines", "openreview_crowd",
        "omnia_spam", "week_flavor", "scoop_news")}

    with renpy.open_file("data/art_manifest.json") as _f:
        ART = json.loads(_f.read().decode("utf-8"))

    # 立绘：images/sprites/<id>/<id>_<expr>.png -> image <id> <expr>
    #       还没画的表情回退到基础立绘 images/sprites/<id>/<id>.png
    # 背景：images/bg/<id>.png -> image bg <id>；CG：images/cg/<id>.png -> image <id>
    def sprite_path(cid, expr):
        path = "images/sprites/%s/%s_%s.png" % (cid, cid, expr)
        if renpy.loadable(path):
            return path
        base = "images/sprites/%s/%s.png" % (cid, cid)
        return base if renpy.loadable(base) else None

    # ChatGPT / Claude 有“形态”：images/sprites/<id>/<id>_form_<形态>.png，和立绘同一张画布。
    # 有脸部遮罩 <id>_facemask.png 时（导入的原画）：形态图是完整立绘，
    #   显示 = 形态图在下面 + 当前表情只取脸（羽化）叠在上面；表情只画一套，四个形态通用。
    # 没有遮罩时（占位图）：形态图是只有外套的覆盖层，直接叠在表情上。
    # 还没有图的形态显示底图。剧本里用 $ set_form("chatgpt", "astra") 切换，名字也会变成「ChatGPT · Astra」。
    def form_overlay(cid, form):
        path = "images/sprites/%s/%s_form_%s.png" % (cid, cid, form)
        return path if renpy.loadable(path) else None

    def _form_sprite(cid, path, forms):
        args = []
        mask = "images/sprites/%s/%s_facemask.png" % (cid, cid)
        face = AlphaMask(path, mask) if renpy.loadable(mask) else path
        for f in forms:
            ov = form_overlay(cid, f["id"])
            if ov:
                layers = (ov, face) if face is not path else (path, ov)
                args += ["ai_form.get(%r) == %r" % (cid, f["id"]), Fixed(*layers, fit_first=True)]
        if not args:
            return path
        return ConditionSwitch(*(args + ["True", path]))

    def _define_images():
        files = renpy.list_files()
        for c in ART["characters"]:
            cid = c["id"]
            for expr in c["expressions"]:
                path = sprite_path(cid, expr)
                if path:
                    renpy.image((cid, expr), _form_sprite(cid, path, c["forms"]) if c.get("forms") else path)
        for b in ART["backgrounds"]:
            path = "images/bg/%s.png" % b["id"]
            if path in files:
                renpy.image(("bg", b["id"]), path)
        for cg in ART["cgs"]:
            path = "images/cg/%s.png" % cg["id"]
            if path in files:
                renpy.image(cg["id"], path)

    _define_images()

    def pick_line(pool, *keys):
        """从文本池里随机取一条。"""
        d = POOLS[pool]
        for k in keys:
            d = d[k]
        return renpy.random.choice(d)

    def chara(name, color, **kwargs):
        """角色：名字写在一段她代表色的和纸胶带上。"""
        tape = Color(color).interpolate(Color("#ffffff"), 0.42).hexcode
        return Character(
            name,
            namebox_background=Frame(Transform("gui/am/tape_white.png", matrixcolor=TintMatrix(tape)), 18, 18),
            who_color="#2e3345",
            ctc="ctc_check",
            ctc_position="nestled",
            **kwargs)

    def set_form(cid, form):
        """切换 ChatGPT / Claude 的形态（None = 不带形态的底图）。"""
        store.ai_form[cid] = form
        renpy.restart_interaction()

    def ai_label(cid):
        """说话人名字：「ChatGPT · Sol」。"""
        form = store.ai_form.get(cid)
        base = adata.HEROINES[cid]["name"]
        if form == "mythos":
            return base + " · Mythos"
        return ahelpers.label(form) if form in ahelpers.FORMS else base

    def week_flavor(action, target=None):
        lines = POOLS["week_flavor"][action]
        if action == "social":
            names = [h["name"] for h in adata.HEROINES.values()]
            if target:
                mine = [l for l in lines if adata.HEROINES[target]["name"] in l]
                if mine:
                    return renpy.random.choice(mine)
            generic = [l for l in lines if not any(n in l for n in names)]
            return renpy.random.choice(generic) if generic else None
        return renpy.random.choice(lines)

define narrator = Character(None, what_italic=False, ctc="ctc_check", ctc_position="nestled")

define p = chara("[gs.player_name]", "#7f8fd6")
define kiwi = chara("夏可薇", "#d0566f", image="kiwi")
define clair = chara("克莱尔", "#5aaed8", image="clair")
define neuri = chara("妮瑞", "#2bb5b0", image="neuri")
define imel = chara("伊梅尔", "#6a6fc0", image="imel")
define iris = chara("艾瑞丝", "#f08c4b", image="iris")
define aceline = chara("阿瑟琳", "#a985dc", image="aceline")
define closia = chara("克洛丝", "#6f6a7d", image="closia")
define natalie = chara("娜塔莉", "#c94f6d", image="natalie")
## 大模型：名字是表达式，跟着当前形态变（ai_label）
define chatgpt = chara("ai_label('chatgpt')", "#5fbf9a", image="chatgpt", dynamic=True)
define claude = chara("ai_label('claude')", "#c96a42", image="claude", dynamic=True)
default ai_form = {"chatgpt": "sol", "claude": "sonnet"}

define zhao = chara("赵一鸣", "#5bb07a", image="zhao")
define lu = chara("陆深", "#a08068", image="lu")
define adv = chara("[gs.advisor_short]", "#8c7fa8")
define rev2 = chara("Reviewer #2", "#c75561", image="rev2")
define delve = chara("戴尔夫", "#3aa6a6", image="delve")
define aisy = chara("艾茜", "#4fae9b", image="aisy")
define omnia = chara("欧米娅", "#e86fb0", image="omnia")
define winston = chara("温斯顿", "#7d7480", image="winston")
define odd = chara("奥德", "#6d6a85")
define unknown = chara("？？？", "#a898a6")

## 低 SAN 时的“主观滤镜”：画面发灰。
transform low_san_filter:
    matrixcolor SaturationMatrix(0.35) * BrightnessMatrix(-0.05)

## 立绘位置
transform left2:
    xalign 0.1 yalign 1.0
transform right2:
    xalign 0.9 yalign 1.0
