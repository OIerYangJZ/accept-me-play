################################################################################
## Initialization
################################################################################

init offset = -1


################################################################################
## Styles
################################################################################

style default:
    properties gui.text_properties()
    language gui.language

style input:
    properties gui.text_properties("input", accent=True)
    adjust_spacing False

style hyperlink_text:
    properties gui.text_properties("hyperlink", accent=True)
    hover_underline True

style gui_text:
    properties gui.text_properties("interface")


style button:
    properties gui.button_properties("button")

style button_text is gui_text:
    properties gui.text_properties("button")
    yalign 0.5


style label_text is gui_text:
    properties gui.text_properties("label", accent=True)

style prompt_text is gui_text:
    properties gui.text_properties("prompt")


style bar:
    ysize gui.bar_size
    left_bar Frame("gui/bar/left.png", gui.bar_borders, tile=gui.bar_tile)
    right_bar Frame("gui/bar/right.png", gui.bar_borders, tile=gui.bar_tile)

style vbar:
    xsize gui.bar_size
    top_bar Frame("gui/bar/top.png", gui.vbar_borders, tile=gui.bar_tile)
    bottom_bar Frame("gui/bar/bottom.png", gui.vbar_borders, tile=gui.bar_tile)

style scrollbar:
    ysize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/horizontal_[prefix_]bar.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/horizontal_[prefix_]thumb.png", gui.scrollbar_borders, tile=gui.scrollbar_tile)

style vscrollbar:
    xsize gui.scrollbar_size
    base_bar Frame("gui/scrollbar/vertical_[prefix_]bar.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)
    thumb Frame("gui/scrollbar/vertical_[prefix_]thumb.png", gui.vscrollbar_borders, tile=gui.scrollbar_tile)

style slider:
    ysize gui.slider_size
    base_bar Frame("gui/slider/horizontal_[prefix_]bar.png", gui.slider_borders, tile=gui.slider_tile)
    thumb "gui/slider/horizontal_[prefix_]thumb.png"

style vslider:
    xsize gui.slider_size
    base_bar Frame("gui/slider/vertical_[prefix_]bar.png", gui.vslider_borders, tile=gui.slider_tile)
    thumb "gui/slider/vertical_[prefix_]thumb.png"


style frame:
    padding gui.frame_borders.padding
    background Frame("gui/frame.png", gui.frame_borders, tile=gui.frame_tile)



################################################################################
## In-game screens
################################################################################


## Say screen ##################################################################
##
## The say screen is used to display dialogue to the player. It takes two
## parameters, who and what, which are the name of the speaking character and
## the text to be displayed, respectively. (The who parameter can be None
## if no name is given.)
##
## This screen must create a text displayable with id "what", as Ren'Py
## uses this to manage text display. It can also create displayables with
## id "who" and id "window" to apply style properties.
##
## https://www.renpy.org/doc/html/screen_special.html#say

screen say(who, what):

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "namebox"
                at tilt(-2.5)
                text who id "who"

        text what id "what"


    ## If there's a side image, display it above the text. Do not display
    ## on the phone variant - there's no room.
    if not renpy.variant("small"):
        add SideImage() xalign 0.0 yalign 1.0


## Make the namebox available for styling through the Character object.
init python:
    config.character_id_prefixes.append('namebox')

style window is default
style say_label is default
style say_dialogue is default
style say_thought is say_dialogue

style namebox is default
style namebox_label is say_label


style window:
    xalign 0.5
    xfill True
    yalign gui.textbox_yalign
    ysize gui.textbox_height

    background Image("gui/textbox.png", xalign=0.5, yalign=1.0)

## 名牌：默认是墨色药丸；每个角色在 characters.rpy 里用自己的颜色着色。
style namebox:
    xpos gui.name_xpos
    xanchor gui.name_xalign
    xsize gui.namebox_width
    ypos gui.name_ypos
    ysize gui.namebox_height

    background Frame("gui/namebox.png", 18, 18)
    padding (30, 6, 34, 8)

style say_label:
    properties gui.text_properties("name", accent=True)
    xalign gui.name_xalign
    yalign 0.5
    color C_INK

style say_dialogue:
    properties gui.text_properties("dialogue")

    xpos gui.dialogue_xpos
    xsize gui.dialogue_width
    ypos gui.dialogue_ypos
    ## 行距 = 横线间距（50px），字刚好写在线上
    line_spacing 13

    adjust_spacing False

## Input screen ################################################################
##
## This screen is used to display renpy.input. The prompt parameter is used
## to pass a text prompt in.
##
## This screen must create an input displayable with id "input" to accept
## the various input parameters.
##
## https://www.renpy.org/doc/html/screen_special.html#input

screen input(prompt):
    style_prefix "input"

    if autoplay:
        timer 0.02 action Return("")

    window:

        vbox:
            xanchor gui.dialogue_text_xalign
            xpos gui.dialogue_xpos
            xsize gui.dialogue_width
            ypos gui.dialogue_ypos

            text prompt style "input_prompt"
            input id "input"

style input_prompt is default

style input_prompt:
    xalign gui.dialogue_text_xalign
    properties gui.text_properties("input_prompt")

style input:
    xalign gui.dialogue_text_xalign
    xmaximum gui.dialogue_width


## Choice screen ###############################################################
##
## This screen is used to display the in-game choices presented by the
## menu statement. The one parameter, items, is a list of objects, each
## with caption and action fields.
##
## https://www.renpy.org/doc/html/screen_special.html#choice

init -1 python:
    def metrics_choice():
        """自动测试的统计插件（game/metrics.rpy）会覆盖它；正式版里什么都不做。"""
        pass

screen choice(items):
    style_prefix "choice"
    on "show" action Function(metrics_choice)

    if autoplay:
        timer 0.02 action renpy.random.choice(items).action

    vbox:
        for i, item in enumerate(items):
            button:
                action item.action
                background note(NOTE_CYCLE[i % len(NOTE_CYCLE)])
                at note_lift(tilt_for(i, 1.1)), drop_in(0.07 * i, tilt_for(i, 1.1))
                hbox:
                    spacing 18
                    fixed:
                        xysize (40, 40)
                        yalign 0.5
                        add "gui/am/box_empty.png"
                        add "gui/am/pen_check.png" at show_on_hover xoffset 2 yoffset -8
                    text item.caption style "choice_button_text"


style choice_vbox is vbox
style choice_button is button
style choice_button_text is button_text

style choice_vbox:
    xalign 0.5
    ypos 545  # 立绘的脸在画面上方（约 80–380），选项放在身体的位置，不挡脸
    yanchor 0.5
    spacing 2

style choice_button is default:
    xsize gui.choice_button_width
    xalign 0.5
    hover_foreground nine("am/pen_box.png")
    padding (marg("am/note_yellow.png") + 34, marg("am/note_yellow.png") + 26, marg("am/note_yellow.png") + 34, marg("am/note_yellow.png") + 20)

style choice_button_text is default:
    font F_HAND
    size 30
    color C_INK
    hover_color C_RED
    yalign 0.5
    xmaximum gui.choice_button_width - 180


## Quick Menu screen ###########################################################
##
## The quick menu is displayed in-game to provide easy access to the
## out-of-game menus.

screen quick_menu():

    ## Ensure this appears on top of other screens.
    zorder 100

    ## 养成界面（每周计划、审稿等）有自己的顶栏按钮，这里就不显示了
    $ dashboard = any(renpy.get_screen(n) for n in DASHBOARD_SCREENS) or renpy.get_screen("choice")

    if quick_menu and not dashboard:

        hbox:
            style_prefix "quick"
            style "quick_menu"

            textbutton _("回退") action Rollback()
            textbutton _("历史") action ShowMenu('history')
            textbutton _("快进") action Skip() alternate Skip(fast=True, confirm=True)
            textbutton _("自动") action Preference("auto-forward", "toggle")
            textbutton _("存档") action ShowMenu('save')
            textbutton _("快存") action QuickSave()
            textbutton _("快读") action QuickLoad()
            textbutton _("设置") action ShowMenu('preferences')


## This code ensures that the quick_menu screen is displayed in-game, whenever
## the player has not explicitly hidden the interface.
init python:
    config.overlay_screens.append("quick_menu")

define DASHBOARD_SCREENS = ("week_planner", "week_tick", "phone_chat", "rebuttal_duel", "review_board", "rebuttal_result", "decision_letter", "year_summary", "topic_select", "submit_select")

default quick_menu = True

style quick_menu is hbox
style quick_button is default
style quick_button_text is button_text

## 写在对话框那张纸的右下角
style quick_menu:
    xalign 1.0
    xoffset -150
    yalign 1.0
    yoffset -26
    spacing 22

style quick_button:
    padding (4, 2)

style quick_button_text:
    font F_HAND
    size 20
    color C_MUTED
    hover_color C_RED
    selected_color C_RED
    insensitive_color "#d6d2ca"


################################################################################
## Main and Game Menu Screens
################################################################################

## Navigation screen ###########################################################
##
## This screen is included in the main and game menus, and provides navigation
## to other menus, and to start the game.

screen navigation(compact=False):

    vbox:
        spacing (2 if compact else 6)

        $ nav = []
        if main_menu:
            $ nav.append((_("开始投稿"), Start()))
        else:
            $ nav.append((_("对话历史"), ShowMenu("history")))
            $ nav.append((_("保存进度"), ShowMenu("save")))
        $ nav.append((_("读取进度"), ShowMenu("load")))
        $ nav.append((_("设置"), ShowMenu("preferences")))
        if _in_replay:
            $ nav.append((_("结束回放"), EndReplay(confirm=True)))
        elif not main_menu:
            $ nav.append((_("返回标题"), MainMenu()))
        $ nav.append((_("关于"), ShowMenu("about")))
        $ nav.append((_("反馈"), ShowMenu("feedback")))
        if renpy.variant("pc") or (renpy.variant("web") and not renpy.variant("mobile")):
            $ nav.append((_("帮助"), ShowMenu("help")))
        if renpy.variant("pc"):
            $ nav.append((_("退出"), Quit(confirm=not main_menu)))

        for i, (label, act) in enumerate(nav):
            button:
                style "navigation_button"
                action act
                hbox:
                    spacing 16
                    fixed:
                        xysize (40, 40)
                        yalign 0.5
                        add "gui/am/box_empty.png"
                        add "gui/am/pen_check.png" at show_on_hover xoffset 2 yoffset -8
                    text label style "navigation_button_text"


style navigation_button is gui_button
style navigation_button_text is gui_button_text

style navigation_button:
    hover_background nine("am/highlight.png")
    selected_background nine("am/highlight.png")
    padding (10, 4, 26, 4)

style navigation_button_text:
    font F_HAND
    size 34
    color C_INK
    hover_color C_RED
    selected_color C_RED
    yalign 0.5


## Main Menu screen ############################################################
##
## Used to display the main menu when Ren'Py starts.
##
## https://www.renpy.org/doc/html/screen_special.html#main-menu

screen main_menu():

    ## This ensures that any other menu screen is replaced.
    tag menu

    ## 主视觉：art_src/title/标题主视觉.png 经 tools/import_art.py 生成。图里已经画了角色，不再叠立绘
    add "gui/title_kv.png" at fade_in(0.0, 0.6)

    ## 标题：一张贴在画面上的纸片
    fixed:
        at drop_in(0.0, -2.5)
        xpos 90 ypos 70 xysize (700, 360)
        frame:
            style "am_sheet"
            xpos -marg("am/sheet.png") ypos -marg("am/sheet.png")
            xsize 700 + 2 * marg("am/sheet.png") ysize 330 + 2 * marg("am/sheet.png")
            vbox:
                spacing 0
                text _("刊娘攻略手账") style "main_menu_title"
                hbox:
                    spacing 14
                    text "Accept Me!" style "am_note" size 64
                    text "♥" style "am_note" size 40 yalign 0.6
                add nine("am/pen_underline.png") xsize 330 ysize 26 yoffset -14
                text _("—— 写给顶会的一百封情书") style "am_small" size 24
        add "gui/am/tape_pink.png" at tilt(-8) xpos -40 ypos -18
        add "gui/am/tape_mint.png" at tilt(6) xpos 560 ypos -14
        add "gui/am/stamp_accept.png" at tilt(10) xpos 470 ypos 230 zoom 0.42 alpha 0.92

    ## 菜单：一张便利贴上的待办清单
    fixed:
        at drop_in(0.15, -1.5)
        xpos 120 ypos 520 xysize (460, 500)
        add note("yellow") xpos -marg("am/note_yellow.png") ypos -marg("am/note_yellow.png") xysize (460 + 2 * marg("am/note_yellow.png"), 500 + 2 * marg("am/note_yellow.png"))
        add "gui/am/tape_blue.png" at tilt(-3) xpos 130 ypos -26
        vbox:
            xpos 40 ypos 34
            text "To Do ✎" style "am_note" size 34
            null height 6
            use navigation

    text "v[config.version] · 所有角色均为虚构的拟人化形象":
        style "am_tiny"
        color "#ffffff"
        outlines [(2, "#00000040", 0, 0)]
        xalign 1.0 yalign 1.0 xoffset -30 yoffset -20


style main_menu_frame is empty
style main_menu_vbox is vbox
style main_menu_text is gui_text
style main_menu_title is main_menu_text
style main_menu_version is main_menu_text

style main_menu_title:
    font F_HAND
    size 88
    color C_INK

style main_menu_version:
    properties gui.text_properties("version")


## Game Menu screen ############################################################
##
## This lays out the basic common structure of a game menu screen. It's called
## with the screen title, and displays the background, title, and navigation.
##
## The scroll parameter can be None, or one of "viewport" or "vpgrid".
## This screen is intended to be used with one or more children, which are
## transcluded (placed) inside it.

screen game_menu(title, scroll=None, yinitial=0.0, spacing=0):

    style_prefix "game_menu"

    add gui.game_menu_background

    ## 左页：标题 + 目录
    vbox:
        xpos 150
        ypos 96
        text "menu" style "am_note" size 30
        text title style "game_menu_label_text"
        add nine("am/pen_underline.png") xsize 300 ysize 26 yoffset -10
        null height 30
        use navigation(compact=True)

    textbutton _("← 回去"):
        style "am_pen_button"
        xpos 150
        yalign 1.0
        yoffset -78
        action Return()

    ## 右页：内容
    frame:
        style "game_menu_content_frame"
        at fade_in(0.0, 0.2)

        if scroll == "viewport":

            viewport:
                yinitial yinitial
                scrollbars "vertical"
                mousewheel True
                draggable True
                pagekeys True

                side_yfill True

                vbox:
                    spacing spacing

                    transclude

        elif scroll == "vpgrid":

            vpgrid:
                cols 1
                yinitial yinitial

                scrollbars "vertical"
                mousewheel True
                draggable True
                pagekeys True

                side_yfill True

                spacing spacing

                transclude

        else:

            transclude

    if main_menu:
        key "game_menu" action ShowMenu("main_menu")


style game_menu_outer_frame is empty
style game_menu_navigation_frame is empty
style game_menu_content_frame is empty
style game_menu_viewport is gui_viewport
style game_menu_side is gui_side
style game_menu_scrollbar is gui_vscrollbar

style game_menu_label is gui_label
style game_menu_label_text is gui_label_text

style return_button is navigation_button
style return_button_text is navigation_button_text

style game_menu_content_frame:
    xpos 1070
    ypos 110
    xsize 760
    ysize 880

style game_menu_viewport:
    xfill True

style game_menu_vscrollbar:
    unscrollable gui.unscrollable

style game_menu_side:
    spacing 15

style game_menu_label_text:
    font F_HAND
    size 64
    color C_INK


## About screen ################################################################
##
## This screen gives credit and copyright information about the game and
## Ren'Py.
##
## There's nothing special about this screen, and hence it also serves as an
## example of how to make a custom screen.

screen about():

    tag menu

    ## This use statement includes the game_menu screen inside this one.
    ## The vbox child is then included inside the viewport inside the
    ## game_menu screen.
    use game_menu(_("关于"), scroll="viewport"):

        style_prefix "about"

        vbox:

            label "[config.name!t]"
            text _("Version [config.version!t]\n")

            ## gui.about is usually set in options.rpy.
            if gui.about:
                text "[gui.about!t]\n"

            text _("Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]")


## 反馈：玩家把问题和建议发到作者邮箱 ###########################################

define FEEDBACK_EMAIL = "theyjz001@gmail.com"

init python:
    import urllib.parse

    def feedback_mailto():
        where = "网页版" if renpy.variant("web") else "电脑版"
        if renpy.variant("mobile"):
            where += "（手机）"
        subject = "《Accept Me!》反馈 %s" % config.version
        body = "版本：%s %s\n\n遇到了什么 / 想说什么：\n\n\n（报错的话，能附一张截图最好）\n" % (config.version, where)
        return "mailto:%s?subject=%s&body=%s" % (FEEDBACK_EMAIL, urllib.parse.quote(subject), urllib.parse.quote(body))

    def open_feedback_mail():
        url = feedback_mailto()
        if renpy.emscripten:
            # 网页版里 OpenURL 会开一个空白新标签页，直接跳转 mailto 更稳
            import emscripten
            emscripten.run_script("window.location.href = %r;" % url)
        else:
            renpy.run(OpenURL(url))

screen feedback():
    tag menu
    use game_menu(_("反馈"), scroll="viewport"):
        style_prefix "about"
        vbox:
            spacing 24
            text _("玩的时候遇到 bug、看不懂的地方，或者有想吐槽的剧情，都欢迎发邮件给作者。")
            text _("报错的话，写一下是第几周、在做什么，能附截图最好。")
            text "[FEEDBACK_EMAIL]" size 40 color C_INK
            textbutton _("写邮件给作者"):
                action Function(open_feedback_mail)
                padding (26, 12)
                background nine("am/pen_box.png")
                text_size 32
                text_color C_RED
                text_hover_color C_INK
            text _("（点了没反应的话，复制上面的邮箱，用自己的邮箱发就行。）") size 24

style about_label is gui_label
style about_label_text is gui_label_text
style about_text is gui_text

style about_label_text:
    size gui.label_text_size


## Load and Save screens #######################################################
##
## These screens are responsible for letting the player save the game and
## load it again. Since they share nearly everything in common, both
## are implemented in terms of a third screen, file_slots.
##
## https://www.renpy.org/doc/html/screen_special.html#save
## https://www.renpy.org/doc/html/screen_special.html#load

screen save():

    tag menu

    use file_slots(_("保存进度"))


screen load():

    tag menu

    use file_slots(_("读取进度"))


screen file_slots(title):

    default page_name_value = FilePageNameInputValue(pattern=_("Page {}"), auto=_("Automatic saves"), quick=_("Quick saves"))

    use game_menu(title):

        fixed:

            ## This ensures the input will get the enter
            ## event before any of the buttons do.
            order_reverse True

            ## The page name, which can be edited by clicking on a button.
            button:
                style "page_label"

                key_events True
                xalign 0.5
                action page_name_value.Toggle()

                input:
                    style "page_label_text"
                    value page_name_value

            ## 存档格：一张张贴在本子上的拍立得
            grid gui.file_slot_cols gui.file_slot_rows:
                style_prefix "slot"

                xalign 0.5
                yalign 0.45

                xspacing 30
                yspacing 44

                for i in range(gui.file_slot_cols * gui.file_slot_rows):

                    $ slot = i + 1
                    $ pm = marg("am/polaroid_wide.png")

                    button:
                        action FileAction(slot)
                        xysize (230, 205)
                        padding (0, 0)
                        hover_foreground nine("am/pen_box.png")
                        at note_lift(tilt_for(i, 2.2))

                        fixed:
                            add "gui/am/polaroid_wide.png" xpos -pm ypos -pm
                            add FileScreenshot(slot, empty=Solid("#e2ded6", xysize=(206, 116))) xpos 12 ypos 12
                            text FileTime(slot, format=_("{#file_time}%m月%d日 %H:%M"), empty=_("（空）")):
                                style "slot_time_text"
                                xpos 14 ypos 136
                            text FileSaveName(slot):
                                style "slot_name_text"
                                xpos 14 ypos 166
                            add "gui/am/tape_%s.png" % ("pink", "mint", "yellow", "blue", "lavender", "pink")[i % 6]:
                                at tilt(tilt_for(i + 3, 6.0))
                                xpos 55 ypos -24 zoom 0.6

                        key "save_delete" action FileDelete(slot)

            ## Buttons to access other pages.
            vbox:
                style_prefix "page"

                xalign 0.5
                yalign 1.0

                hbox:
                    xalign 0.5

                    spacing gui.page_spacing

                    style_prefix "page"
                    textbutton _("<") action FilePagePrevious()
                    key "save_page_prev" action FilePagePrevious()

                    if config.has_autosave:
                        textbutton _("{#auto_page}A") action FilePage("auto")

                    if config.has_quicksave:
                        textbutton _("{#quick_page}Q") action FilePage("quick")

                    ## range(1, 10) gives the numbers from 1 to 9.
                    for page in range(1, 10):
                        textbutton "[page]" action FilePage(page)

                    textbutton _(">") action FilePageNext()
                    key "save_page_next" action FilePageNext()

                if config.has_sync:
                    if CurrentScreenName() == "save":
                        textbutton _("上传同步"):
                            action UploadSync()
                            xalign 0.5
                    else:
                        textbutton _("下载同步"):
                            action DownloadSync()
                            xalign 0.5


style page_label is gui_label
style page_label_text is gui_label_text
style page_button is gui_button
style page_button_text is gui_button_text
style slot_button is gui_button
style slot_button_text is gui_button_text
style slot_time_text is slot_button_text
style slot_name_text is slot_button_text

style page_label:
    xpadding 50
    ypadding 3

style page_label_text:
    font F_HAND
    size 34
    color C_INK
    textalign 0.5
    layout "subtitle"
    hover_color C_RED

style page_button:
    padding (12, 2)
    hover_background nine("am/highlight.png")
    selected_background nine("am/highlight_pink.png")

style page_button_text:
    font F_EN
    size 30
    color C_INK_SOFT
    hover_color C_RED
    selected_color C_RED

style slot_button:
    background None

style slot_button_text:
    font F_BODY
    size 18
    color C_INK_SOFT

style slot_time_text:
    font F_HAND
    size 19
    color C_INK

style slot_name_text:
    font F_BODY
    size 17
    color C_MUTED


## ## Preferences screen ##########################################################
##
## The preferences screen allows the player to configure the game to better
## suit themselves.
##
## https://www.renpy.org/doc/html/screen_special.html#preferences

screen preferences():

    tag menu

    use game_menu(_("设置"), scroll="viewport"):

        vbox:

            hbox:
                box_wrap True

                if renpy.variant("pc") or renpy.variant("web"):

                    vbox:
                        style_prefix "radio"
                        label _("Display")
                        textbutton _("Window") action Preference("display", "window")
                        textbutton _("Fullscreen") action Preference("display", "fullscreen")

                vbox:
                    style_prefix "check"
                    label _("Skip")
                    textbutton _("Unseen Text") action Preference("skip", "toggle")
                    textbutton _("After Choices") action Preference("after choices", "toggle")
                    textbutton _("Transitions") action InvertSelected(Preference("transitions", "toggle"))

                ## Additional vboxes of type "radio_pref" or "check_pref" can be added here, to
                ## add additional creator-defined preferences.

            null height (4 * gui.pref_spacing)

            vbox:
                style_prefix "slider"

                label _("Text Speed")
                bar value Preference("text speed")

                label _("Auto-Forward Time")
                bar value Preference("auto-forward time")

                if config.has_music:
                    label _("Music Volume")
                    bar value Preference("music volume")

                if config.has_sound:
                    label _("Sound Volume")
                    hbox:
                        bar value Preference("sound volume")
                        if config.sample_sound:
                            textbutton _("Test") action Play("sound", config.sample_sound)

                if config.has_voice:
                    label _("Voice Volume")
                    hbox:
                        bar value Preference("voice volume")
                        if config.sample_voice:
                            textbutton _("Test") action Play("voice", config.sample_voice)

                if config.has_music or config.has_sound or config.has_voice:
                    null height gui.pref_spacing
                    textbutton _("Mute All"):
                        action Preference("all mute", "toggle")
                        style "mute_all_button"


style pref_label is gui_label
style pref_label_text is gui_label_text
style pref_vbox is vbox

style radio_label is pref_label
style radio_label_text is pref_label_text
style radio_button is gui_button
style radio_button_text is gui_button_text
style radio_vbox is pref_vbox

style check_label is pref_label
style check_label_text is pref_label_text
style check_button is gui_button
style check_button_text is gui_button_text
style check_vbox is pref_vbox

style slider_label is pref_label
style slider_label_text is pref_label_text
style slider_slider is gui_slider
style slider_button is gui_button
style slider_button_text is gui_button_text
style slider_pref_vbox is pref_vbox

style mute_all_button is check_button
style mute_all_button_text is check_button_text

style pref_label:
    top_margin gui.pref_spacing
    bottom_margin 3

style pref_label_text:
    font F_HAND
    size 30
    color C_RED
    yalign 1.0

style pref_vbox:
    xsize 300

style radio_vbox:
    spacing gui.pref_button_spacing

style radio_button:
    properties gui.button_properties("radio_button")
    foreground "gui/button/radio_[prefix_]foreground.png"

style radio_button_text:
    properties gui.text_properties("radio_button")
    font F_BODY
    size 26
    hover_color C_RED
    selected_color C_INK

style check_vbox:
    spacing gui.pref_button_spacing

style check_button:
    properties gui.button_properties("check_button")
    foreground "gui/button/check_[prefix_]foreground.png"

style check_button_text:
    properties gui.text_properties("check_button")
    font F_BODY
    size 26
    hover_color C_RED
    selected_color C_INK

style slider_slider:
    xsize 600

style slider_button:
    properties gui.button_properties("slider_button")
    yalign 0.5
    left_margin 15

style slider_button_text:
    properties gui.text_properties("slider_button")

style slider_vbox:
    xsize 700


## History screen ##############################################################
##
## This is a screen that displays the dialogue history to the player.
## While there isn't anything special about this screen, it does have to
## access the dialogue history stored in _history_list.
##
## https://www.renpy.org/doc/html/history.html

screen history():

    tag menu

    ## Avoid predicting this screen, as it can be very large.
    predict False

    use game_menu(_("对话历史"), scroll=("vpgrid" if gui.history_height else "viewport"), yinitial=1.0, spacing=gui.history_spacing):

        style_prefix "history"

        for h in _history_list:

            window:

                ## This lays things out properly if history_height is None.
                has fixed:
                    yfit True

                if h.who:

                    label h.who:
                        style "history_name"
                        substitute False

                        ## Take the color of the who text from the Character, if set.
                        if "color" in h.who_args:
                            text_color h.who_args["color"]

                $ what = renpy.filter_text_tags(h.what, allow=gui.history_allow_tags)
                text what:
                    substitute False

        if not _history_list:
            label _("The dialogue history is empty.")


## This determines what tags are allowed to be displayed on the history
## screen.

define gui.history_allow_tags = { "alt", "noalt", "rt", "rb", "art" }


style history_window is empty

style history_name is gui_label
style history_name_text is gui_label_text
style history_text is gui_text

style history_label is gui_label
style history_label_text is gui_label_text

style history_window:
    xfill True
    ysize gui.history_height

style history_name:
    xpos gui.history_name_xpos
    xanchor gui.history_name_xalign
    ypos gui.history_name_ypos
    xsize gui.history_name_width

style history_name_text:
    min_width gui.history_name_width
    textalign gui.history_name_xalign

style history_text:
    xpos gui.history_text_xpos
    ypos gui.history_text_ypos
    xanchor gui.history_text_xalign
    xsize gui.history_text_width
    min_width gui.history_text_width
    textalign gui.history_text_xalign
    layout ("subtitle" if gui.history_text_xalign else "tex")

style history_label:
    xfill True

style history_label_text:
    xalign 0.5


## Help screen #################################################################
##
## A screen that gives information about key and mouse bindings. It uses
## other screens (keyboard_help, mouse_help, and gamepad_help) to display the
## actual help.

screen help():

    tag menu

    default device = "keyboard"

    use game_menu(_("帮助"), scroll="viewport"):

        style_prefix "help"

        vbox:
            spacing 23

            hbox:

                textbutton _("Keyboard") action SetScreenVariable("device", "keyboard")
                textbutton _("Mouse") action SetScreenVariable("device", "mouse")

                if GamepadExists():
                    textbutton _("Gamepad") action SetScreenVariable("device", "gamepad")

            if device == "keyboard":
                use keyboard_help
            elif device == "mouse":
                use mouse_help
            elif device == "gamepad":
                use gamepad_help


screen keyboard_help():

    hbox:
        label _("Enter")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Space")
        text _("Advances dialogue without selecting choices.")

    hbox:
        label _("Arrow Keys")
        text _("Navigate the interface.")

    hbox:
        label _("Escape")
        text _("Accesses the game menu.")

    hbox:
        label _("Ctrl")
        text _("Skips dialogue while held down.")

    hbox:
        label _("Tab")
        text _("Toggles dialogue skipping.")

    hbox:
        label _("Page Up")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Page Down")
        text _("Rolls forward to later dialogue.")

    hbox:
        label "H"
        text _("Hides the user interface.")

    hbox:
        label "S"
        text _("Takes a screenshot.")

    hbox:
        label "V"
        text _("Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}.")

    hbox:
        label "Shift+A"
        text _("Opens the accessibility menu.")


screen mouse_help():

    hbox:
        label _("Left Click")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Middle Click")
        text _("Hides the user interface.")

    hbox:
        label _("Right Click")
        text _("Accesses the game menu.")

    hbox:
        label _("Mouse Wheel Up")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Mouse Wheel Down")
        text _("Rolls forward to later dialogue.")


screen gamepad_help():

    hbox:
        label _("Right Trigger\nA/Bottom Button")
        text _("Advances dialogue and activates the interface.")

    hbox:
        label _("Left Trigger\nLeft Shoulder")
        text _("Rolls back to earlier dialogue.")

    hbox:
        label _("Right Shoulder")
        text _("Rolls forward to later dialogue.")

    hbox:
        label _("D-Pad, Sticks")
        text _("Navigate the interface.")

    hbox:
        label _("Start, Guide, B/Right Button")
        text _("Accesses the game menu.")

    hbox:
        label _("Y/Top Button")
        text _("Hides the user interface.")

    textbutton _("Calibrate") action GamepadCalibrate()


style help_button is gui_button
style help_button_text is gui_button_text
style help_label is gui_label
style help_label_text is gui_label_text
style help_text is gui_text

style help_button:
    properties gui.button_properties("help_button")
    xmargin 12

style help_button_text:
    properties gui.text_properties("help_button")

style help_label:
    xsize 375
    right_padding 30

style help_label_text:
    size gui.text_size
    xalign 1.0
    textalign 1.0



################################################################################
## Additional screens
################################################################################


## Confirm screen ##############################################################
##
## The confirm screen is called when Ren'Py wants to ask the player a yes or
## no question.
##
## https://www.renpy.org/doc/html/screen_special.html#confirm

screen confirm(message, yes_action, no_action):

    ## Ensure other screens do not get input while this screen is displayed.
    modal True

    zorder 200

    style_prefix "confirm"

    add "gui/overlay/confirm.png"

    frame:

        vbox:
            xalign .5
            yalign .5
            spacing 44

            text "wait a sec..." style "am_note" xalign 0.5
            label _(message):
                style "confirm_prompt"
                xalign 0.5

            hbox:
                xalign 0.5
                spacing 24

                textbutton _("确定") action yes_action style "am_tape_button" xminimum 200
                textbutton _("再想想") action no_action style "am_pen_button" xminimum 160

    ## Right-click and escape answer "no".
    key "game_menu" action no_action


style confirm_frame is gui_frame
style confirm_prompt is gui_prompt
style confirm_prompt_text is gui_prompt_text
style confirm_button is gui_medium_button
style confirm_button_text is gui_medium_button_text

style confirm_frame:
    background nine("confirm_frame.png")
    padding (marg("confirm_frame.png") + 80, marg("confirm_frame.png") + 70, marg("confirm_frame.png") + 80, marg("confirm_frame.png") + 50)
    xalign .5
    yalign .5
    xminimum 900

style confirm_prompt_text:
    font F_HAND
    size 34
    color C_INK
    textalign 0.5
    layout "subtitle"


## Skip indicator screen #######################################################
##
## The skip_indicator screen is displayed to indicate that skipping is in
## progress.
##
## https://www.renpy.org/doc/html/screen_special.html#skip-indicator

screen skip_indicator():

    zorder 100
    style_prefix "skip"

    frame:

        hbox:
            spacing 9

            text _("Skipping")

            text "▸" at delayed_blink(0.0, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.2, 1.0) style "skip_triangle"
            text "▸" at delayed_blink(0.4, 1.0) style "skip_triangle"


## This transform is used to blink the arrows one after another.
transform delayed_blink(delay, cycle):
    alpha .5

    pause delay

    block:
        linear .2 alpha 1.0
        pause .2
        linear .2 alpha 0.5
        pause (cycle - .4)
        repeat


style skip_frame is empty
style skip_text is gui_text
style skip_triangle is skip_text

style skip_frame:
    xpos 16
    yalign 1.0
    yoffset 4
    background nine("skip.png")
    padding (marg("skip.png") + 24, marg("skip.png") + 12, marg("skip.png") + 24, marg("skip.png") + 8)

style skip_text:
    font F_HAND
    size 22
    color C_INK

style skip_triangle:
    ## We have to use a font that has the BLACK RIGHT-POINTING SMALL TRIANGLE
    ## glyph in it.
    font "DejaVuSans.ttf"
    color C_RED


## Notify screen ###############################################################
##
## The notify screen is used to show the player a message. (For example,
## when the game is quicksaved or a screenshot has been taken.)
##
## https://www.renpy.org/doc/html/screen_special.html#notify-screen

screen notify(message):

    zorder 100
    style_prefix "notify"

    frame at notify_appear:
        text "[message!tq]"

    timer 3.25 action Hide('notify')


transform notify_appear:
    on show:
        alpha 0
        linear .25 alpha 1.0
    on hide:
        linear .5 alpha 0.0


style notify_frame is empty
style notify_text is gui_text

style notify_frame:
    xalign 1.0
    xoffset -36
    ypos 124
    background nine("notify.png")
    padding (marg("notify.png") + 26, marg("notify.png") + 14, marg("notify.png") + 26, marg("notify.png") + 8)

style notify_text:
    font F_HAND
    size 23
    color C_INK


## NVL screen ##################################################################
##
## This screen is used for NVL-mode dialogue and menus.
##
## https://www.renpy.org/doc/html/screen_special.html#nvl


screen nvl(dialogue, items=None):

    window:
        style "nvl_window"

        has vbox:
            spacing gui.nvl_spacing

        ## Displays dialogue in either a vpgrid or the vbox.
        if gui.nvl_height:

            vpgrid:
                cols 1
                yinitial 1.0

                use nvl_dialogue(dialogue)

        else:

            use nvl_dialogue(dialogue)

        ## Displays the menu, if given. The menu may be displayed incorrectly
        ## if config.narrator_menu is set to True.
        for i in items:

            textbutton i.caption:
                action i.action
                style "nvl_button"

    add SideImage() xalign 0.0 yalign 1.0


screen nvl_dialogue(dialogue):

    for d in dialogue:

        window:
            id d.window_id

            fixed:
                yfit gui.nvl_height is None

                if d.who is not None:

                    text d.who:
                        id d.who_id

                text d.what:
                    id d.what_id


## This controls the maximum number of NVL-mode entries that can be displayed
## at once.
define config.nvl_list_length = gui.nvl_list_length

style nvl_window is default
style nvl_entry is default

style nvl_label is say_label
style nvl_dialogue is say_dialogue

style nvl_button is button
style nvl_button_text is button_text

style nvl_window:
    xfill True
    yfill True

    background "gui/nvl.png"
    padding gui.nvl_borders.padding

style nvl_entry:
    xfill True
    ysize gui.nvl_height

style nvl_label:
    xpos gui.nvl_name_xpos
    xanchor gui.nvl_name_xalign
    ypos gui.nvl_name_ypos
    yanchor 0.0
    xsize gui.nvl_name_width
    min_width gui.nvl_name_width
    textalign gui.nvl_name_xalign

style nvl_dialogue:
    xpos gui.nvl_text_xpos
    xanchor gui.nvl_text_xalign
    ypos gui.nvl_text_ypos
    xsize gui.nvl_text_width
    min_width gui.nvl_text_width
    textalign gui.nvl_text_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_thought:
    xpos gui.nvl_thought_xpos
    xanchor gui.nvl_thought_xalign
    ypos gui.nvl_thought_ypos
    xsize gui.nvl_thought_width
    min_width gui.nvl_thought_width
    textalign gui.nvl_thought_xalign
    layout ("subtitle" if gui.nvl_text_xalign else "tex")

style nvl_button:
    properties gui.button_properties("nvl_button")
    xpos gui.nvl_button_xpos
    xanchor gui.nvl_button_xalign

style nvl_button_text:
    properties gui.text_properties("nvl_button")


## Bubble screen ###############################################################
##
## The bubble screen is used to display dialogue to the player when using
## speech bubbles. The bubble screen takes the same parameters as the say
## screen, must create a displayable with the id of "what", and can create
## displayables with the "namebox", "who", and "window" ids.
##
## https://www.renpy.org/doc/html/bubble.html#bubble-screen

screen bubble(who, what):
    style_prefix "bubble"

    window:
        id "window"

        if who is not None:

            window:
                id "namebox"
                style "bubble_namebox"

                text who:
                    id "who"

        text what:
            id "what"

        default ctc = None
        showif ctc:
            add ctc

style bubble_window is empty
style bubble_namebox is empty
style bubble_who is default
style bubble_what is default

style bubble_window:
    xpadding 30
    top_padding 5
    bottom_padding 5

style bubble_namebox:
    xalign 0.5

style bubble_who:
    xalign 0.5
    textalign 0.5
    color "#000"

style bubble_what:
    align (0.5, 0.5)
    text_align 0.5
    layout "subtitle"
    color "#000"

define bubble.frame = Frame("gui/bubble.png", 55, 55, 55, 95)
define bubble.thoughtframe = Frame("gui/thoughtbubble.png", 55, 55, 55, 55)

define bubble.properties = {
    "bottom_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "bottom_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=1),
        "window_bottom_padding" : 27,
    },

    "top_left" : {
        "window_background" : Transform(bubble.frame, xzoom=1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "top_right" : {
        "window_background" : Transform(bubble.frame, xzoom=-1, yzoom=-1),
        "window_top_padding" : 27,
    },

    "thought" : {
        "window_background" : bubble.thoughtframe,
    }
}

define bubble.expand_area = {
    "bottom_left" : (0, 0, 0, 22),
    "bottom_right" : (0, 0, 0, 22),
    "top_left" : (0, 22, 0, 0),
    "top_right" : (0, 22, 0, 0),
    "thought" : (0, 0, 0, 0),
}



################################################################################
## 手机 / 平板
################################################################################

## 不再使用 Ren'Py 模板自带的手机版覆盖（gui/phone/ 下的英文快捷栏、灰色对话框和滑条）：
## 手机和电脑用同一套手账风界面，画面整体按比例缩放。
## 模板的触屏快捷栏在每周计划、投稿等养成界面上不会隐藏，玩家在投稿界面点 Back / Skip
## 会打乱 Ren'Py 的回退重放，曾导致投稿时崩溃（_return 不是论文编号）。
