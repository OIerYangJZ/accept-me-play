## 手机聊天界面：对方的消息逐条自动出现（不用按空格，点一下可以加速），玩家用选项回复。
## 素材由 tools/make_chat_ui.py 生成。剧本里这样用：
##
##     $ chat_open("夏可薇")
##     $ chat_say("kiwi", "今晚好安静")
##     $ t = chat_reply([("念给她听", "那今晚换我给你念"), ("早点睡", "早点睡吧")])
##     $ chat_close()

init python:
    CHAT_X, CHAT_Y = 620, 10  # 手机外框图（680×1060，四周留白 30）的位置
    CHAT_SCREEN = (52, 52, 576, 956)  # 屏幕区域：相对外框图的 x, y, 宽, 高

    def chat_open(title):
        store.chat_title = title
        store.chat_log = []

    def chat_say(who, text):
        """对方发来一条消息。who 是角色 id（显示她的名字），也可以直接写名字。"""
        name = adata.HEROINES[who]["name"] if who in adata.HEROINES else who
        store.chat_log.append(("left", name, text))
        renpy.call_screen("phone_chat", title=store.chat_title, log=list(store.chat_log),
                          auto=0.9 + 0.035 * len(text))

    def chat_reply(options):
        """玩家回复：options 是 [(按钮上的字, 发出去的消息)]，返回选中的下标。"""
        i = renpy.call_screen("phone_chat", title=store.chat_title, log=list(store.chat_log),
                              choices=[o[0] for o in options])
        if not isinstance(i, int) or not 0 <= i < len(options):
            i = 0  # 回退重放时可能拿到别的界面的返回值
        store.chat_log.append(("right", None, options[i][1]))
        renpy.call_screen("phone_chat", title=store.chat_title, log=list(store.chat_log), auto=0.7)
        if getattr(store, "autoplay", False):
            ap_trace("  chat reply %d" % i)
        return i

    def chat_close():
        store.chat_log = []


default chat_title = ""
default chat_log = []


screen phone_chat(title, log, choices=None, auto=None):
    modal True
    if ap_go("phone_chat"):
        timer 0.02 action Return(0 if choices else True)
    elif auto:
        timer auto action Return(True)
        key "dismiss" action Return(True)
        button:
            xfill True yfill True
            background None
            action Return(True)

    add Solid("#1e1a2488")
    $ sx, sy, sw, sh = CHAT_SCREEN
    fixed:
        xpos CHAT_X ypos CHAT_Y xysize (680, 1060)
        at fade_in(0.0, 0.2)
        add Solid("#f4f0e8", xysize=(sw, sh)) xpos sx ypos sy

        # 顶栏：联系人
        fixed:
            xpos sx ypos sy + 34 xysize (sw, 70)
            text title style "am_h3" size 30 xalign 0.5 yalign 0.5
        add Solid("#ddd6cc", xysize=(sw, 2)) xpos sx ypos sy + 104

        # 消息
        viewport:
            xpos sx + 18 ypos sy + 118
            xysize (sw - 36, (sh - 118 - 230) if choices else (sh - 140))
            yinitial 1.0
            mousewheel True
            vbox:
                xsize sw - 36
                spacing 14
                null height 6
                for side, name, msg in log:
                    vbox:
                        xalign (0.0 if side == "left" else 1.0)
                        spacing 2
                        if side == "left" and name:
                            text name style "am_tiny" size 18 color C_MUTED
                        frame:
                            background Frame("gui/am/bubble_%s.png" % side, 26, 26)
                            padding (22, 14)
                            xmaximum 420
                            text msg style "am_body" size 25 color C_INK substitute False
                null height 6

        # 回复选项
        if choices:
            add Solid("#e8e2d8", xysize=(sw, 230)) xpos sx ypos sy + sh - 230
            vbox:
                xpos sx + 24 ypos sy + sh - 214
                xsize sw - 48
                spacing 10
                for i, c in enumerate(choices):
                    button:
                        xfill True
                        padding (20, 12)
                        background Frame("gui/am/bubble_right.png", 26, 26)
                        hover_foreground nine("am/pen_box.png")
                        action Return(i)
                        text c style "am_body" size 24 color C_INK
        add "gui/am/phone_frame.png"
