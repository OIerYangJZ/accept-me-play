## 界面主题 ——“研究手账”。
## 一个研究生的手账本：横线纸、便利贴、和纸胶带、拍立得、回形针，和审稿人的红笔。
## 界面图由 tools/make_ui.py 生成，颜色与这里保持一致。

## 比 screens.rpy（-1）更早执行，这样那里的样式也能用这里的颜色和字体。
init offset = -2

init -5 python:
    import json as _json

    with renpy.open_file("gui/am/metrics.json") as _f:
        UI_METRICS = _json.loads(_f.read().decode("utf-8"))

    def nine(path):
        """九宫格：边框尺寸来自 metrics.json（包含投影边距）。横线纸平铺而不是拉伸，否则横线会变粗。"""
        m = UI_METRICS[path]
        return Frame("gui/" + path, m["border"], m["border"], tile=m.get("tile", False))

    def marg(path):
        return UI_METRICS[path]["margin"]

    def tinted(path, color, alpha=1.0):
        return Transform(path, matrixcolor=TintMatrix(color) * OpacityMatrix(alpha))

    def lighten(color, t=0.5):
        c = Color(color)
        return c.interpolate(Color("#ffffff"), t).hexcode

    def tape_frame(color, alpha=1.0):
        return Frame(tinted("gui/am/tape_white.png", color, alpha), 18, 18)

    def note(color):
        return nine("am/note_%s.png" % color)

    def san_color(v):
        return C_GREEN if v >= 60 else (C_GOLD if v >= 30 else C_RED)

    def score_color(score10):
        return C_GREEN if score10 >= 6.0 else (C_GOLD if score10 >= 4.5 else C_RED)

    def heart_count(affinity, n=5):
        return int(round(affinity * n / 100.0))

    def tilt_for(i, amount=1.4):
        """给第 i 个元素一个固定的、看起来随手的倾斜角。"""
        pattern = (-1.0, 0.7, -0.4, 1.0, -0.8, 0.5, -0.2, 0.9)
        return pattern[i % len(pattern)] * amount

    NOTE_CYCLE = ("yellow", "pink", "mint", "blue", "lavender", "peach")

## ---- 调色板 -------------------------------------------------------------------
define C_INK = "#2e3345"          # 圆珠笔墨
define C_INK_SOFT = "#62687a"
define C_MUTED = "#969aa6"
define C_PAPER = "#fcf9f2"
define C_LINE = "#d8d2c4"
define C_RED = "#d9443f"          # 审稿人的红笔
define C_GREEN = "#3d8b5f"
define C_GOLD = "#c08a2a"
define C_BLUE = "#4f7fb8"
define C_ROSE = "#e0708a"
define C_ACCENT = C_RED

## ---- 字体 ---------------------------------------------------------------------
## 霞鹜文楷（手写感楷体，SIL OFL）+ Patrick Hand（英文手写，SIL OFL）
define F_HAND = "fonts/LXGWWenKai-Medium.ttf"
define F_BODY = "fonts/LXGWWenKai-Regular.ttf"
define F_EN = "fonts/PatrickHand-Regular.ttf"

## 各会议的标识色
define VENUE_COLORS = {
    "iclr": "#4f8fc8", "neurips": "#2a9d8f", "icml": "#5b5fb0", "cvpr": "#e07b39",
    "iccv": "#7a7a96", "acl": "#9b6fd1", "nature": "#b34766",
}
## 刊娘的代表色（名牌胶带、拍立得边角）
define HEROINE_COLORS = {
    "kiwi": "#d0566f", "clair": "#4fa3d1", "neuri": "#2bb5b0", "imel": "#6a6fc0",
    "iris": "#f08c4b", "aceline": "#a985dc", "closia": "#6f6a7d", "natalie": "#c94f6d",
    "chatgpt": "#5fbf9a", "claude": "#c96a42",
}

## ---- 动效 ---------------------------------------------------------------------
transform tilt(deg=0.0):
    rotate deg
    rotate_pad False
    transform_anchor True

## 便利贴：悬停时被拿起来一点
transform note_lift(deg=0.0):
    rotate deg
    rotate_pad False
    transform_anchor True
    on idle:
        ease 0.14 yoffset 0 rotate deg
    on hover:
        ease 0.14 yoffset -6 rotate deg * 0.4
    on selected_idle:
        ease 0.14 yoffset 0 rotate deg
    on selected_hover:
        ease 0.14 yoffset -6 rotate deg * 0.4

## 红笔勾 / 荧光笔：悬停时出现
transform show_on_hover:
    on idle:
        ease 0.12 alpha 0.0
    on hover:
        ease 0.12 alpha 1.0
    on selected_idle:
        alpha 1.0
    on selected_hover:
        alpha 1.0

transform fade_in(delay=0.0, t=0.5):
    alpha 0.0
    pause delay
    ease t alpha 1.0

transform drop_in(delay=0.0, deg=0.0):
    alpha 0.0 yoffset -30 rotate deg
    rotate_pad False
    transform_anchor True
    pause delay
    easein 0.32 alpha 1.0 yoffset 0

transform breathe(delay=0.0):
    yoffset 0
    pause delay
    block:
        ease 2.8 yoffset -6
        ease 2.8 yoffset 0
        repeat

## 对话结束时：红笔打一个勾，然后轻轻跳
image ctc_check:
    "gui/am/ctc_check.png"
    zoom 0.85
    alpha 0.0 yoffset 6
    easein 0.18 alpha 1.0 yoffset 0
    block:
        ease 0.5 yoffset -3
        ease 0.5 yoffset 2
        repeat

## ---- 文字样式 -----------------------------------------------------------------
style default:
    prefer_emoji False

style am_h1 is text:
    font F_HAND
    size 52
    color C_INK

style am_h2 is text:
    font F_HAND
    size 34
    color C_INK

style am_h3 is text:
    font F_HAND
    size 27
    color C_INK

style am_body is text:
    font F_BODY
    size 25
    color C_INK
    line_spacing 8

style am_small is text:
    font F_BODY
    size 21
    color C_INK_SOFT
    line_spacing 4

style am_tiny is text:
    font F_BODY
    size 18
    color C_MUTED

## 红笔写的英文批注（代替那种字距拉开的英文小标题）
style am_note is text:
    font F_EN
    size 28
    color C_RED

style am_num is text:
    font F_EN
    size 30
    color C_INK

## ---- 容器 ---------------------------------------------------------------------
## 打印纸（审稿意见、论文首页、录用信）
style am_sheet is frame:
    background nine("am/sheet.png")
    padding (marg("am/sheet.png") + 36, marg("am/sheet.png") + 30)

## 横线索引卡（弹窗）
style am_card is frame:
    background nine("am/index_card.png")
    padding (marg("am/index_card.png") + 44, marg("am/index_card.png") + 64, marg("am/index_card.png") + 44, marg("am/index_card.png") + 36)

## ---- 按钮 ---------------------------------------------------------------------
## 便利贴按钮：悬停时出现红笔圈
style am_note_button is button:
    hover_foreground nine("am/pen_box.png")
    selected_foreground nine("am/pen_box.png")
    padding (marg("am/note_yellow.png") + 28, marg("am/note_yellow.png") + 26, marg("am/note_yellow.png") + 28, marg("am/note_yellow.png") + 22)

style am_note_title is text:
    font F_HAND
    size 30
    color C_INK
    insensitive_color "#b4b2ad"

style am_note_desc is text:
    font F_BODY
    size 21
    color C_INK_SOFT
    insensitive_color "#bcbab4"
    line_spacing 3

## 纯文字按钮：悬停时荧光笔划过 + 文字变红
style am_pen_button is button:
    hover_background nine("am/highlight.png")
    selected_background nine("am/highlight.png")
    padding (14, 6)

style am_pen_button_text is text:
    font F_HAND
    size 28
    color C_INK
    hover_color C_RED
    selected_color C_RED
    insensitive_color "#bcbab4"

## 胶带按钮（主要操作）
style am_tape_button is button:
    background tape_frame("#f5b8c8")
    hover_background tape_frame("#ef8fa8")
    insensitive_background tape_frame("#e4e0da")
    hover_foreground nine("am/pen_box.png")
    padding (36, 14)

style am_tape_button_text is text:
    font F_HAND
    size 28
    color C_INK
    insensitive_color "#b4b2ad"
    xalign 0.5

## rebuttal 卡牌：小纸片，选中时变黄并打勾
style am_chip is button:
    background note("grey")
    hover_background note("yellow")
    selected_background note("yellow")
    insensitive_background note("grey")
    padding (marg("am/note_grey.png") + 14, marg("am/note_grey.png") + 8, marg("am/note_grey.png") + 14, marg("am/note_grey.png") + 6)

style am_chip_text is text:
    font F_BODY
    size 20
    color C_INK
    selected_color C_RED
    insensitive_color "#c8c6c0"

## ---- 小部件 -------------------------------------------------------------------
## 标题：红笔英文批注 + 手写中文大标题 + 一道红笔下划线
screen heading(note_text, title, size=None):
    vbox:
        spacing 0
        text note_text style "am_note" size 26
        text title style "am_h1" size (size or 52)
        add nine("am/pen_underline.png") xsize min(520, 40 + len(title) * (size or 52)) ysize 26 yoffset -8

## 胶带贴纸标签
screen tag(label, color=C_BLUE, solid=False):
    frame:
        background tape_frame(lighten(color, 0.15 if solid else 0.55))
        padding (20, 4)
        yalign 0.5
        text label font F_HAND size 19 color (C_INK if not solid else "#ffffff") substitute False

## 印章式状态（审稿中 / Accept / Reject）
screen stamp_tag(label, color, deg=-4):
    frame:
        background Frame(tinted("gui/am/stamp_frame.png", color), 16, 16)
        padding (14, 3)
        yalign 0.5
        at tilt(deg)
        text label font F_HAND size 19 color color substitute False

## 手绘进度条：铅笔框 + 荧光笔填充
screen meter(value, maxv=100, width=260, color=C_BLUE):
    fixed:
        xsize width
        ysize 30
        yalign 0.5
        $ frac = max(0.0, min(1.0, float(value) / maxv))
        if frac > 0.01:
            add Frame(tinted("gui/am/bar_fill_white.png", color, 0.85), 16, 16) xsize max(32, int(width * frac)) ysize 30
        add nine("am/bar_frame.png") xsize width ysize 30

screen stat_row(label, value, maxv=100, width=260, color=C_BLUE):
    hbox:
        spacing 12
        text label style "am_small" color C_INK min_width 70 yalign 0.5
        use meter(value, maxv, width, color)
        text "%d" % value style "am_num" size 26 min_width 44 yalign 0.5

## 好感：手绘小爱心
screen hearts(value, n=5, size=30):
    hbox:
        spacing 0
        yalign 0.5
        $ lit = heart_count(value, n)
        for i in range(n):
            add ("gui/am/heart_full.png" if i < lit else "gui/am/heart_empty.png") zoom (size / 30.0)

## 按可见区域摆放带投影的纸（自动扣除投影边距）
screen sheet_at(x, y, w, h, deg=0.0, kind="am_sheet"):
    $ m = marg("am/sheet.png") if kind == "am_sheet" else marg("am/index_card.png")
    frame:
        style kind
        xpos x - m
        ypos y - m
        xsize w + 2 * m
        ysize h + 2 * m
        at tilt(deg)
        transclude

## 半透明遮罩
screen dim(alpha=0.4):
    add Solid("#2a2430%02x" % int(alpha * 255))

## 拍立得照片里的头像：从立绘上裁出脸部
init python:
    def portrait(h, expr=None):
        info = {c["id"]: c for c in ART["characters"]}[h]
        path = sprite_path(h, expr or info["expressions"][0])
        if not path:
            return Solid("#e2ded6")
        # 脸框由 tools/import_art.py 写进 art_manifest.json；没有脸框的占位图用旧的固定位置
        box = info.get("face") or [190, 30, 340, 310]
        return Transform(Crop(tuple(box), path), xysize=(220, 199))
