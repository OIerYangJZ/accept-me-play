## 养成部分的界面 ——“研究手账”。
## 每周计划是摊开的活页本：左页贴着论文打印稿，右页是这周的便利贴。
## 样式与小部件见 ui_theme.rpy。

init python:
    def try_card(plan, sub, ri, ci, card):
        """rebuttal 界面里点卡牌：再点一次同一张卡 = 取消。"""
        if plan.assign.get((ri, ci)) == card:
            arebuttal.set_card(gs, plan, sub, ri, ci, None)
        else:
            ok, why = arebuttal.set_card(gs, plan, sub, ri, ci, card)
            if not ok:
                renpy.notify(why)
        renpy.restart_interaction()

    # ---------------- rebuttal 对线 ----------------
    duel_sel = 0  # 当前选中的意见（对线界面里点意见、再点卡）

    def duel_first_open(plan, ri, sub):
        for ci in range(len(sub.reviews[ri].concerns)):
            if (ri, ci) not in plan.assign:
                return ci
        return 0

    def duel_pick(plan, sub, ri, card):
        """把卡贴到当前选中的意见上；再点同一张 = 撕下来。贴好后自动跳到下一条没回应的。"""
        global duel_sel
        ci = duel_sel
        try_card(plan, sub, ri, ci, card)
        if plan.assign.get((ri, ci)) == card:
            duel_sel = duel_first_open(plan, ri, sub) if (ri, duel_first_open(plan, ri, sub)) not in plan.assign else ci
        renpy.restart_interaction()

    def duel_select(ci):
        global duel_sel
        duel_sel = ci
        renpy.restart_interaction()

    def auto_fill_one(plan, sub, ri):
        """这一位交给导师：按导师的思路给他的意见贴卡（时间不够就贴“诚恳修改”）。"""
        auto = arebuttal.auto_plan(gs, sub, plan.round_no)
        for (r, ci), card in auto.assign.items():
            if r == ri and (r, ci) not in plan.assign:
                ok, _ = arebuttal.set_card(gs, plan, sub, ri, ci, card)
                if not ok:
                    arebuttal.set_card(gs, plan, sub, ri, ci, "concede")
        renpy.restart_interaction()

    def card_hint(card, concern, review):
        c = arebuttal.CARDS[card]
        if c.get("only_persona"):
            return "专治代写"
        if c.get("risky"):
            return "看运气"
        eff = c["eff"].get(concern.kind, c["default"])
        if review.persona == "rev2" and concern.kind != "cite_me":
            eff *= 0.6
        return "很对症" if eff >= 0.8 else "有点用" if eff >= 0.45 else "不太对症"

    HINT_COLOR = {"很对症": "#4f9a6a", "有点用": "#b08a3a", "不太对症": "#a9a6a0", "看运气": "#c4404a", "专治代写": "#2a8f8f"}

    FOLLOWUP_LINES = {
        "normal": ["关于「{c}」，作者的回应没有说服我。能再具体一点吗？",
                   "「{c}」这一点，我仍然有疑问。补充的内容不够充分。"],
        "rev2": ["「{c}」——你以为一句话就能糊弄过去？",
                 "我再问一遍：「{c}」。这次认真回答。"],
        "delve": ["This rebuttal delves into…"],
    }

    def followup_line(review, ci):
        c = areview.CONCERN_NAMES[review.concerns[ci].kind]
        return renpy.random.choice(FOLLOWUP_LINES[review.persona]).format(c=c)

    def reviewer_face(review):
        return {"rev2": "rev2", "delve": "delve"}.get(review.persona)

    def auto_fill(plan, sub):
        auto = arebuttal.auto_plan(gs, sub, plan.round_no)
        plan.assign.clear()
        plan.assign.update(auto.assign)
        renpy.restart_interaction()

    def sub_status(s):
        """(状态文字, 颜色, 补充说明)"""
        if s.status == "waiting":
            return ("审稿中", C_BLUE, "第 %d 周出意见" % (s.reviews_week + 1))
        if s.status == "reviewed":
            return ("等结果", C_GOLD, "第 %d 周出结果" % (s.decision_week + 1))
        if s.outcome == "accept":
            return ("ACCEPT", C_RED, "")
        return ("REJECT", C_INK_SOFT, "")

    def crowd_comments(k=6):
        pools = POOLS["openreview_crowd"]
        out = []
        for _ in range(k):
            cat = renpy.random.choice(list(pools))
            out.append((cat, renpy.random.randint(1000, 9999), renpy.random.choice(pools[cat])))
        return out

    CROWD_NOTES = {"support": "mint", "troll": "pink", "neutral": "blue", "meme": "lavender"}
    CROWD_NAMES = {"support": "路过的支持者", "troll": "匿名吐槽役", "neutral": "旁观的博士生", "meme": "梗图制造机"}

    ACTION_NOTES = {
        "read": "blue", "experiment": "lavender", "theory": "blue", "write": "yellow",
        "promote": "peach", "rest": "mint", "social": "pink", "crunch": "peach",
    }
    ACTION_NOTE_EN = {
        "read": "read", "experiment": "run it!", "theory": "prove it", "write": "write",
        "promote": "post it", "rest": "zzz...", "social": "go see her", "crunch": "DDL!!",
    }
    TAPE_NAMES = ("pink", "mint", "yellow", "blue", "lavender")
    ACTION_SHORT = {
        "read": "创新↑ · 攒 idea", "experiment": "实验结果↑ · 耗算力", "theory": "严谨↑",
        "write": "表达↑ · 完成度↑↑", "promote": "热度↑", "rest": "SAN↑",
        "social": "好感↑ · 可能触发剧情", "crunch": "完成度暴涨 · SAN↓↓",
    }

    def plan_slot_label(k):
        a, t = gs.plan[k]
        if a == "social":
            return "见" + adata.HEROINES[t]["name"]
        return adata.ACTIONS[a]["name"]

    def plan_slot_helper(k):
        """这一格贴着的 AI 帮手贴纸（形态名），没有就是 None。"""
        a, t = gs.plan[k]
        return ahelpers.FORMS[t]["name"] if a != "social" and t in ahelpers.FORMS else None

    def week_title(act, target):
        if act == "social" and target:
            return "见" + adata.HEROINES[target]["name"]
        name = adata.ACTIONS[act]["name"]
        return name + " · " + ahelpers.FORMS[target]["name"] if target in ahelpers.FORMS else name

    def helper_button_label():
        if gs.helper in ahelpers.FORMS:
            return "AI 帮手：%s" % ahelpers.label(gs.helper)
        return "AI 帮手：不用"

    def set_helper(form):
        gs.helper = form

    def family_status(fam):
        if not gs.met.get(fam):
            return "还没认识她"
        if fam == "claude" and ahelpers.is_banned(gs):
            return "账号停用中 · 还要 %d 周" % ahelpers.ban_weeks_left(gs)
        if fam == "chatgpt" and ahelpers.is_dumb(gs):
            return "额度 %d / %d · 降智中" % (gs.quota[fam], ahelpers.QUOTA)
        return "本月额度 %d / %d" % (gs.quota[fam], ahelpers.QUOTA)

    HELPER_NOTES = {"chatgpt": "mint", "claude": "peach"}

    def topic_fans(tid):
        fit = adata.TOPICS[tid]["fit"]
        return [venue_name(v) for v, f in sorted(fit.items(), key=lambda x: -x[1]) if f >= 1.05]

    def score10(venue, shown):
        scale = adata.VENUES[venue]["scale"]
        if adata.VENUES[venue].get("scale_from_ten"):
            return 1.0 + (shown - scale[0]) * 9.0 / (scale[-1] - scale[0])
        return shown


## 日程本右页是不是正在显示“请谁帮忙”（存在 store 里，自动化测试可以直接打开）
default planner_show_helper = False

## 一张可点击的便利贴（宽高是“看得见的纸”的尺寸）
screen note_button(w, h, color, action, i=0, sensitive=True, selected=False):
    $ m = marg("am/note_yellow.png")
    button:
        style "am_note_button"
        xysize (w + 2 * m, h + 2 * m)
        background (note(color) if sensitive else note("grey"))
        action action
        sensitive sensitive
        selected selected
        at note_lift(tilt_for(i, 1.0))
        transclude


## ---------------------------------------------------------------------------
## 每周计划
## ---------------------------------------------------------------------------
screen week_planner():
    default show_social = False
    if ap_go("week_planner"):
        timer 0.02 action Function(ap_week)

    if gs.low_san:
        add "gui/am/planner_bg.png" at low_san_filter
    else:
        add "gui/am/planner_bg.png"

    # ---------------- 左页 ----------------
    fixed:
        xpos 130 ypos 62 xysize (780, 960)

        # 日期与状态
        text "week %02d / %d" % (gs.week + 1, adata.WEEKS_TOTAL) style "am_note" size 28
        text gs.date_label style "am_h1" size 46 ypos 26
        hbox:
            ypos 104
            spacing 30
            hbox:
                spacing 10
                text "SAN" style "am_num" size 26 color C_INK_SOFT yalign 0.5
                use meter(gs.san, 100, 170, san_color(gs.san))
                text "%d" % gs.san style "am_num" size 26 color san_color(gs.san) yalign 0.5
            hbox:
                spacing 10
                text "算力" style "am_small" color C_INK_SOFT yalign 0.5
                use meter(gs.compute, adata.COMPUTE_MAX, 150, C_BLUE)
                text "%d" % gs.compute style "am_num" size 26 yalign 0.5
        hbox:
            ypos 150
            spacing 12
            use tag("声望 %d" % gs.reputation, C_GOLD)
            use tag("idea × %d" % gs.ideas, C_BLUE)
            text "导师：%s（%s）" % (gs.advisor_info["name"], gs.advisor_info["type"]) style "am_small" yalign 0.5
        if gs.low_san:
            text "SAN 太低了……做什么都提不起劲，世界也变得刻薄起来。" style "am_small" color C_RED ypos 190

        # 论文打印稿（回形针夹着）
        fixed:
            ypos 230 xysize (760, 420)
            at tilt(-0.8)
            frame:
                style "am_sheet"
                xpos -marg("am/sheet.png") ypos -marg("am/sheet.png")
                xsize 760 + 2 * marg("am/sheet.png") ysize 420 + 2 * marg("am/sheet.png")
                if gs.current_paper:
                    $ cp = gs.current_paper
                    vbox:
                        spacing 8
                        text "Under review · Anonymous Authors · %s" % adata.TOPICS[cp.topic]["name"] font F_EN size 20 color C_MUTED
                        text cp.title style "am_h2" size 30 substitute False
                        hbox:
                            spacing 10
                            if cp.arxiv:
                                use tag("已挂 arXiv", C_RED)
                            if cp.scooped:
                                use stamp_tag("被抢发", C_RED)
                            if cp.travel:
                                use tag("环游 %d 次" % cp.travel, C_GOLD)
                            if ahelpers.hedge(cp) >= 10:
                                use tag("满纸防御性措辞", C_GOLD)
                            if gs.paper_under_review(cp.id):
                                use stamp_tag("审稿中", C_BLUE)
                        null height 4
                        use stat_row("完成度", cp.progress, 100, 440, C_ROSE)
                        grid 2 3:
                            xspacing 26
                            yspacing 6
                            for a in adata.ATTRS:
                                use stat_row(adata.ATTR_NAMES[a], cp.attrs[a], 100, 170, C_BLUE)
                            null
                else:
                    vbox:
                        spacing 10
                        yalign 0.5
                        text "（桌上空空的）" style "am_h2" color C_MUTED
                        text "你手上还没有课题。读读论文，攒一个 idea 吧。" style "am_body"
            add "gui/am/paperclip.png" xpos 660 ypos -30

        # 课题操作
        hbox:
            ypos 676
            spacing 18
            if aactions.can_start_paper(gs):
                textbutton "＋ 开始新课题" style "am_pen_button" action Return(("start_paper", None))
            for pp in gs.papers:
                if pp.id != gs.active_paper and pp.status in ("draft", "rejected") and not gs.paper_under_review(pp.id):
                    textbutton "换成《%s…》" % pp.title[:10] style "am_pen_button" action Return(("switch_paper", pp.id))
            if gs.current_paper and "nature" in areview.venues_open_for(gs, gs.current_paper):
                textbutton "投给 Nature" style "am_tape_button" action Return(("submit_nature", gs.current_paper.id))

        # 投稿记录
        text "submissions" style "am_note" ypos 736
        viewport:
            ypos 772 xsize 780 ysize 104
            mousewheel True
            vbox:
                spacing 6
                for s in reversed(gs.submissions):
                    $ st_label, st_color, st_note = sub_status(s)
                    hbox:
                        spacing 12
                        use tag(venue_name(s.venue), VENUE_COLORS.get(s.venue, C_BLUE), True)
                        text "《%s》" % gs.paper(s.paper_id).title[:20] style "am_small" color C_INK yalign 0.5 substitute False
                        use stamp_tag(st_label, st_color)
                        if st_note:
                            text st_note style "am_tiny" yalign 0.5
                if not gs.submissions:
                    text "还没有投过稿。" style "am_small"

        # 截稿日
        text "deadlines" style "am_note" ypos 888
        $ upcoming = sorted([(d, v) for v in adata.CONFERENCE_ORDER for d in adata.VENUES[v]["deadlines"] if gs.week <= d <= gs.week + 12])
        hbox:
            ypos 924
            spacing 12
            for d, v in upcoming:
                $ urgent = d - gs.week <= 2
                fixed:
                    xysize (190, 40)
                    if urgent:
                        add Transform("gui/am/pen_circle.png", xysize=(200, 54)) xpos -5 ypos -7
                    text "%s %s" % (venue_name(v), ("今天！" if d == gs.week else "%d周后" % (d - gs.week))):
                        style "am_small"
                        color (C_RED if urgent else C_INK)
                        xalign 0.5 yalign 0.5
            if not upcoming:
                text "最近 12 周没有截稿日。" style "am_small"

    # ---------------- 右页 ----------------
    hbox:
        xpos 1830 xanchor 1.0 ypos 64
        spacing 4
        textbutton "存档" style "am_pen_button" text_size 22 action ShowMenu("save")
        textbutton "读档" style "am_pen_button" text_size 22 action ShowMenu("load")
        textbutton "设置" style "am_pen_button" text_size 22 action ShowMenu("preferences")

    fixed:
        xpos 1060 ypos 62 xysize (780, 960)
        if planner_show_helper:
            use helper_panel(SetVariable("planner_show_helper", False))
        elif not show_social:
            use heading("this month", "接下来几周做什么？", 48)
            text "点便利贴排进日程，排好按「开始」。" style "am_small" ypos 122
            if gs.met.get("chatgpt") or gs.met.get("claude"):
                textbutton helper_button_label() style "am_pen_button" text_size 22 xalign 1.0 ypos 108 action SetVariable("planner_show_helper", True)

            # ---- 日程格子 ----
            $ preview = aactions.plan_preview(gs, gs.plan)
            hbox:
                ypos 162
                spacing 12
                for k in range(PLAN_SLOTS):
                    $ wk = gs.week + k
                    button:
                        xysize (184, 150)
                        padding (14, 10)
                        if k < len(gs.plan):
                            background note(ACTION_NOTES[gs.plan[k][0]])
                            hover_foreground nine("am/pen_box.png")
                            action Function(plan_remove, k)
                        else:
                            background nine("am/pen_box.png")
                            action NullAction()
                            sensitive k < plan_capacity()
                        at note_lift(tilt_for(k, 1.2))
                        vbox:
                            spacing 2
                            text "第 %d 周" % (wk + 1) style "am_small" size 22 color (C_RED if wk in [d for d in aactions.upcoming_deadlines(gs, 4)] else C_MUTED)
                            if k < len(gs.plan):
                                text plan_slot_label(k) style "am_note_title" size 27
                                if plan_slot_helper(k):
                                    text "+ " + plan_slot_helper(k) font F_EN size 22 color C_BLUE
                                if preview[k][2]:
                                    text preview[k][2] style "am_tiny" color C_RED xmaximum 160
                            elif k < plan_capacity():
                                text "（空）" style "am_note_desc" color C_MUTED
                            else:
                                text "学年结束" style "am_note_desc" color C_MUTED

            # ---- 可排的行动 ----
            $ m = marg("am/note_yellow.png")
            $ k_next = len(gs.plan)
            grid 2 4:
                ypos 336
                xspacing 26 - 2 * m
                yspacing 14 - 2 * m
                for i, a in enumerate(adata.ACTION_ORDER):
                    $ why = slot_problem(a, k_next) if k_next < plan_capacity() else "日程排满了"
                    $ ok = why is None
                    $ cmb = next_combo(a) if ok else (1.0, 0, "")
                    use note_button(372, 104, ACTION_NOTES[a], (SetScreenVariable("show_social", True) if a == "social" else Function(plan_add, a)), i, ok):
                        fixed:
                            vbox:
                                spacing 0
                                text ACTION_NOTE_EN[a] style "am_note" size 22 color (C_RED if ok else "#c8c6c0")
                                text adata.ACTIONS[a]["name"] style "am_note_title" size 28
                                if not ok:
                                    text "—— " + why style "am_note_desc" size 19 xmaximum 330
                                elif cmb[2] and cmb[0] > 1.0:
                                    text "+%d%%  %s" % (round((cmb[0] - 1) * 100), cmb[2].split("，")[0]) style "am_note_desc" size 19 color C_RED xmaximum 330
                                elif cmb[2]:
                                    text cmb[2] style "am_note_desc" size 19 color C_RED xmaximum 330
                                else:
                                    text ACTION_SHORT[a] style "am_note_desc" size 19 xmaximum 330
                            if not ok:
                                add "gui/am/pencil_cross.png" xalign 1.0 yalign 0.0 zoom 0.8

            # ---- 开始 / 照上次 / 清空 ----
            hbox:
                ypos 842
                spacing 22
                textbutton "▶ 开始" style "am_tape_button" text_size 30 action Return(("go", None)) sensitive bool(gs.plan)
                textbutton "照上次再来" style "am_pen_button" yalign 0.5 action Function(plan_repeat) sensitive bool(gs.last_plan) and not gs.plan
                textbutton "清空" style "am_pen_button" yalign 0.5 action Function(plan_remove, 0) sensitive bool(gs.plan)
        else:
            use heading("who to see?", "去见谁？", 48)
            text "好感越高，越容易遇到她的故事。" style "am_small" ypos 122
            $ visitable = aevents.visitable_heroines(gs)
            $ blocked = [h for h in adata.HEROINE_ORDER if gs.met.get(h) and h not in visitable]
            $ pm = marg("am/polaroid.png")
            grid 5 2:
                ypos 190
                xspacing 10
                yspacing 26
                for i, h in enumerate(visitable + blocked):
                    $ ok = h in visitable
                    button:
                        xysize (137, 228)
                        padding (0, 0)
                        if ok:
                            hover_foreground nine("am/pen_box.png")
                            action [Function(plan_add, "social", h), SetScreenVariable("show_social", False)]
                        else:
                            action NullAction()
                        at note_lift(tilt_for(i, 2.4))
                        fixed:
                            xysize (180, 300)
                            at Transform(zoom=0.76)
                            add Transform("gui/am/polaroid.png", zoom=0.6) xpos -int(pm * 0.6) ypos -int(pm * 0.6)
                            if ok:
                                add portrait(h) zoom 0.74 xpos 10 ypos 10
                            else:
                                add portrait(h) zoom 0.74 xpos 10 ypos 10 at low_san_filter
                            text adata.HEROINES[h]["name"] style "am_h3" size 25 xalign 0.5 ypos 162
                            text adata.HEROINES[h]["origin"] font F_EN size 20 color C_MUTED xalign 0.5 ypos 192
                            hbox:
                                xalign 0.5 ypos 226
                                use hearts(gs.affinity[h], 5, 30)
                            add "gui/am/tape_%s.png" % TAPE_NAMES[i % len(TAPE_NAMES)]:
                                at tilt(tilt_for(i + 2, 7.0))
                                xpos 30 ypos -22 zoom 0.55
                            if not ok:
                                fixed:
                                    xpos 22 ypos 40 xysize (140, 90)
                                    use stamp_tag("Suspended", C_RED, -8)
                for i in range(10 - len(visitable) - len(blocked)):
                    null
            textbutton "← 先不去了" style "am_pen_button" ypos 860 action SetScreenVariable("show_social", False)


## ---------------------------------------------------------------------------
## 请谁帮忙：ChatGPT / Claude 的形态（见 acceptme/helpers.py）
## ---------------------------------------------------------------------------
screen helper_panel(close):
    use heading("who helps?", "请谁帮忙？", 48)
    text "选中的帮手会跟着排进去的每一个工作周（读论文、跑实验、推公式、写论文）。" style "am_small" ypos 122 xmaximum 780
    $ m = marg("am/note_yellow.png")
    hbox:
        ypos 176
        spacing 26 - 2 * m
        for j, fam in enumerate(("chatgpt", "claude")):
            $ ready = gs.met.get(fam) and not (fam == "claude" and ahelpers.is_banned(gs))
            vbox:
                spacing 12 - 2 * m
                hbox:
                    spacing 10
                    xoffset m
                    text ahelpers.FAMILIES[fam]["name"] style "am_h2" size 30
                    text family_status(fam) style "am_small" color (C_RED if not ready or (fam == "chatgpt" and ahelpers.is_dumb(gs)) else C_INK_SOFT) yalign 0.7
                for i, f in enumerate(ahelpers.FAMILIES[fam]["forms"]):
                    $ fd = ahelpers.FORMS[f]
                    $ ok = ready and gs.quota[fam] >= fd["cost"]
                    use note_button(352, 104, HELPER_NOTES[fam], [Function(set_helper, f), close], i + 4 * j, ok, gs.helper == f):
                        fixed:
                            vbox:
                                spacing 0
                                hbox:
                                    spacing 12
                                    text fd["name"] style "am_note_title" size 28
                                    text "额度 %d" % fd["cost"] style "am_note" size 22 color C_RED yalign 0.6
                                text fd["desc"] style "am_note_desc" size 19 xmaximum 320
                            if gs.helper == f:
                                add "gui/am/pen_circle.png" xalign 1.0 yalign 0.0 zoom 0.35
    hbox:
        ypos 842
        spacing 22
        textbutton "不用 AI，自己来" style "am_tape_button" text_size 26 action [Function(set_helper, None), close]
        textbutton "← 返回" style "am_pen_button" yalign 0.5 action close
    text "ChatGPT 推公式最强，但满纸防御性措辞，本月额度用掉六成还会降智；Claude 写得好、代码好，但会被封号。结局会统计有几封信是你自己写的。" style "am_tiny" ypos 912 xmaximum 780


## ---------------------------------------------------------------------------
## 每周结果：一张便利贴，停一会儿自动消失（点一下也能跳过），不用按空格
## ---------------------------------------------------------------------------
screen week_tick(act, target, res, flavor=None):
    zorder 50
    if ap_go("week_tick"):
        timer 0.02 action Return(True)
    else:
        timer (1.6 + 0.35 * len(res["lines"])) action Return(True)
    key "dismiss" action Return(True)
    button:
        xfill True yfill True
        background None
        action Return(True)
    $ m = marg("am/note_yellow.png")
    fixed:
        at drop_in(0.0, -1.2)
        xalign 0.5 ypos 120 xysize (860, 300)
        frame:
            background note(ACTION_NOTES.get(act, "yellow"))
            xpos -m ypos -m xysize (860 + 2 * m, 300 + 2 * m)
            padding (m + 40, m + 26)
            vbox:
                spacing 8
                text "week %02d" % gs.week style "am_note" size 26
                text week_title(act, target) style "am_note_title" size 40
                for ln in res["lines"]:
                    text ln style "am_note_desc" size 26 color (C_RED if ln.startswith("（") else C_INK_SOFT)
                if flavor:
                    null height 4
                    text flavor style "am_note_desc" size 22 italic True xmaximum 760


## ---------------------------------------------------------------------------
## 选题
## ---------------------------------------------------------------------------
screen topic_select():
    modal True
    if ap_go("topic_select"):
        timer 0.02 action Function(ap_topic)
    use dim()
    use sheet_at(330, 70, 1260, 940, -0.6, "am_card"):
        vbox:
            spacing 0
            use heading("new project", "选一个新课题")
            text "你的主攻方向是「%s」。和会议口味对得上的选题，审稿时更占便宜。" % adata.TRACKS[gs.track]["name"] style "am_small"
            null height 20
            vbox:
                spacing 8
                for tid, t in adata.TOPICS.items():
                    button:
                        style "am_pen_button"
                        xfill True
                        padding (14, 10)
                        action Return(tid)
                        hbox:
                            spacing 18
                            fixed:
                                xysize (40, 40)
                                yalign 0.5
                                add "gui/am/box_empty.png"
                                add "gui/am/pen_check.png" at show_on_hover xoffset 2 yoffset -8
                            vbox:
                                xsize 760
                                text t["name"] style "am_pen_button_text" size 30
                                text t["desc"] style "am_small"
                            hbox:
                                spacing 8
                                yalign 0.5
                                for vn in topic_fans(tid):
                                    use tag(vn + " 爱看", C_GREEN)
            null height 16
            textbutton "← 再想想" style "am_pen_button" action Return(None)


## ---------------------------------------------------------------------------
## 投稿
## ---------------------------------------------------------------------------
screen submit_select(v, cands):
    modal True
    if ap_go("submit_select"):
        timer 0.02 action Function(ap_submit, v, cands)
    use dim()
    use sheet_at(420, 110, 1080, 860, 0.5, "am_card"):
        vbox:
            spacing 0
            use heading("deadline today!", "投给 %s 吗？" % venue_name(v))
            text "选一篇投出去，或者这次先放一放。" style "am_small"
            null height 24
            viewport:
                ysize 520
                mousewheel True
                vbox:
                    spacing 12 - 2 * marg("am/note_yellow.png")
                    for i, pp in enumerate(cands):
                        use note_button(900, 140, NOTE_CYCLE[i % 6], Return(pp.id), i):
                            vbox:
                                spacing 6
                                text "《%s》" % pp.title style "am_note_title" substitute False
                                hbox:
                                    spacing 24
                                    text "完成度 %d" % pp.progress style "am_note_desc"
                                    for a in adata.ATTRS:
                                        text "%s %d" % (adata.ATTR_NAMES[a], pp.attrs[a]) style "am_note_desc"
            null height 16
            textbutton "这次先不投" style "am_pen_button" action Return(None)


## ---------------------------------------------------------------------------
## 审稿意见与 rebuttal
## ---------------------------------------------------------------------------
screen review_card(sub, ri, r, plan, editable):
    $ vcfg = adata.VENUES[sub.venue]
    $ shown = areview.display_score(sub.venue, r.score)
    vbox:
        spacing 10
        hbox:
            spacing 18
            text r.name style "am_h2" size 30 color (C_RED if r.persona == "rev2" else ("#2a8f8f" if r.persona == "delve" else C_INK)) yalign 0.5
            fixed:
                xysize (150, 56)
                yalign 0.5
                add Transform("gui/am/pen_circle.png", xysize=(170, 62)) xpos -10 ypos -3
                text "%s / %s" % (shown, vcfg["scale"][-1]) style "am_num" size 30 color score_color(score10(sub.venue, shown)) xalign 0.5 yalign 0.5
            text "confidence %d" % r.confidence font F_EN size 22 color C_MUTED yalign 0.5
            if r.persona == "rev2":
                use stamp_tag("红笔", C_RED, 6)
            elif r.persona == "delve":
                use stamp_tag("疑似大模型代写", "#2a8f8f", -5)
        for ci, c in enumerate(r.concerns):
            vbox:
                spacing 6
                hbox:
                    spacing 12
                    use tag(areview.CONCERN_NAMES[c.kind], C_INK_SOFT)
                    text getattr(c, "text", "") style "am_body" size 23 xmaximum 1000 yalign 0.5 substitute False
                if c.resolved > 0:
                    text "✓ 已回应 %d%%" % (c.resolved * 100) style "am_small" color C_GREEN
                if editable:
                    hbox:
                        spacing 4 - 2 * marg("am/note_grey.png")
                        box_wrap True
                        xmaximum 1180
                        for card in arebuttal.CARD_ORDER:
                            if arebuttal.card_usable(gs, sub, r, card):
                                textbutton "%s · %g天" % (arebuttal.CARDS[card]["name"], arebuttal.CARDS[card]["days"]):
                                    style "am_chip"
                                    selected plan.assign.get((ri, ci)) == card
                                    action Function(try_card, plan, sub, ri, ci, card)
                                    tooltip arebuttal.CARDS[card]["desc"]
        add Solid(C_LINE, ysize=2)


screen review_board(sub, plan, editable):
    modal True
    if ap_go("review_board"):
        timer 0.02 action (Function(ap_rebuttal, plan, sub) if editable else Return(ap_board_choice() if plan is not None else True))
    $ vcfg = adata.VENUES[sub.venue]
    $ public = vcfg.get("public", False)
    default crowd = crowd_comments(6)
    add "gui/am/desk.png"

    use sheet_at(50, 30, (1330 if public else 1820), 1020, -0.3):
        vbox:
            spacing 0
            hbox:
                spacing 16
                use tag(venue_name(sub.venue), VENUE_COLORS.get(sub.venue, C_BLUE), True)
                text "Official Reviews" font F_EN size 30 color C_INK_SOFT yalign 0.5
                if public:
                    use stamp_tag("公开审稿 · 所有人可见", C_BLUE, -3)
            text "《%s》" % gs.paper(sub.paper_id).title style "am_h1" size 38 substitute False
            if plan is not None and not editable:
                text "rebuttal 第 %d 轮：点「开始对线」一位一位回应审稿人（他们会当场回话，还可能追问）；不想细抠，就交给导师。" % plan.round_no style "am_small" color C_RED
            null height 8
            if editable:
                $ days, comp = plan.cost()
                hbox:
                    spacing 34
                    text "rebuttal · round %d" % plan.round_no style "am_note" size 26 yalign 0.5
                    hbox:
                        spacing 10
                        use meter(min(days, plan.budget), plan.budget, 260, (C_RED if days > plan.budget else C_GOLD))
                        text "%.1f / %.1f 天" % (days, plan.budget) style "am_small" color C_INK yalign 0.5
                    text "算力 %d / %d" % (comp, gs.compute) style "am_small" color (C_RED if comp > gs.compute else C_INK) yalign 0.5
                text "给每条意见贴一张回应卡；再点一次可以撕下来。" style "am_small"
                null height 8

            viewport:
                ysize (640 if editable else 760)
                mousewheel True
                scrollbars "vertical"
                vbox:
                    spacing 22
                    for ri, r in enumerate(sub.reviews):
                        use review_card(sub, ri, r, plan, editable)

            null height 12
            hbox:
                spacing 24
                if editable:
                    textbutton "让导师帮忙分配" style "am_pen_button" action Function(auto_fill, plan, sub)
                    textbutton "提交 rebuttal" style "am_tape_button" action Return(True)
                elif plan is not None:
                    textbutton "交给导师分配" style "am_pen_button" yalign 0.5 action Return("auto")
                    textbutton "开始对线 →" style "am_tape_button" action Return("duel")
                else:
                    textbutton "看完了" style "am_tape_button" action Return(True)
                $ tip = GetTooltip()
                if tip:
                    text tip style "am_small" yalign 0.5 substitute False

    if public:
        text "路人评论" style "am_h2" xpos 1450 ypos 40
        text "public comments" style "am_note" size 24 xpos 1456 ypos 88
        $ m = marg("am/note_yellow.png")
        vbox:
            xpos 1430 ypos 130
            spacing 6 - 2 * m
            for i, (cat, uid, line) in enumerate(crowd):
                frame:
                    background note(CROWD_NOTES[cat])
                    xsize 440 + 2 * m
                    padding (m + 20, m + 18, m + 20, m + 14)
                    at tilt(tilt_for(i, 1.6))
                    vbox:
                        spacing 4
                        text "%s #%d" % (CROWD_NAMES[cat], uid) style "am_tiny" color C_INK_SOFT
                        text line style "am_small" color C_INK substitute False


## ---------------------------------------------------------------------------
## rebuttal 对线：一位一位来。先点意见，再出牌；出完看对方的反应，可能还会被追问
## ---------------------------------------------------------------------------
screen duel_reviewer(sub, r, idx, total, shown_score=None):
    ## 左边：审稿人的拍立得
    $ face = reviewer_face(r)
    $ pm = marg("am/polaroid.png")
    fixed:
        xpos 80 ypos 70 xysize (380, 560)
        at tilt(-1.5)
        add Transform("gui/am/polaroid.png", xysize=(380 + 2 * pm, 430 + 2 * pm)) xpos -pm ypos -pm
        if face:
            add portrait(face) zoom 1.55 xpos 20 ypos 20
        else:
            add Solid("#e9e4da", xysize=(340, 310)) xpos 20 ypos 20
            text r.name.replace("Reviewer ", "") font F_EN size 140 color C_INK_SOFT xpos 190 xanchor 0.5 ypos 70
            text "匿名审稿人" style "am_small" xpos 190 xanchor 0.5 ypos 260
        text r.name style "am_h2" size 34 xpos 190 xanchor 0.5 ypos 350 color (C_RED if r.persona == "rev2" else ("#2a8f8f" if r.persona == "delve" else C_INK))
        add "gui/am/tape_pink.png" xpos 130 ypos -26 zoom 0.6
    vbox:
        xpos 100 ypos 560
        spacing 8
        $ sc = areview.display_score(sub.venue, r.score) if shown_score is None else shown_score
        hbox:
            spacing 14
            text "评分" style "am_small" yalign 0.5
            fixed:
                xysize (150, 56)
                add Transform("gui/am/pen_circle.png", xysize=(170, 62)) xpos -10 ypos -3
                text "%s / %s" % (sc, adata.VENUES[sub.venue]["scale"][-1]) style "am_num" size 30 color score_color(score10(sub.venue, sc)) xalign 0.5 yalign 0.5
        if r.persona == "rev2":
            use stamp_tag("红笔 · 最难缠", C_RED, 6)
        elif r.persona == "delve":
            use stamp_tag("疑似大模型代写", "#2a8f8f", -5)
        text "对线 %d / %d" % (idx, total) style "am_note" size 26


screen rebuttal_duel(sub, plan, ri, idx, total):
    modal True
    if ap_go("rebuttal_duel"):
        timer 0.02 action [Function(auto_fill_one, plan, sub, ri), Return("go")]
    $ r = sub.reviews[ri]
    $ days, comp = plan.cost()
    add "gui/am/desk.png"
    use duel_reviewer(sub, r, idx, total)

    # 右边：他的意见
    use sheet_at(540, 40, 1320, 600, 0.3):
        vbox:
            spacing 8
            hbox:
                spacing 30
                text "rebuttal · round %d" % plan.round_no style "am_note" size 26 yalign 0.5
                hbox:
                    spacing 10
                    text "剩余时间" style "am_small" yalign 0.5
                    use meter(max(0, plan.budget - days), plan.budget, 220, C_GOLD)
                    text "%.1f 天" % max(0, plan.budget - days) style "am_small" color C_INK yalign 0.5
                text "算力 %d" % (gs.compute - sum(arebuttal.CARDS[c]["compute"] for (rr, _c), c in plan.assign.items() if rr not in plan.done)) style "am_small" yalign 0.5
            text "先点一条意见，再从下面出一张牌。时间是这一轮所有审稿人共用的。" style "am_small"
            null height 6
            for ci, c in enumerate(r.concerns):
                $ card = plan.assign.get((ri, ci))
                button:
                    xfill True
                    padding (16, 12)
                    background (nine("am/highlight.png") if ci == duel_sel else None)
                    hover_background nine("am/highlight.png")
                    action Function(duel_select, ci)
                    hbox:
                        spacing 14
                        use tag(areview.CONCERN_NAMES[c.kind], C_INK_SOFT)
                        vbox:
                            xsize 820
                            spacing 4
                            text getattr(c, "text", "") style "am_body" size 23 substitute False
                            if c.resolved > 0:
                                text "✓ 之前已回应 %d%%" % (c.resolved * 100) style "am_small" color C_GREEN
                        if card:
                            use stamp_tag(arebuttal.CARDS[card]["name"], C_BLUE, -4)
                        else:
                            text "未回应" style "am_small" color C_MUTED yalign 0.5

    # 下面：手牌
    $ cards = [c for c in arebuttal.CARD_ORDER if arebuttal.card_usable(gs, sub, r, c)]
    $ selc = r.concerns[duel_sel] if duel_sel < len(r.concerns) else r.concerns[0]
    hbox:
        xpos 60 ypos 690
        spacing 6 - 2 * marg("am/note_yellow.png")
        for i, cid in enumerate(cards):
            $ cd = arebuttal.CARDS[cid]
            $ hint = card_hint(cid, selc, r)
            use note_button(236, 200, NOTE_CYCLE[i % 6], Function(duel_pick, plan, sub, ri, cid), i, True, plan.assign.get((ri, duel_sel)) == cid):
                vbox:
                    spacing 4
                    text cd["name"] style "am_note_title" size 30
                    text "%g 天%s" % (cd["days"], (" · 算力 %d" % cd["compute"]) if cd["compute"] else "") style "am_note_desc" size 20
                    text hint style "am_note_desc" size 24 color HINT_COLOR[hint]
                    text cd["desc"] style "am_note_desc" size 17 xmaximum 210

    hbox:
        xpos 1860 xanchor 1.0 ypos 968
        spacing 26
        textbutton "全部交给导师" style "am_pen_button" yalign 0.5 action Return("auto_all")
        textbutton "这位交给导师" style "am_pen_button" yalign 0.5 action Function(auto_fill_one, plan, sub, ri)
        textbutton "回应 →" style "am_tape_button" text_size 30 action Return("go")


screen duel_reaction(sub, plan, ri, res, fu, idx, total):
    ## 对方的反应；fu 不是 None 时还会追问，可以再出一张牌（或者不接）
    modal True
    if ap_go("duel_reaction"):
        timer 0.02 action Return(ap_followup(plan, sub, ri, fu))
    $ r = sub.reviews[ri]
    $ before = areview.display_score(sub.venue, r.score - res["delta"])
    $ after = areview.display_score(sub.venue, r.score)
    $ col = {"raise": C_GREEN, "keep": C_INK_SOFT, "lower": C_RED}[res["reply"]]
    add "gui/am/desk.png"
    use duel_reviewer(sub, r, idx, total, after)

    use sheet_at(540, 60, 1320, (560 if fu is not None else 760), -0.4):
        vbox:
            spacing 12
            hbox:
                spacing 14
                text "%s" % before style "am_num" size 56 color C_MUTED
                text "→" style "am_h2" size 50 color col yalign 0.5
                text "%s" % after style "am_num" size 56 color col
                text {"raise": "上调了评分", "keep": "维持原分", "lower": "下调了评分"}[res["reply"]] style "am_h3" color col yalign 0.7
            text "「%s」" % getattr(r, "reply_text", "") style "am_body" size 28 xmaximum 1200 substitute False
            for note_line in res["notes"]:
                text "※ " + note_line style "am_small"
            if fu is not None:
                null height 10
                add Solid(C_LINE, ysize=2)
                text "追问" style "am_note" size 30 color C_RED
                text followup_line(r, fu) style "am_body" size 26 color C_RED xmaximum 1200 substitute False

    if fu is not None:
        $ cards = [c for c in arebuttal.CARD_ORDER if arebuttal.followup_usable(gs, plan, sub, ri, c)]
        hbox:
            xpos 60 ypos 690
            spacing 6 - 2 * marg("am/note_yellow.png")
            for i, cid in enumerate(cards):
                $ cd = arebuttal.CARDS[cid]
                $ hint = card_hint(cid, r.concerns[fu], r)
                use note_button(236, 200, NOTE_CYCLE[i % 6], Return(cid), i):
                    vbox:
                        spacing 4
                        text cd["name"] style "am_note_title" size 30
                        text "%g 天%s" % (cd["days"], (" · 算力 %d" % cd["compute"]) if cd["compute"] else "") style "am_note_desc" size 20
                        text hint style "am_note_desc" size 24 color HINT_COLOR[hint]
        hbox:
            xpos 1860 xanchor 1.0 ypos 968
            spacing 26
            text "剩余 %.1f 天" % plan.days_left() style "am_small" yalign 0.5
            textbutton "不接了" style "am_pen_button" yalign 0.5 action Return(None)
    else:
        textbutton "继续" style "am_tape_button" text_size 30 xpos 1860 xanchor 1.0 ypos 960 action Return(None)


screen rebuttal_result(sub, results):
    modal True
    if ap_go("rebuttal_result"):
        timer 0.02 action Return(True)
    add "gui/am/desk.png"
    use sheet_at(280, 70, 1360, 940, 0.4):
        vbox:
            spacing 0
            use heading("after rebuttal", "审稿人的回复")
            null height 16
            vbox:
                spacing 18
                for res in results:
                    $ r = sub.reviews[res["review"]]
                    $ before = areview.display_score(sub.venue, r.score - res["delta"])
                    $ after = areview.display_score(sub.venue, r.score)
                    $ col = {"raise": C_GREEN, "keep": C_INK_SOFT, "lower": C_RED}[res["reply"]]
                    hbox:
                        spacing 30
                        vbox:
                            xsize 230
                            text r.name style "am_h3"
                            hbox:
                                spacing 10
                                text "%s" % before style "am_num" size 40 color C_MUTED
                                text "→" style "am_h2" size 36 color col yalign 0.5
                                text "%s" % after style "am_num" size 40 color col
                        vbox:
                            spacing 4
                            yalign 0.5
                            text "「%s」" % getattr(r, "reply_text", "") style "am_body" xmaximum 1000 substitute False
                            for note_line in res["notes"]:
                                text "※ " + note_line style "am_small"
                    add Solid(C_LINE, ysize=2)
            null height 18
            textbutton "继续" style "am_tape_button" action Return(True)


## ---------------------------------------------------------------------------
## 录用通知：一封信，最后盖章
## ---------------------------------------------------------------------------
screen decision_letter(sub):
    modal True
    if ap_go("decision_letter"):
        timer 0.02 action Return(True)
    $ paper = gs.paper(sub.paper_id)
    $ accepted = sub.outcome == "accept"
    on "show" action Function(sfx, "stamp_accept" if accepted else "stamp_reject")
    use dim(0.5)
    use sheet_at(400, 110, 1120, 820, -0.8):
        vbox:
            spacing 0
            hbox:
                xfill True
                text "Decision Notification" font F_EN size 30 color C_INK_SOFT
                text "#%d" % (sub.id * 7919 % 20000) font F_EN size 26 color C_MUTED xalign 1.0
            null height 10
            text "发件人：%s Program Chairs" % venue_name(sub.venue) style "am_small"
            text "收件人：%s" % gs.player_name style "am_small" substitute False
            null height 10
            add Solid(C_LINE, ysize=2)
            null height 30
            text "Dear Authors," font F_EN size 40 color C_INK
            null height 10
            if accepted:
                text "We are pleased to inform you that your paper" font F_EN size 30 color C_INK
            else:
                text "We regret to inform you that your paper" font F_EN size 30 color C_INK
            text "《%s》" % paper.title style "am_h2" size 32 substitute False
            if accepted:
                text "has been accepted." font F_EN size 30 color C_INK
            else:
                text "was not accepted this time." font F_EN size 30 color C_INK
            null height 24
            text "AC 综合分 %.2f（录用线约 %.1f）" % (sub.final_score or 0, adata.VENUES[sub.venue]["bar"]) style "am_tiny"
            null height 30
            textbutton "把信收好" style "am_tape_button" action Return(True)

    add ("gui/am/stamp_accept.png" if accepted else "gui/am/stamp_reject.png"):
        at stamp_in
        xpos 1240
        ypos 760


transform stamp_in:
    anchor (0.5, 0.5)
    rotate -12
    alpha 0.0
    zoom 1.5
    pause 0.2
    easein 0.16 alpha 0.95 zoom 0.8
    ease 0.08 zoom 0.84


## ---------------------------------------------------------------------------
## 学年总结：成绩单
## ---------------------------------------------------------------------------
screen summary_row(label):
    hbox:
        spacing 0
        text label style "am_small" color C_INK_SOFT min_width 230
        transclude


screen year_summary(s):
    modal True
    if ap_go("year_summary"):
        timer 0.02 action Return(True)
    add "gui/am/desk.png"
    use sheet_at(260, 90, 1000, 900, -0.6, "am_card"):
        vbox:
            spacing 0
            use heading("annual review", "一年级 · 成绩单", 56)
            null height 10
            vbox:
                spacing 22
                use summary_row("投稿 / 被拒 / 中稿"):
                    text "%d  /  %d  /  %d" % (s["submissions"], s["rejections"], len(s["accepted"])) style "am_num" size 38
                use summary_row("中稿论文"):
                    vbox:
                        spacing 8
                        for title, venues in s["accepted"]:
                            hbox:
                                spacing 12
                                for v in venues:
                                    use tag(venue_name(v), VENUE_COLORS.get(v, C_BLUE), True)
                                text "《%s》" % title style "am_body" substitute False xmaximum 560
                        if not s["accepted"]:
                            text "暂无。论文会一直在那里的。" style "am_body" color C_INK_SOFT
                use summary_row("声望"):
                    text "%d" % s["reputation"] style "am_num" size 38
                use summary_row("审稿人称号"):
                    use stamp_tag(s["title"], C_RED, -3)
                if s["pen"]["letters"]:
                    use summary_row("亲笔信"):
                        hbox:
                            spacing 16
                            text "寄出 %d 封，自己写的 %d 封" % (s["pen"]["letters"], s["pen"]["own"]) style "am_body" yalign 0.5
                            if s["pen"]["title"]:
                                use stamp_tag(s["pen"]["title"], C_BLUE if s["pen"]["title"] == "亲笔" else C_GOLD, 4)
            null height 30
            textbutton "继续" style "am_tape_button" action Return(True)

    # 最亲近的人：贴在旁边的拍立得
    text "和你最亲近的人" style "am_h2" xpos 1340 ypos 110
    $ pm = marg("am/polaroid.png")
    vbox:
        xpos 1360 ypos 180
        spacing 10
        for i, (a, h) in enumerate(s["top_affinity"]):
            fixed:
                xysize (200, 270)
                at tilt(tilt_for(i, 3.0))
                add Transform("gui/am/polaroid.png", zoom=0.66) xpos -int(pm * 0.66) ypos -int(pm * 0.66)
                add portrait(h) zoom 0.82 xpos 11 ypos 11
                text adata.HEROINES[h]["name"] style "am_h3" xalign 0.5 ypos 176
                hbox:
                    xalign 0.5 ypos 210
                    use hearts(a, 5, 28)
